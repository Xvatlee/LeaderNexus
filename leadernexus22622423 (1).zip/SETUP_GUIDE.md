# LeaderNexus - Setup & Configuration Guide

## Quick Start

### 1. Environment Setup

Copy the `.env.example` file to `.env.local`:

\`\`\`bash
cp .env.example .env.local
\`\`\`

Then fill in your Supabase credentials:

\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000/dashboard
\`\`\`

**⚠️ Important**: These environment variables MUST be set in your v0 project:
- Go to the **Vars** section in the in-chat sidebar
- Add each environment variable listed above
- Without these, the app will not connect to Supabase

### 2. Install Dependencies

\`\`\`bash
npm install
\`\`\`

### 3. Database Setup

You'll see a "Run Files" dialog with 6 SQL scripts that need to be executed in order. Click **"Run All (6)"** to execute them sequentially:

1. `scripts/01_create_tables.sql` - Creates all base tables
2. `scripts/02_enable_rls.sql` - Enables Row-Level Security
3. `scripts/03_seed_sample_data.sql` - Adds sample data
4. `scripts/04_create_notification_triggers.sql` - Sets up notifications
5. `scripts/008_add_status_to_profiles.sql` - Adds status field
6. `scripts/002_create_voting_tables.sql` - Creates voting system

**Note**: These scripts will be run directly against your Supabase database from v0.

### 4. Start Development Server

\`\`\`bash
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) to see your app!

---

## Project Architecture

### Tech Stack
- **Frontend**: Next.js 15 (App Router), React 19, TypeScript
- **Styling**: Tailwind CSS + shadcn/ui components
- **Backend**: Supabase (PostgreSQL + Auth + Storage)
- **i18n**: Multi-language support (English, Russian, Uzbek)

### Key Features

#### 1. Authentication System
- Email/password registration
- Email verification flow
- Role-based access control (4 roles)
- Secure session management

**User Roles:**
- `admin` - Full system access
- `viloyat_sardori` - Regional leader oversight
- `tuman_sardori` - District leader management
- `district_head_leader` - Individual district operations

#### 2. Project Management
- Create and track projects
- Set milestones and deadlines
- Budget tracking
- Progress monitoring
- Team collaboration

#### 3. Voting & Decision Making
- Democratic polls with multiple options
- Decision proposals with voting
- Real-time vote tracking
- Transparent results display

#### 4. Performance Rating System
- Peer review evaluations
- Multi-category assessments
- Leaderboard rankings
- Analytics dashboard
- Community feedback

#### 5. Media Management
- File upload (images, documents)
- Category organization
- Gallery view
- Supabase Storage integration
- Thumbnail generation

#### 6. Forum & Discussions
- Create discussion posts
- Comment and reply system
- Category organization
- Like/engagement tracking

#### 7. Strategic Planning
- Create plans with tasks
- Task management
- Progress tracking
- Due date monitoring

#### 8. Notifications
- Real-time notification center
- Mark as read functionality
- Notification types (project, voting, rating, etc.)
- Notification history

---

## Common Issues & Solutions

### Issue: Images Not Loading

**Problem**: Icon files showing 404 errors

**Solution**: The project now includes all necessary icon files:
- `/public/icon.svg`
- `/public/icon-light-32x32.png`
- `/public/icon-dark-32x32.png`
- `/public/apple-icon.png`

These are automatically generated and ready to use.

### Issue: Supabase Connection Errors

**Problem**: "Missing Supabase environment variables" error

**Solution**: 
1. Check that environment variables are set in the **Vars section** of v0's sidebar
2. Verify the values are correct (copy from Supabase dashboard)
3. Restart the development server after adding variables

### Issue: Database Tables Not Found

**Problem**: API errors about missing tables

**Solution**:
1. Run all database migration scripts from the "Run Files" dialog
2. Check Supabase SQL Editor to verify tables were created
3. Scripts must be run in order (01, 02, 03, etc.)

### Issue: Translation Keys Not Found

**Problem**: Console warnings about missing translation keys

**Solution**: The project includes comprehensive translations in 3 languages. If you see warnings, check:
- `lib/i18n/translations.ts` for available keys
- Use the correct dot notation (e.g., `t('nav.dashboard')`)
- All keys are properly nested in the translations object

### Issue: Authentication Redirect Loops

**Problem**: After login, redirects keep looping

**Solution**:
1. Ensure `NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL` is set correctly
2. Check that the URL matches your dev server (usually `http://localhost:3000/dashboard`)
3. Clear browser cookies and try again

---

## Database Schema Overview

### Core Tables

**profiles**
- User accounts with roles
- Links to viloyat/tuman/district
- Avatar, bio, points tracking

**viloyat**
- Regional divisions
- Name, description

**tuman**
- District subdivisions under viloyat
- Population, area data

**districts**
- Geographic areas
- Linked to regions

**directions**
- Areas of expertise/work
- Active status

**leader_directions**
- Many-to-many: leaders ↔ directions
- Defines leader expertise areas

### Feature Tables

**projects**
- Project tracking
- Status, progress, budget
- Start/end dates

**project_milestones**
- Milestones for projects
- Completion tracking

**plans**
- Strategic planning
- Tasks and progress

**forum_posts**
- Discussion posts
- Comments and likes

**ratings**
- Performance evaluations
- Multiple scoring categories

**district_ratings**
- District-level ratings
- Ranking system

**notifications**
- System notifications
- Read status tracking

**media**
- File storage metadata
- URLs, categories, tags

**activities**
- Activity tracking
- Impact points

**issues**
- Issue tracking
- Priority and status

---

## API Endpoints

All API routes are located in `/app/api/`:

### Admin APIs
- `GET /api/admin/stats` - System statistics
- `GET /api/admin/users` - List all users
- `GET /api/admin/users/[id]` - Get user details
- `PATCH /api/admin/users/[id]` - Update user
- `DELETE /api/admin/users/[id]` - Delete user

### Authentication
- `GET /api/auth/callback` - OAuth callback handler

### Leaders
- `GET /api/leaders/all` - Get all leaders

### Media
- `POST /api/media/upload` - Upload files

### Notifications
- `GET /api/notifications` - Get user notifications
- `POST /api/notifications` - Create notification
- `PATCH /api/notifications/[id]/read` - Mark as read
- `PATCH /api/notifications/mark-all-read` - Mark all as read

### Plans
- `GET /api/plans` - List plans
- `POST /api/plans` - Create plan
- `GET /api/plans/[id]` - Get plan details
- `PUT /api/plans/[id]` - Update plan
- `DELETE /api/plans/[id]` - Delete plan
- `POST /api/plans/[id]/tasks` - Create task
- `PUT /api/plans/tasks/[taskId]` - Update task
- `DELETE /api/plans/tasks/[taskId]` - Delete task

### Ratings
- `GET /api/ratings/analytics` - Rating analytics
- `POST /api/ratings/calculate` - Calculate ratings
- `POST /api/ratings/calculate-all` - Batch calculate
- `GET /api/ratings/leaderboard` - Get leaderboard
- `GET /api/ratings/my-rating` - Get current user rating
- `POST /api/ratings/peer-review` - Submit peer review
- `GET/POST /api/ratings/community-feedback` - Community feedback

### Voting
- `POST /api/decisions/[id]/vote` - Vote on decision
- `POST /api/polls/[id]/vote` - Vote on poll

### Projects
- `POST /api/projects/[id]/join` - Join project

### Reports
- `POST /api/reports/approve` - Approve report

---

## Security Features

### Row-Level Security (RLS)
All database tables have RLS policies enabled to ensure:
- Users can only access their own data
- Role-based data access
- District-level data isolation
- Admin override capabilities

### Access Control
- Authentication required for all protected routes
- Role verification on sensitive operations
- District ownership validation
- Audit logging for security events

### Data Protection
- Password hashing (handled by Supabase Auth)
- Secure session management
- HTTP-only cookies
- CSRF protection

---

## Deployment Checklist

### Pre-Deployment
- [ ] All environment variables set in Vercel
- [ ] Database migrations run on production Supabase
- [ ] Storage buckets configured
- [ ] Email templates set up in Supabase
- [ ] Test authentication flow
- [ ] Verify RLS policies are active

### Post-Deployment
- [ ] Test all user roles
- [ ] Verify API endpoints
- [ ] Check file uploads
- [ ] Test notifications
- [ ] Monitor error logs
- [ ] Set up monitoring (optional: Sentry)

---

## Development Workflow

### Adding New Features

1. **Database Changes**: Create a new SQL script in `/scripts/` with incrementing number
2. **Types**: Update `/lib/types/database.types.ts` with new table types
3. **Components**: Add React components in relevant `/components/` subdirectory
4. **API Routes**: Create API routes in `/app/api/` if needed
5. **Pages**: Add pages in `/app/` following App Router structure
6. **Translations**: Add translation keys to `/lib/i18n/translations.ts`

### Code Organization

\`\`\`
Feature-based organization:
/app/[feature]/         - Pages for the feature
/components/[feature]/  - Components specific to the feature
/app/api/[feature]/     - API routes for the feature
\`\`\`

### Best Practices

- Always use TypeScript types from `database.types.ts`
- Leverage existing UI components from `components/ui/`
- Follow RLS patterns for database access
- Use the `useTranslations()` hook for all user-facing text
- Add `[v0]` prefix to console.log statements for debugging
- Follow the established error handling patterns

---

## Support & Resources

### Documentation Files
- `README.md` - Project overview and quick start
- `SETUP_GUIDE.md` (this file) - Detailed setup instructions
- `.env.example` - Environment variable template

### Key Configuration Files
- `next.config.mjs` - Next.js configuration
- `tailwind.config.ts` - Tailwind CSS configuration
- `tsconfig.json` - TypeScript configuration
- `lib/i18n/config.ts` - i18n configuration

### Useful Commands

\`\`\`bash
# Development
npm run dev

# Build
npm run build

# Production
npm start

# Linting
npm run lint

# Type checking
npx tsc --noEmit
\`\`\`

---

## Next Steps

1. **Set Environment Variables**: Add Supabase credentials in v0's Vars section
2. **Run Database Scripts**: Execute all 6 SQL scripts from the "Run Files" dialog
3. **Test Authentication**: Register a test account and verify email flow
4. **Explore Features**: Navigate through different role dashboards
5. **Customize**: Modify branding, colors, and content to your needs

---

**Need Help?**
- Check console logs (prefixed with `[v0]`) for debugging info
- Verify environment variables in the Vars section
- Ensure all database scripts have been executed
- Check Supabase dashboard for database/auth status

---

*Last Updated: January 2026*
