"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send } from "lucide-react"

interface ReportCommentsProps {
  reportId: string
  comments: any[]
  currentUserId: string
}

export function ReportComments({ reportId, comments, currentUserId }: ReportCommentsProps) {
  const router = useRouter()
  const [newComment, setNewComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [replyingTo, setReplyingTo] = useState<string | null>(null)
  const [replyText, setReplyText] = useState("")

  async function handleSubmitComment(e: React.FormEvent) {
    e.preventDefault()
    if (!newComment.trim()) return

    setIsSubmitting(true)
    const supabase = createClient()

    try {
      // Get report details for notification
      const { data: report } = await supabase
        .from("reports")
        .select("user_id, title, districts(name)")
        .eq("id", reportId)
        .single()

      // Insert comment
      await supabase.from("report_comments").insert({
        report_id: reportId,
        user_id: currentUserId,
        comment_text: newComment,
      })

      // Create notification if commenting on someone else's report
      if (report && report.user_id !== currentUserId) {
        await supabase.from("notifications").insert({
          user_id: report.user_id,
          title: "Hisobotingizga izoh qoldirildi",
          message: `"${report.title}" hisobotingizga yangi izoh qoldirildi.`,
          type: "report_comment",
          link: `/tuman/reports/${reportId}`,
        })
      }

      setNewComment("")
      router.refresh()
    } catch (error) {
      console.error("[v0] Error submitting comment:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleSubmitReply(e: React.FormEvent, parentId: string) {
    e.preventDefault()
    if (!replyText.trim()) return

    setIsSubmitting(true)
    const supabase = createClient()

    try {
      // Get parent comment author
      const { data: parentComment } = await supabase
        .from("report_comments")
        .select("user_id")
        .eq("id", parentId)
        .single()

      // Insert reply
      await supabase.from("report_comments").insert({
        report_id: reportId,
        user_id: currentUserId,
        parent_comment_id: parentId,
        comment_text: replyText,
      })

      // Create notification for parent comment author
      if (parentComment && parentComment.user_id !== currentUserId) {
        await supabase.from("notifications").insert({
          user_id: parentComment.user_id,
          title: "Izohingizga javob berildi",
          message: "Hisobot izohi bo'yicha sizga javob berildi.",
          type: "report_comment",
          link: `/tuman/reports/${reportId}`,
        })
      }

      setReplyText("")
      setReplyingTo(null)
      router.refresh()
    } catch (error) {
      console.error("[v0] Error submitting reply:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  // Organize comments into threads
  const topLevelComments = comments.filter((c) => !c.parent_comment_id)
  const replies = comments.filter((c) => c.parent_comment_id)

  function CommentItem({ comment, isReply = false }: { comment: any; isReply?: boolean }) {
    const commentReplies = replies.filter((r) => r.parent_comment_id === comment.id)
    const isReplying = replyingTo === comment.id

    return (
      <div className={isReply ? "ml-12" : ""}>
        <div className="flex gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={comment.profiles?.avatar_url || "/placeholder.svg"} />
            <AvatarFallback>{comment.profiles?.username?.charAt(0).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-sm">
                  {comment.profiles?.full_name || comment.profiles?.username}
                </span>
                <span className="text-xs text-muted-foreground">
                  {new Date(comment.created_at).toLocaleDateString()}
                </span>
              </div>
              <p className="text-sm mt-1">{comment.comment_text}</p>
            </div>

            {!isReply && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setReplyingTo(isReplying ? null : comment.id)}
                className="h-8 text-xs"
              >
                Javob berish
              </Button>
            )}

            {isReplying && (
              <form onSubmit={(e) => handleSubmitReply(e, comment.id)} className="mt-2">
                <div className="flex gap-2">
                  <Textarea
                    placeholder="Javobingizni yozing..."
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    rows={2}
                    className="text-sm"
                    disabled={isSubmitting}
                  />
                  <div className="flex flex-col gap-2">
                    <Button type="submit" size="sm" disabled={isSubmitting || !replyText.trim()}>
                      <Send className="h-3 w-3" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={() => setReplyingTo(null)}>
                      Bekor
                    </Button>
                  </div>
                </div>
              </form>
            )}

            {commentReplies.length > 0 && (
              <div className="space-y-3 mt-3">
                {commentReplies.map((reply) => (
                  <CommentItem key={reply.id} comment={reply} isReply />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* New Comment Form */}
      <Card>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmitComment} className="space-y-4">
            <Textarea
              placeholder="Izoh qoldirish..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              rows={3}
              disabled={isSubmitting}
            />
            <Button type="submit" disabled={isSubmitting || !newComment.trim()}>
              <Send className="h-4 w-4 mr-2" />
              {isSubmitting ? "Yuborilmoqda..." : "Izoh qoldirish"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Comments List */}
      <div className="space-y-6">
        {topLevelComments.length > 0 ? (
          topLevelComments.map((comment) => <CommentItem key={comment.id} comment={comment} />)
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">Hozircha izohlar yo'q</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
