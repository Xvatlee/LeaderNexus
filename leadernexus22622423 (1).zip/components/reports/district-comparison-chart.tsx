"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from "recharts"

interface DistrictData {
  name: string
  performance: number
  reports: number
  projects: number
}

interface DistrictComparisonChartProps {
  data?: DistrictData[]
  title?: string
}

export function DistrictComparisonChart({ 
  data = [], 
  title = "Tumanlar taqqoslash" 
}: DistrictComparisonChartProps) {
  const chartColors = {
    performance: "#22c55e",
    reports: "#3b82f6",
    projects: "#f59e0b"
  }

  if (data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-[300px] text-muted-foreground">
            Ma'lumotlar mavjud emas
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="name" 
              tick={{ fontSize: 12 }}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              tick={{ fontSize: 12 }}
              tickLine={false}
              axisLine={false}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px'
              }}
            />
            <Legend />
            <Bar 
              dataKey="performance" 
              name="Samaradorlik (%)" 
              fill={chartColors.performance}
              radius={[4, 4, 0, 0]}
            />
            <Bar 
              dataKey="reports" 
              name="Hisobotlar" 
              fill={chartColors.reports}
              radius={[4, 4, 0, 0]}
            />
            <Bar 
              dataKey="projects" 
              name="Loyihalar" 
              fill={chartColors.projects}
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
