"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Plus, Trash2 } from "lucide-react"
import Link from "next/link"
import type { ProjectDetail, CommunityActivity } from "@/lib/types/reports.types"

interface CreateReportFormProps {
  userId: string
  districtId: string
  districtName: string
}

export default function CreateReportForm({ userId, districtId, districtName }: CreateReportFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isDraft, setIsDraft] = useState(false)

  const currentYear = new Date().getFullYear()
  const currentMonth = new Date().getMonth() + 1

  const [formData, setFormData] = useState({
    report_type: "monthly" as "monthly" | "yearly",
    report_period: `${currentYear}-${String(currentMonth).padStart(2, "0")}`,
    title: "",
    summary: "",
    completed_projects_count: 0,
    ongoing_projects_count: 0,
    events_count: 0,
    initiatives_count: 0,
    participation_rate: 0,
    project_success_rate: 0,
    leadership_effectiveness_score: 0,
    innovation_score: 0,
    challenges_faced: "",
    solutions_implemented: "",
  })

  const [projects, setProjects] = useState<ProjectDetail[]>([])
  const [activities, setActivities] = useState<CommunityActivity[]>([])

  const addProject = () => {
    setProjects([
      ...projects,
      {
        id: crypto.randomUUID(),
        name: "",
        status: "ongoing",
        completion_percentage: 0,
        description: "",
        start_date: "",
        end_date: "",
        impact: "",
      },
    ])
  }

  const removeProject = (id: string) => {
    setProjects(projects.filter((p) => p.id !== id))
  }

  const updateProject = (id: string, field: keyof ProjectDetail, value: any) => {
    setProjects(projects.map((p) => (p.id === id ? { ...p, [field]: value } : p)))
  }

  const addActivity = () => {
    setActivities([
      ...activities,
      {
        id: crypto.randomUUID(),
        name: "",
        type: "event",
        date: new Date().toISOString().split("T")[0],
        participants_count: 0,
        description: "",
        outcome: "",
      },
    ])
  }

  const removeActivity = (id: string) => {
    setActivities(activities.filter((a) => a.id !== id))
  }

  const updateActivity = (id: string, field: keyof CommunityActivity, value: any) => {
    setActivities(activities.map((a) => (a.id === id ? { ...a, [field]: value } : a)))
  }

  const handleSubmit = async (e: React.FormEvent, saveAsDraft = false) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)
    setIsDraft(saveAsDraft)

    const supabase = createClient()

    try {
      const reportData = {
        user_id: userId,
        district_id: districtId,
        report_type: formData.report_type,
        report_period: formData.report_period,
        title: formData.title,
        summary: formData.summary,
        completed_projects_count: formData.completed_projects_count,
        ongoing_projects_count: formData.ongoing_projects_count,
        projects_details: projects,
        events_count: formData.events_count,
        initiatives_count: formData.initiatives_count,
        participation_rate: formData.participation_rate,
        community_activities: activities,
        project_success_rate: formData.project_success_rate,
        leadership_effectiveness_score: formData.leadership_effectiveness_score,
        innovation_score: formData.innovation_score,
        performance_metrics: {},
        challenges_faced: formData.challenges_faced,
        solutions_implemented: formData.solutions_implemented,
        status: saveAsDraft ? "draft" : "submitted",
        submitted_at: saveAsDraft ? null : new Date().toISOString(),
      }

      const { data, error } = await supabase.from("reports").insert(reportData).select().single()

      if (error) throw error

      router.push(`/tuman/reports/${data.id}`)
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost" size="icon">
            <Link href="/tuman/reports">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <CardTitle>Yangi hisobot yaratish</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">{districtName} tumani</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={(e) => handleSubmit(e, false)} className="space-y-8">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Asosiy ma'lumotlar</h3>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="report_type">Hisobot turi *</Label>
                <Select
                  value={formData.report_type}
                  onValueChange={(value: "monthly" | "yearly") => setFormData({ ...formData, report_type: value })}
                  disabled={isLoading}
                >
                  <SelectTrigger id="report_type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Oylik hisobot</SelectItem>
                    <SelectItem value="yearly">Yillik hisobot</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="report_period">Davr *</Label>
                <Input
                  id="report_period"
                  type={formData.report_type === "monthly" ? "month" : "number"}
                  value={formData.report_period}
                  onChange={(e) => setFormData({ ...formData, report_period: e.target.value })}
                  disabled={isLoading}
                  required
                  placeholder={formData.report_type === "monthly" ? "2025-01" : "2025"}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Sarlavha *</Label>
              <Input
                id="title"
                placeholder="Hisobot sarlavhasi"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="summary">Qisqacha xulosa</Label>
              <Textarea
                id="summary"
                placeholder="Hisobotning umumiy xulosasi..."
                rows={4}
                value={formData.summary}
                onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Project Updates */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Loyihalar haqida ma'lumot</h3>
              <Button type="button" variant="outline" size="sm" onClick={addProject} disabled={isLoading}>
                <Plus className="h-4 w-4 mr-2" />
                Loyiha qo'shish
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="completed_projects">Tugallangan loyihalar</Label>
                <Input
                  id="completed_projects"
                  type="number"
                  min="0"
                  value={formData.completed_projects_count}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      completed_projects_count: Number.parseInt(e.target.value) || 0,
                    })
                  }
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="ongoing_projects">Davom etayotgan loyihalar</Label>
                <Input
                  id="ongoing_projects"
                  type="number"
                  min="0"
                  value={formData.ongoing_projects_count}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      ongoing_projects_count: Number.parseInt(e.target.value) || 0,
                    })
                  }
                  disabled={isLoading}
                />
              </div>
            </div>

            {projects.map((project, index) => (
              <Card key={project.id} className="p-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Loyiha {index + 1}</h4>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeProject(project.id)}
                      disabled={isLoading}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Nomi</Label>
                      <Input
                        value={project.name}
                        onChange={(e) => updateProject(project.id, "name", e.target.value)}
                        disabled={isLoading}
                        placeholder="Loyiha nomi"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Holati</Label>
                      <Select
                        value={project.status}
                        onValueChange={(value) => updateProject(project.id, "status", value)}
                        disabled={isLoading}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="completed">Tugallangan</SelectItem>
                          <SelectItem value="ongoing">Davom etmoqda</SelectItem>
                          <SelectItem value="planned">Rejalashtirilgan</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Bajarilish foizi</Label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={project.completion_percentage}
                        onChange={(e) =>
                          updateProject(project.id, "completion_percentage", Number.parseInt(e.target.value) || 0)
                        }
                        disabled={isLoading}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Ta'sir</Label>
                      <Input
                        value={project.impact || ""}
                        onChange={(e) => updateProject(project.id, "impact", e.target.value)}
                        disabled={isLoading}
                        placeholder="Loyihaning ta'siri"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Tavsif</Label>
                    <Textarea
                      rows={2}
                      value={project.description || ""}
                      onChange={(e) => updateProject(project.id, "description", e.target.value)}
                      disabled={isLoading}
                      placeholder="Loyiha haqida qisqacha ma'lumot"
                    />
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Community Engagement */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Jamoat faoliyati</h3>
              <Button type="button" variant="outline" size="sm" onClick={addActivity} disabled={isLoading}>
                <Plus className="h-4 w-4 mr-2" />
                Faoliyat qo'shish
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="events_count">Tadbirlar soni</Label>
                <Input
                  id="events_count"
                  type="number"
                  min="0"
                  value={formData.events_count}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      events_count: Number.parseInt(e.target.value) || 0,
                    })
                  }
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="initiatives_count">Tashabbuslar soni</Label>
                <Input
                  id="initiatives_count"
                  type="number"
                  min="0"
                  value={formData.initiatives_count}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      initiatives_count: Number.parseInt(e.target.value) || 0,
                    })
                  }
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="participation_rate">Ishtirok foizi (%)</Label>
                <Input
                  id="participation_rate"
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={formData.participation_rate}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      participation_rate: Number.parseFloat(e.target.value) || 0,
                    })
                  }
                  disabled={isLoading}
                />
              </div>
            </div>

            {activities.map((activity, index) => (
              <Card key={activity.id} className="p-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Faoliyat {index + 1}</h4>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeActivity(activity.id)}
                      disabled={isLoading}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <Label>Nomi</Label>
                      <Input
                        value={activity.name}
                        onChange={(e) => updateActivity(activity.id, "name", e.target.value)}
                        disabled={isLoading}
                        placeholder="Faoliyat nomi"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Turi</Label>
                      <Select
                        value={activity.type}
                        onValueChange={(value: "event" | "initiative" | "program") =>
                          updateActivity(activity.id, "type", value)
                        }
                        disabled={isLoading}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="event">Tadbir</SelectItem>
                          <SelectItem value="initiative">Tashabbuss</SelectItem>
                          <SelectItem value="program">Dastur</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Sana</Label>
                      <Input
                        type="date"
                        value={activity.date}
                        onChange={(e) => updateActivity(activity.id, "date", e.target.value)}
                        disabled={isLoading}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Ishtirokchilar soni</Label>
                    <Input
                      type="number"
                      min="0"
                      value={activity.participants_count}
                      onChange={(e) =>
                        updateActivity(activity.id, "participants_count", Number.parseInt(e.target.value) || 0)
                      }
                      disabled={isLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Tavsif</Label>
                    <Textarea
                      rows={2}
                      value={activity.description || ""}
                      onChange={(e) => updateActivity(activity.id, "description", e.target.value)}
                      disabled={isLoading}
                      placeholder="Faoliyat haqida qisqacha"
                    />
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Performance Metrics */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Samaradorlik ko'rsatkichlari</h3>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="project_success_rate">Loyihalar muvaffaqiyati (%)</Label>
                <Input
                  id="project_success_rate"
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={formData.project_success_rate}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      project_success_rate: Number.parseFloat(e.target.value) || 0,
                    })
                  }
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="leadership_score">Yetakchilik samaradorligi</Label>
                <Input
                  id="leadership_score"
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={formData.leadership_effectiveness_score}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      leadership_effectiveness_score: Number.parseFloat(e.target.value) || 0,
                    })
                  }
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="innovation_score">Innovatsiya balli</Label>
                <Input
                  id="innovation_score"
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={formData.innovation_score}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      innovation_score: Number.parseFloat(e.target.value) || 0,
                    })
                  }
                  disabled={isLoading}
                />
              </div>
            </div>
          </div>

          {/* Challenges and Solutions */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Muammolar va yechimlar</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="challenges">Duch kelgan muammolar</Label>
                <Textarea
                  id="challenges"
                  placeholder="Hisobot davrida duch kelgan asosiy muammolar..."
                  rows={4}
                  value={formData.challenges_faced}
                  onChange={(e) => setFormData({ ...formData, challenges_faced: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="solutions">Amalga oshirilgan yechimlar</Label>
                <Textarea
                  id="solutions"
                  placeholder="Muammolarni hal qilish uchun qo'llanilgan yechimlar..."
                  rows={4}
                  value={formData.solutions_implemented}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      solutions_implemented: e.target.value,
                    })
                  }
                  disabled={isLoading}
                />
              </div>
            </div>
          </div>

          {error && (
            <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md p-3">
              {error}
            </div>
          )}

          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading}>
              {isLoading && !isDraft ? "Yuborilmoqda..." : "Yuborish"}
            </Button>
            <Button type="button" variant="outline" disabled={isLoading} onClick={(e: any) => handleSubmit(e, true)}>
              {isLoading && isDraft ? "Saqlanmoqda..." : "Qoralama sifatida saqlash"}
            </Button>
            <Button type="button" variant="ghost" asChild disabled={isLoading}>
              <Link href="/tuman/reports">Bekor qilish</Link>
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
