"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { FileText, Calendar, TrendingUp, Eye } from "lucide-react"
import type { Report } from "@/lib/types/reports.types"
import Link from "next/link"

interface ReportsListProps {
  reports: Report[]
  userRole: "tuman" | "viloyat"
}

export function ReportsList({ reports, userRole }: ReportsListProps) {
  function getStatusBadge(status: string) {
    const statusMap = {
      draft: { label: "Qoralama", variant: "secondary" as const },
      submitted: { label: "Yuborilgan", variant: "default" as const },
      reviewed: { label: "Ko'rib chiqilgan", variant: "default" as const },
      approved: { label: "Tasdiqlangan", variant: "default" as const },
    }
    const config = statusMap[status as keyof typeof statusMap] || statusMap.draft
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  function getReportTypeLabel(type: string) {
    return type === "monthly" ? "Oylik" : "Yillik"
  }

  return (
    <div className="grid gap-4">
      {reports.map((report) => (
        <Card key={report.id}>
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1 flex-1">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{getReportTypeLabel(report.report_type)}</Badge>
                  <span className="text-sm text-muted-foreground">{report.report_period}</span>
                </div>
                <CardTitle className="text-xl">{report.title}</CardTitle>
                {report.summary && <CardDescription className="line-clamp-2">{report.summary}</CardDescription>}
              </div>
              <div className="flex items-center gap-2">
                {getStatusBadge(report.status)}
                <Button asChild variant="outline" size="sm">
                  <Link href={`/${userRole}/reports/${report.id}`}>
                    <Eye className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4">
              <div className="flex items-center gap-2 text-sm">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Loyihalar</p>
                  <p className="font-medium">{report.completed_projects_count + report.ongoing_projects_count}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Tadbirlar</p>
                  <p className="font-medium">{report.events_count}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Ishtirok</p>
                  <p className="font-medium">{report.participation_rate}%</p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Samaradorlik</p>
                  <p className="font-medium">{report.leadership_effectiveness_score}/100</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 mt-4 border-t">
              <div className="text-sm text-muted-foreground">
                {report.submitted_at
                  ? `Yuborildi: ${new Date(report.submitted_at).toLocaleDateString()}`
                  : `Yaratildi: ${new Date(report.created_at).toLocaleDateString()}`}
              </div>
              <Button asChild variant="outline" size="sm">
                <Link href={`/${userRole}/reports/${report.id}`}>Batafsil</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
