"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Star } from "lucide-react"

interface ReportFeedbackFormProps {
  reportId: string
  reviewerId: string
}

export function ReportFeedbackForm({ reportId, reviewerId }: ReportFeedbackFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [ratings, setRatings] = useState({
    overall: 0,
    projectSuccess: 0,
    communityParticipation: 0,
    leadership: 0,
  })

  const [formData, setFormData] = useState({
    feedback: "",
    suggestions: "",
    improvements: "",
  })

  function StarRating({ value, onChange }: { value: number; onChange: (value: number) => void }) {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="focus:outline-none transition-colors"
          >
            <Star className={`h-6 w-6 ${star <= value ? "fill-primary text-primary" : "text-muted-foreground"}`} />
          </button>
        ))}
      </div>
    )
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const supabase = createClient()

    try {
      // Insert feedback
      const { error: feedbackError } = await supabase.from("report_feedback").insert({
        report_id: reportId,
        reviewer_id: reviewerId,
        overall_rating: ratings.overall,
        project_success_rating: ratings.projectSuccess,
        community_participation_rating: ratings.communityParticipation,
        leadership_rating: ratings.leadership,
        feedback_text: formData.feedback,
        suggestions: formData.suggestions,
        areas_for_improvement: formData.improvements,
      })

      if (feedbackError) throw feedbackError

      // Update report status
      await supabase
        .from("reports")
        .update({
          status: "reviewed",
          reviewed_at: new Date().toISOString(),
          reviewed_by: reviewerId,
        })
        .eq("id", reportId)

      // Create notification for report author
      const { data: report } = await supabase.from("reports").select("user_id").eq("id", reportId).single()

      if (report) {
        await supabase.from("notifications").insert({
          user_id: report.user_id,
          title: "Hisobotingiz ko'rib chiqildi",
          message: "Viloyat sardori tomonidan hisobotingizga fikr-mulohaza qoldirildi.",
          type: "report_feedback",
          link: `/tuman/reports/${reportId}`,
        })
      }

      router.refresh()

      // Reset form
      setRatings({ overall: 0, projectSuccess: 0, communityParticipation: 0, leadership: 0 })
      setFormData({ feedback: "", suggestions: "", improvements: "" })
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Baholash va fikr-mulohaza qoldirish</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Ratings */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Umumiy baho</Label>
              <StarRating value={ratings.overall} onChange={(value) => setRatings({ ...ratings, overall: value })} />
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label className="text-sm">Loyihalar muvaffaqiyati</Label>
                <StarRating
                  value={ratings.projectSuccess}
                  onChange={(value) => setRatings({ ...ratings, projectSuccess: value })}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm">Jamoat ishtiroki</Label>
                <StarRating
                  value={ratings.communityParticipation}
                  onChange={(value) => setRatings({ ...ratings, communityParticipation: value })}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm">Yetakchilik</Label>
                <StarRating
                  value={ratings.leadership}
                  onChange={(value) => setRatings({ ...ratings, leadership: value })}
                />
              </div>
            </div>
          </div>

          {/* Text Feedback */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="feedback">Fikr-mulohaza</Label>
              <Textarea
                id="feedback"
                placeholder="Hisobot haqida umumiy fikringiz..."
                rows={4}
                value={formData.feedback}
                onChange={(e) => setFormData({ ...formData, feedback: e.target.value })}
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="suggestions">Takliflar</Label>
              <Textarea
                id="suggestions"
                placeholder="Qanday takomillashtirish mumkin..."
                rows={3}
                value={formData.suggestions}
                onChange={(e) => setFormData({ ...formData, suggestions: e.target.value })}
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="improvements">Yaxshilanishi kerak bo'lgan sohalar</Label>
              <Textarea
                id="improvements"
                placeholder="E'tibor qaratish lozim bo'lgan joylar..."
                rows={3}
                value={formData.improvements}
                onChange={(e) => setFormData({ ...formData, improvements: e.target.value })}
                disabled={isLoading}
              />
            </div>
          </div>

          {error && (
            <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md p-3">
              {error}
            </div>
          )}

          <Button type="submit" disabled={isLoading || ratings.overall === 0}>
            {isLoading ? "Yuklanmoqda..." : "Fikr-mulohaza yuborish"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
