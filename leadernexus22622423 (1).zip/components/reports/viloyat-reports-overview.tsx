"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Eye, FileText, TrendingUp, Search, Filter } from "lucide-react"
import Link from "next/link"

interface ViloyatReportsOverviewProps {
  reports: any[]
}

export function ViloyatReportsOverview({ reports }: ViloyatReportsOverviewProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterType, setFilterType] = useState("all")
  const [filterDistrict, setFilterDistrict] = useState("all")

  // Get unique districts
  const districts = Array.from(new Set(reports.map((r) => r.districts?.name).filter(Boolean)))

  // Filter reports
  const filteredReports = reports.filter((report) => {
    const matchesSearch =
      searchQuery === "" ||
      report.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.districts?.name?.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = filterStatus === "all" || report.status === filterStatus
    const matchesType = filterType === "all" || report.report_type === filterType
    const matchesDistrict = filterDistrict === "all" || report.districts?.name === filterDistrict

    return matchesSearch && matchesStatus && matchesType && matchesDistrict
  })

  // Group by status
  const submittedReports = filteredReports.filter((r) => r.status === "submitted")
  const reviewedReports = filteredReports.filter((r) => r.status === "reviewed")
  const approvedReports = filteredReports.filter((r) => r.status === "approved")

  function getStatusBadge(status: string) {
    const statusMap = {
      draft: { label: "Qoralama", variant: "secondary" as const },
      submitted: { label: "Yuborilgan", variant: "default" as const },
      reviewed: { label: "Ko'rib chiqilgan", variant: "default" as const },
      approved: { label: "Tasdiqlangan", variant: "default" as const },
    }
    const config = statusMap[status as keyof typeof statusMap] || statusMap.draft
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  function ReportCard({ report }: { report: any }) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-2 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="outline">{report.report_type === "monthly" ? "Oylik" : "Yillik"}</Badge>
                <span className="text-sm text-muted-foreground">{report.report_period}</span>
                <Badge variant="outline">{report.districts?.name}</Badge>
              </div>
              <CardTitle className="text-lg">{report.title}</CardTitle>
              <p className="text-sm text-muted-foreground">{report.profiles?.full_name || report.profiles?.username}</p>
            </div>
            <div className="flex items-center gap-2">{getStatusBadge(report.status)}</div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-3 mb-4">
            <div className="flex items-center gap-2 text-sm">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Loyihalar</p>
                <p className="font-medium">{report.completed_projects_count + report.ongoing_projects_count}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Tadbirlar</p>
                <p className="font-medium">{report.events_count}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Samaradorlik</p>
                <p className="font-medium">{report.leadership_effectiveness_score}/100</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-3 border-t">
            <div className="text-sm text-muted-foreground">
              {report.submitted_at
                ? `Yuborildi: ${new Date(report.submitted_at).toLocaleDateString()}`
                : `Yaratildi: ${new Date(report.created_at).toLocaleDateString()}`}
            </div>
            <Button asChild variant="outline" size="sm">
              <Link href={`/viloyat/reports/${report.id}`}>
                <Eye className="h-4 w-4 mr-2" />
                Ko'rish
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filtrlash
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Qidirish..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
            </div>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Holat" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Barcha holatlar</SelectItem>
                <SelectItem value="submitted">Yuborilgan</SelectItem>
                <SelectItem value="reviewed">Ko'rib chiqilgan</SelectItem>
                <SelectItem value="approved">Tasdiqlangan</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Turi" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Barcha turlar</SelectItem>
                <SelectItem value="monthly">Oylik</SelectItem>
                <SelectItem value="yearly">Yillik</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterDistrict} onValueChange={setFilterDistrict}>
              <SelectTrigger>
                <SelectValue placeholder="Tuman" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Barcha tumanlar</SelectItem>
                {districts.map((district) => (
                  <SelectItem key={district} value={district}>
                    {district}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabbed View */}
      <Tabs defaultValue="submitted" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">Barchasi ({filteredReports.length})</TabsTrigger>
          <TabsTrigger value="submitted">Yuborilgan ({submittedReports.length})</TabsTrigger>
          <TabsTrigger value="reviewed">Ko'rilgan ({reviewedReports.length})</TabsTrigger>
          <TabsTrigger value="approved">Tasdiqlangan ({approvedReports.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4 mt-6">
          {filteredReports.length > 0 ? (
            filteredReports.map((report) => <ReportCard key={report.id} report={report} />)
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Hisobotlar topilmadi</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="submitted" className="space-y-4 mt-6">
          {submittedReports.length > 0 ? (
            submittedReports.map((report) => <ReportCard key={report.id} report={report} />)
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Yuborilgan hisobotlar yo'q</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="reviewed" className="space-y-4 mt-6">
          {reviewedReports.length > 0 ? (
            reviewedReports.map((report) => <ReportCard key={report.id} report={report} />)
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Ko'rib chiqilgan hisobotlar yo'q</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-4 mt-6">
          {approvedReports.length > 0 ? (
            approvedReports.map((report) => <ReportCard key={report.id} report={report} />)
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Tasdiqlangan hisobotlar yo'q</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
