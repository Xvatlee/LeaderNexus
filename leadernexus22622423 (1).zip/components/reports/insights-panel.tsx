"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { TrendingUp, TrendingDown, Award, AlertTriangle, Lightbulb, Target } from "lucide-react"

interface InsightsPanelProps {
  districtMetrics: any[]
  trends: any[]
}

export function InsightsPanel({ districtMetrics, trends }: InsightsPanelProps) {
  // Calculate insights
  const sortedByOverall = [...districtMetrics].sort((a, b) => b.overallScore - a.overallScore)
  const topPerformer = sortedByOverall[0]
  const needsSupport = sortedByOverall.filter((d) => d.overallScore < 50)

  const sortedByProjects = [...districtMetrics].sort((a, b) => b.avgProjectsCompleted - a.avgProjectsCompleted)
  const mostProjects = sortedByProjects[0]

  const sortedByParticipation = [...districtMetrics].sort((a, b) => b.avgParticipationRate - a.avgParticipationRate)
  const highestParticipation = sortedByParticipation[0]

  const sortedByInnovation = [...districtMetrics].sort((a, b) => b.avgInnovationScore - a.avgInnovationScore)
  const mostInnovative = sortedByInnovation[0]

  // Analyze trends
  const recentTrends = trends.slice(-3)
  const isImproving =
    recentTrends.length >= 2 &&
    recentTrends[recentTrends.length - 1].avgLeadershipScore > recentTrends[0].avgLeadershipScore

  return (
    <div className="space-y-6">
      {/* Top Performers */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-yellow-500" />
            Eng yaxshi ko'rsatkichlar
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="border rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Umumiy ball bo'yicha</span>
                <Badge variant="default">1-o'rin</Badge>
              </div>
              <p className="text-lg font-bold">{topPerformer?.districtName}</p>
              <p className="text-2xl font-bold text-primary">{topPerformer?.overallScore}</p>
            </div>

            <div className="border rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Eng ko'p loyihalar</span>
                <TrendingUp className="h-4 w-4 text-green-500" />
              </div>
              <p className="text-lg font-bold">{mostProjects?.districtName}</p>
              <p className="text-2xl font-bold text-primary">{mostProjects?.avgProjectsCompleted} ta</p>
            </div>

            <div className="border rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Eng yuqori ishtirok</span>
                <Target className="h-4 w-4 text-blue-500" />
              </div>
              <p className="text-lg font-bold">{highestParticipation?.districtName}</p>
              <p className="text-2xl font-bold text-primary">{highestParticipation?.avgParticipationRate}%</p>
            </div>

            <div className="border rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Eng innovatsion</span>
                <Lightbulb className="h-4 w-4 text-purple-500" />
              </div>
              <p className="text-lg font-bold">{mostInnovative?.districtName}</p>
              <p className="text-2xl font-bold text-primary">{mostInnovative?.avgInnovationScore}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trends Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {isImproving ? (
              <TrendingUp className="h-5 w-5 text-green-500" />
            ) : (
              <TrendingDown className="h-5 w-5 text-red-500" />
            )}
            Tendensiyalar tahlili
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertDescription>
              {isImproving ? (
                <span className="text-green-600">
                  ✓ Viloyat darajasida umumiy samaradorlik oxirgi oylar davomida yaxshilanmoqda. Davom eting!
                </span>
              ) : (
                <span className="text-amber-600">
                  ⚠ Viloyat darajasida ba'zi ko'rsatkichlarda pasayish kuzatilmoqda. E'tibor qaratish tavsiya etiladi.
                </span>
              )}
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Areas for Improvement */}
      {needsSupport.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              Yordamga muhtoj tumanlar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {needsSupport.map((district) => (
                <div key={district.districtId} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-semibold">{district.districtName}</p>
                    <Badge variant="destructive">{district.overallScore} ball</Badge>
                  </div>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    {district.avgLeadershipScore < 50 && <p>• Yetakchilik samaradorligini oshirish kerak</p>}
                    {district.avgInnovationScore < 50 && <p>• Innovatsion yondashuvlarni rivojlantirish zarur</p>}
                    {district.avgParticipationRate < 40 && <p>• Jamoatchilik ishtiroki past darajada</p>}
                    {district.avgProjectsCompleted < 2 && <p>• Loyihalar sonini ko'paytirish tavsiya etiladi</p>}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-amber-500" />
            Tavsiyalar
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Alert>
              <AlertDescription>
                <strong>1. Tajriba almashish:</strong> {topPerformer?.districtName} tumanining muvaffaqiyatli
                tajribasini boshqa tumanlar bilan bo'lishing.
              </AlertDescription>
            </Alert>

            {needsSupport.length > 0 && (
              <Alert>
                <AlertDescription>
                  <strong>2. Maqsadli qo'llab-quvvatlash:</strong> {needsSupport.length} ta tuman qo'shimcha yordam va
                  ko'rsatmaga muhtoj. Ular bilan individual ishlashni rejalashtiring.
                </AlertDescription>
              </Alert>
            )}

            <Alert>
              <AlertDescription>
                <strong>3. Innovatsiyani rag'batlantirish:</strong> {mostInnovative?.districtName} tumanining
                innovatsion yondashuvlarini o'rganib, viloyat miqyosida qo'llash imkoniyatlarini ko'rib chiqing.
              </AlertDescription>
            </Alert>

            <Alert>
              <AlertDescription>
                <strong>4. Jamoat ishtiroki:</strong> {highestParticipation?.districtName} tumanining yuqori ishtirok
                darajasiga erishish usullarini boshqa tumanlar uchun namuna qiling.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
