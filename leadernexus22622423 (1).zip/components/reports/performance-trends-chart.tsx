"use client"

import { Line, LineChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

interface PerformanceTrendsChartProps {
  data: any[]
}

export function PerformanceTrendsChart({ data }: PerformanceTrendsChartProps) {
  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
          <XAxis dataKey="period" className="text-xs" />
          <YAxis className="text-xs" />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="rounded-lg border bg-background p-3 shadow-sm">
                    <div className="mb-2">
                      <span className="text-sm font-bold">{payload[0].payload.period}</span>
                    </div>
                    <div className="grid gap-2">
                      {payload.map((entry: any, index: number) => (
                        <div key={index} className="flex items-center justify-between gap-4">
                          <span className="text-xs text-muted-foreground">{entry.name}:</span>
                          <span className="text-xs font-bold" style={{ color: entry.color }}>
                            {entry.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              }
              return null
            }}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="avgProjectSuccessRate"
            name="Loyihalar"
            stroke="hsl(var(--chart-1))"
            strokeWidth={2}
          />
          <Line
            type="monotone"
            dataKey="avgLeadershipScore"
            name="Yetakchilik"
            stroke="hsl(var(--chart-2))"
            strokeWidth={2}
          />
          <Line
            type="monotone"
            dataKey="avgInnovationScore"
            name="Innovatsiya"
            stroke="hsl(var(--chart-3))"
            strokeWidth={2}
          />
          <Line
            type="monotone"
            dataKey="avgParticipationRate"
            name="Ishtirok"
            stroke="hsl(var(--chart-4))"
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
