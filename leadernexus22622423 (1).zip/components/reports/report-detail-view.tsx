"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, FileText, Calendar, TrendingUp, Users, MessageSquare } from "lucide-react"
import Link from "next/link"
import { ReportFeedbackForm } from "@/components/reports/report-feedback-form"
import { ReportComments } from "@/components/reports/report-comments"

interface ReportDetailViewProps {
  report: any
  feedback: any[]
  comments: any[]
  userRole: "tuman" | "viloyat"
  currentUserId: string
}

export function ReportDetailView({ report, feedback, comments, userRole, currentUserId }: ReportDetailViewProps) {
  function getStatusBadge(status: string) {
    const statusMap = {
      draft: { label: "Qoralama", variant: "secondary" as const },
      submitted: { label: "Yuborilgan", variant: "default" as const },
      reviewed: { label: "Ko'rib chiqilgan", variant: "default" as const },
      approved: { label: "Tasdiqlangan", variant: "default" as const },
    }
    const config = statusMap[status as keyof typeof statusMap] || statusMap.draft
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1">
          <Button asChild variant="ghost" size="icon">
            <Link href={`/${userRole}/reports`}>
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="outline">{report.report_type === "monthly" ? "Oylik" : "Yillik"}</Badge>
              <span className="text-sm text-muted-foreground">{report.report_period}</span>
              {report.districts && <Badge variant="outline">{report.districts.name}</Badge>}
            </div>
            <h1 className="text-3xl font-bold">{report.title}</h1>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>{report.profiles?.full_name || report.profiles?.username}</span>
              <span>•</span>
              <span>
                {report.submitted_at
                  ? `Yuborildi: ${new Date(report.submitted_at).toLocaleDateString()}`
                  : `Yaratildi: ${new Date(report.created_at).toLocaleDateString()}`}
              </span>
            </div>
          </div>
        </div>
        {getStatusBadge(report.status)}
      </div>

      {/* Summary */}
      {report.summary && (
        <Card>
          <CardHeader>
            <CardTitle>Umumiy xulosa</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{report.summary}</p>
          </CardContent>
        </Card>
      )}

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Loyihalar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{report.completed_projects_count + report.ongoing_projects_count}</div>
            <p className="text-xs text-muted-foreground">
              {report.completed_projects_count} tugallangan, {report.ongoing_projects_count} davom etmoqda
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Tadbirlar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{report.events_count}</div>
            <p className="text-xs text-muted-foreground">{report.initiatives_count} tashabbuslar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Ishtirok</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{report.participation_rate}%</div>
            <p className="text-xs text-muted-foreground">Jamoat ishtirok darajasi</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Samaradorlik</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{report.leadership_effectiveness_score}/100</div>
            <p className="text-xs text-muted-foreground">Yetakchilik samaradorligi</p>
          </CardContent>
        </Card>
      </div>

      {/* Project Details */}
      {report.projects_details && report.projects_details.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Loyihalar tafsiloti
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {report.projects_details.map((project: any, index: number) => (
                <div key={project.id || index} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <h4 className="font-semibold">{project.name}</h4>
                      {project.description && <p className="text-sm text-muted-foreground">{project.description}</p>}
                    </div>
                    <Badge variant={project.status === "completed" ? "default" : "secondary"}>
                      {project.status === "completed"
                        ? "Tugallangan"
                        : project.status === "ongoing"
                          ? "Davom etmoqda"
                          : "Rejalashtirilgan"}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">Progress</span>
                      <span className="font-bold">{project.completion_percentage}%</span>
                    </div>
                    <Progress value={project.completion_percentage || 0} className="h-2" />
                  </div>

                  {project.impact && (
                    <div className="text-sm">
                      <span className="font-medium">Ta'sir: </span>
                      <span className="text-muted-foreground">{project.impact}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Community Activities */}
      {report.community_activities && report.community_activities.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Jamoat faoliyatlari
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {report.community_activities.map((activity: any, index: number) => (
                <div key={activity.id || index} className="border rounded-lg p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <h4 className="font-semibold">{activity.name}</h4>
                      {activity.description && <p className="text-sm text-muted-foreground">{activity.description}</p>}
                    </div>
                    <Badge variant="outline">
                      {activity.type === "event"
                        ? "Tadbir"
                        : activity.type === "initiative"
                          ? "Tashabbuslar"
                          : "Dastur"}
                    </Badge>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {new Date(activity.date).toLocaleDateString()}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      {activity.participants_count} ishtirokchi
                    </div>
                  </div>

                  {activity.outcome && (
                    <div className="text-sm">
                      <span className="font-medium">Natija: </span>
                      <span className="text-muted-foreground">{activity.outcome}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Performance Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Samaradorlik ko'rsatkichlari
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-3">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Loyihalar muvaffaqiyati</span>
                <span className="text-sm font-bold">{report.project_success_rate}%</span>
              </div>
              <Progress value={report.project_success_rate || 0} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Yetakchilik samaradorligi</span>
                <span className="text-sm font-bold">{report.leadership_effectiveness_score}/100</span>
              </div>
              <Progress value={report.leadership_effectiveness_score || 0} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Innovatsiya</span>
                <span className="text-sm font-bold">{report.innovation_score}/100</span>
              </div>
              <Progress value={report.innovation_score || 0} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Challenges and Solutions */}
      <div className="grid gap-6 md:grid-cols-2">
        {report.challenges_faced && (
          <Card>
            <CardHeader>
              <CardTitle>Duch kelgan muammolar</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground whitespace-pre-wrap">{report.challenges_faced}</p>
            </CardContent>
          </Card>
        )}

        {report.solutions_implemented && (
          <Card>
            <CardHeader>
              <CardTitle>Amalga oshirilgan yechimlar</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground whitespace-pre-wrap">{report.solutions_implemented}</p>
            </CardContent>
          </Card>
        )}
      </div>

      <Separator />

      {/* Feedback Section (Viloyat only) */}
      {userRole === "viloyat" && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold">Baholash va fikr-mulohaza</h2>

          {feedback && feedback.length > 0 && (
            <div className="space-y-4">
              {feedback.map((fb) => (
                <Card key={fb.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div>
                          <p className="font-semibold">{fb.profiles?.full_name || fb.profiles?.username}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(fb.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      {fb.overall_rating && (
                        <Badge variant="outline" className="text-lg">
                          {fb.overall_rating}/5
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {(fb.project_success_rating || fb.community_participation_rating || fb.leadership_rating) && (
                      <div className="grid gap-3 md:grid-cols-3">
                        {fb.project_success_rating && (
                          <div>
                            <p className="text-sm text-muted-foreground">Loyihalar muvaffaqiyati</p>
                            <p className="font-bold">{fb.project_success_rating}/5</p>
                          </div>
                        )}
                        {fb.community_participation_rating && (
                          <div>
                            <p className="text-sm text-muted-foreground">Jamoat ishtiroki</p>
                            <p className="font-bold">{fb.community_participation_rating}/5</p>
                          </div>
                        )}
                        {fb.leadership_rating && (
                          <div>
                            <p className="text-sm text-muted-foreground">Yetakchilik</p>
                            <p className="font-bold">{fb.leadership_rating}/5</p>
                          </div>
                        )}
                      </div>
                    )}

                    {fb.feedback_text && (
                      <div>
                        <p className="text-sm font-medium mb-1">Fikr-mulohaza:</p>
                        <p className="text-muted-foreground">{fb.feedback_text}</p>
                      </div>
                    )}

                    {fb.suggestions && (
                      <div>
                        <p className="text-sm font-medium mb-1">Takliflar:</p>
                        <p className="text-muted-foreground">{fb.suggestions}</p>
                      </div>
                    )}

                    {fb.areas_for_improvement && (
                      <div>
                        <p className="text-sm font-medium mb-1">Yaxshilanishi kerak bo'lgan sohalar:</p>
                        <p className="text-muted-foreground">{fb.areas_for_improvement}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          <ReportFeedbackForm reportId={report.id} reviewerId={currentUserId} />
        </div>
      )}

      {/* Comments Section */}
      <div className="space-y-6">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <MessageSquare className="h-6 w-6" />
          Izohlar va muhokama
        </h2>
        <ReportComments reportId={report.id} comments={comments} currentUserId={currentUserId} />
      </div>
    </div>
  )
}
