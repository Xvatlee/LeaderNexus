"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowUp, ArrowDown, Minus } from "lucide-react"

interface DistrictPerformance {
  id: string
  name: string
  performance: number
  previousPerformance?: number
  reportsSubmitted: number
  reportsApproved: number
  activeProjects: number
  leadersCount: number
}

interface DistrictPerformanceTableProps {
  districts?: DistrictPerformance[]
  title?: string
}

export function DistrictPerformanceTable({ 
  districts = [],
  title = "Tumanlar samaradorligi"
}: DistrictPerformanceTableProps) {
  const getPerformanceBadge = (performance: number) => {
    if (performance >= 80) return "default"
    if (performance >= 60) return "secondary"
    return "destructive"
  }

  const getTrendIcon = (current: number, previous?: number) => {
    if (!previous) return <Minus className="h-4 w-4 text-muted-foreground" />
    if (current > previous) return <ArrowUp className="h-4 w-4 text-green-500" />
    if (current < previous) return <ArrowDown className="h-4 w-4 text-red-500" />
    return <Minus className="h-4 w-4 text-muted-foreground" />
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {districts.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            Ma'lumotlar mavjud emas
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tuman</TableHead>
                <TableHead>Samaradorlik</TableHead>
                <TableHead>Trend</TableHead>
                <TableHead>Hisobotlar</TableHead>
                <TableHead>Loyihalar</TableHead>
                <TableHead>Liderlar</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {districts.map((district) => (
                <TableRow key={district.id}>
                  <TableCell className="font-medium">{district.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={district.performance} className="w-16 h-2" />
                      <Badge variant={getPerformanceBadge(district.performance)}>
                        {district.performance}%
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    {getTrendIcon(district.performance, district.previousPerformance)}
                  </TableCell>
                  <TableCell>
                    <span className="text-green-600">{district.reportsApproved}</span>
                    <span className="text-muted-foreground"> / {district.reportsSubmitted}</span>
                  </TableCell>
                  <TableCell>{district.activeProjects}</TableCell>
                  <TableCell>{district.leadersCount}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  )
}
