"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { CheckCircle } from "lucide-react"

interface ReportActionsProps {
  reportId: string
  currentStatus: string
  approverId: string
}

export function ReportActions({ reportId, currentStatus, approverId }: ReportActionsProps) {
  const router = useRouter()
  const [isApproving, setIsApproving] = useState(false)

  async function handleApprove() {
    setIsApproving(true)

    try {
      const response = await fetch("/api/reports/approve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reportId, approverId }),
      })

      if (!response.ok) throw new Error("Failed to approve")

      router.refresh()
    } catch (error) {
      console.error("[v0] Error approving report:", error)
    } finally {
      setIsApproving(false)
    }
  }

  if (currentStatus === "approved") {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <CheckCircle className="h-4 w-4 text-green-500" />
        Hisobot tasdiqlangan
      </div>
    )
  }

  return (
    <div className="flex gap-2">
      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button disabled={isApproving}>
            <CheckCircle className="h-4 w-4 mr-2" />
            Tasdiqlash
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hisobotni tasdiqlaysizmi?</AlertDialogTitle>
            <AlertDialogDescription>
              Hisobotni tasdiqlaganingizdan so'ng, tuman sardoriga xabar yuboriladi.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Bekor qilish</AlertDialogCancel>
            <AlertDialogAction onClick={handleApprove} disabled={isApproving}>
              {isApproving ? "Tasdiqlanmoqda..." : "Tasdiqlash"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
