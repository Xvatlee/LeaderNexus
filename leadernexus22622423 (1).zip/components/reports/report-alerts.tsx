"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CheckCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { useState } from "react"
import { useRouter } from "next/navigation"

interface ReportAlertsProps {
  alerts: any[]
}

export function ReportAlerts({ alerts }: ReportAlertsProps) {
  const [isResolving, setIsResolving] = useState<string | null>(null)
  const router = useRouter()

  async function handleResolve(alertId: string) {
    setIsResolving(alertId)
    const supabase = createClient()

    try {
      await supabase
        .from("report_alerts")
        .update({
          is_resolved: true,
          resolved_at: new Date().toISOString(),
        })
        .eq("id", alertId)

      router.refresh()
    } catch (error) {
      console.error("[v0] Error resolving alert:", error)
    } finally {
      setIsResolving(null)
    }
  }

  function getAlertBadge(type: string) {
    const typeMap = {
      missing: { label: "Yo'q", variant: "destructive" as const },
      overdue: { label: "Muddati o'tgan", variant: "destructive" as const },
      reminder: { label: "Eslatma", variant: "secondary" as const },
    }
    const config = typeMap[type as keyof typeof typeMap] || typeMap.reminder
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-destructive" />
          Ogohlantirishlar
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className="flex items-start justify-between gap-4 p-4 border rounded-lg bg-destructive/5"
            >
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  {getAlertBadge(alert.alert_type)}
                  <Badge variant="outline">{alert.districts?.name}</Badge>
                  <span className="text-sm text-muted-foreground">
                    {alert.report_type === "monthly" ? "Oylik" : "Yillik"} - {alert.expected_period}
                  </span>
                </div>
                <p className="text-sm">{alert.alert_message}</p>
                <p className="text-xs text-muted-foreground">
                  {new Date(alert.created_at).toLocaleDateString()} da yaratilgan
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleResolve(alert.id)}
                disabled={isResolving === alert.id}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                {isResolving === alert.id ? "Hal qilinmoqda..." : "Hal qilindi"}
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
