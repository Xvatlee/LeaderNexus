"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DistrictComparisonChart } from "@/components/reports/district-comparison-chart"
import { PerformanceTrendsChart } from "@/components/reports/performance-trends-chart"
import { DistrictPerformanceTable } from "@/components/reports/district-performance-table"
import { InsightsPanel } from "@/components/reports/insights-panel"
import { useState, useMemo } from "react"
import { TrendingUp, BarChart3, TableIcon, Lightbulb } from "lucide-react"

interface ReportsAnalyticsProps {
  reports: any[]
  districts: any[]
}

export function ReportsAnalytics({ reports, districts }: ReportsAnalyticsProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("all")
  const [selectedMetric, setSelectedMetric] = useState("overall")

  // Get unique periods
  const periods = useMemo(() => {
    const uniquePeriods = Array.from(new Set(reports.map((r) => r.report_period)))
      .sort()
      .reverse()
    return uniquePeriods
  }, [reports])

  // Filter reports by period
  const filteredReports = useMemo(() => {
    if (selectedPeriod === "all") return reports
    return reports.filter((r) => r.report_period === selectedPeriod)
  }, [reports, selectedPeriod])

  // Calculate district performance metrics
  const districtMetrics = useMemo(() => {
    const metrics: Record<string, any> = {}

    districts.forEach((district) => {
      const districtReports = filteredReports.filter((r) => r.district_id === district.id)

      if (districtReports.length === 0) {
        metrics[district.id] = {
          districtId: district.id,
          districtName: district.name,
          reportsCount: 0,
          avgProjectsCompleted: 0,
          avgEventsCount: 0,
          avgParticipationRate: 0,
          avgProjectSuccessRate: 0,
          avgLeadershipScore: 0,
          avgInnovationScore: 0,
          overallScore: 0,
        }
        return
      }

      const totals = districtReports.reduce(
        (acc, report) => ({
          projectsCompleted: acc.projectsCompleted + (report.completed_projects_count || 0),
          projectsOngoing: acc.projectsOngoing + (report.ongoing_projects_count || 0),
          events: acc.events + (report.events_count || 0),
          participationRate: acc.participationRate + (report.participation_rate || 0),
          projectSuccessRate: acc.projectSuccessRate + (report.project_success_rate || 0),
          leadershipScore: acc.leadershipScore + (report.leadership_effectiveness_score || 0),
          innovationScore: acc.innovationScore + (report.innovation_score || 0),
        }),
        {
          projectsCompleted: 0,
          projectsOngoing: 0,
          events: 0,
          participationRate: 0,
          projectSuccessRate: 0,
          leadershipScore: 0,
          innovationScore: 0,
        },
      )

      const count = districtReports.length

      const avgProjectSuccessRate = totals.projectSuccessRate / count
      const avgLeadershipScore = totals.leadershipScore / count
      const avgInnovationScore = totals.innovationScore / count
      const avgParticipationRate = totals.participationRate / count

      // Calculate overall score (weighted average)
      const overallScore =
        (avgProjectSuccessRate * 0.3 +
          avgLeadershipScore * 0.3 +
          avgInnovationScore * 0.2 +
          avgParticipationRate * 0.2) /
        1

      metrics[district.id] = {
        districtId: district.id,
        districtName: district.name,
        reportsCount: count,
        avgProjectsCompleted: Math.round(totals.projectsCompleted / count),
        avgProjectsOngoing: Math.round(totals.projectsOngoing / count),
        avgEventsCount: Math.round(totals.events / count),
        avgParticipationRate: Math.round(avgParticipationRate * 10) / 10,
        avgProjectSuccessRate: Math.round(avgProjectSuccessRate * 10) / 10,
        avgLeadershipScore: Math.round(avgLeadershipScore * 10) / 10,
        avgInnovationScore: Math.round(avgInnovationScore * 10) / 10,
        overallScore: Math.round(overallScore * 10) / 10,
      }
    })

    return Object.values(metrics)
  }, [districts, filteredReports])

  // Calculate performance trends over time
  const performanceTrends = useMemo(() => {
    const trends: Record<string, any> = {}

    periods.slice(0, 12).forEach((period) => {
      const periodReports = reports.filter((r) => r.report_period === period)

      if (periodReports.length === 0) return

      const totals = periodReports.reduce(
        (acc, report) => ({
          projectSuccessRate: acc.projectSuccessRate + (report.project_success_rate || 0),
          leadershipScore: acc.leadershipScore + (report.leadership_effectiveness_score || 0),
          innovationScore: acc.innovationScore + (report.innovation_score || 0),
          participationRate: acc.participationRate + (report.participation_rate || 0),
          eventsCount: acc.eventsCount + (report.events_count || 0),
        }),
        {
          projectSuccessRate: 0,
          leadershipScore: 0,
          innovationScore: 0,
          participationRate: 0,
          eventsCount: 0,
        },
      )

      const count = periodReports.length

      trends[period] = {
        period,
        avgProjectSuccessRate: Math.round((totals.projectSuccessRate / count) * 10) / 10,
        avgLeadershipScore: Math.round((totals.leadershipScore / count) * 10) / 10,
        avgInnovationScore: Math.round((totals.innovationScore / count) * 10) / 10,
        avgParticipationRate: Math.round((totals.participationRate / count) * 10) / 10,
        totalEvents: totals.eventsCount,
        reportsCount: count,
      }
    })

    return Object.values(trends).reverse()
  }, [reports, periods])

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Filtrlar</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <label className="text-sm font-medium">Davr</label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Barcha davrlar</SelectItem>
                  {periods.map((period) => (
                    <SelectItem key={period} value={period}>
                      {period}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Ko'rsatkich</label>
              <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="overall">Umumiy ball</SelectItem>
                  <SelectItem value="projects">Loyihalar</SelectItem>
                  <SelectItem value="leadership">Yetakchilik</SelectItem>
                  <SelectItem value="innovation">Innovatsiya</SelectItem>
                  <SelectItem value="participation">Ishtirok</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Analytics Tabs */}
      <Tabs defaultValue="comparison" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="comparison" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Taqqoslash</span>
          </TabsTrigger>
          <TabsTrigger value="trends" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            <span className="hidden sm:inline">Tendensiyalar</span>
          </TabsTrigger>
          <TabsTrigger value="table" className="gap-2">
            <TableIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Jadval</span>
          </TabsTrigger>
          <TabsTrigger value="insights" className="gap-2">
            <Lightbulb className="h-4 w-4" />
            <span className="hidden sm:inline">Tavsiyalar</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="comparison" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Tumanlar samaradorligi taqqoslash</CardTitle>
              <CardDescription>
                {selectedPeriod === "all"
                  ? "Barcha davrlar bo'yicha o'rtacha ko'rsatkichlar"
                  : `${selectedPeriod} davri uchun`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DistrictComparisonChart data={districtMetrics} metric={selectedMetric} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Vaqt bo'yicha tendensiyalar</CardTitle>
              <CardDescription>Oxirgi 12 davr bo'yicha samaradorlik dinamikasi</CardDescription>
            </CardHeader>
            <CardContent>
              <PerformanceTrendsChart data={performanceTrends} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="table" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Batafsil ko'rsatkichlar jadvali</CardTitle>
              <CardDescription>Barcha tumanlar bo'yicha to'liq ma'lumotlar</CardDescription>
            </CardHeader>
            <CardContent>
              <DistrictPerformanceTable data={districtMetrics} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4 mt-6">
          <InsightsPanel districtMetrics={districtMetrics} trends={performanceTrends} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
