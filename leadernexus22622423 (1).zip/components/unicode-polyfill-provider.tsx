"use client"

// This component ensures the Unicode polyfill is loaded before any Supabase operations
// It must be rendered as early as possible in the component tree

import "@/lib/unicode-polyfill"
import type { ReactNode } from "react"

interface UnicodePolyfillProviderProps {
  children: ReactNode
}

export function UnicodePolyfillProvider({ children }: UnicodePolyfillProviderProps) {
  // The polyfill is loaded via the import above
  // This component just passes through children
  return <>{children}</>
}
