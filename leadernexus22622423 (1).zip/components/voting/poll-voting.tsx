"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Clock, Users, CheckCircle2 } from "lucide-react"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"

interface PollVotingProps {
  poll: any
  options: any[]
  userVote: any
  currentUserId: string
}

export default function PollVoting({ poll, options, userVote, currentUserId }: PollVotingProps) {
  const router = useRouter()
  const [isVoting, setIsVoting] = useState(false)
  const [selectedOption, setSelectedOption] = useState<string>("")
  const [selectedOptions, setSelectedOptions] = useState<string[]>([])

  const totalVotes = options.reduce((sum, opt) => sum + (opt.votes?.[0]?.count || 0), 0)
  const hasVoted = !!userVote

  const handleVote = async () => {
    setIsVoting(true)
    const supabase = createClient()

    try {
      if (poll.poll_type === "single" && !selectedOption) {
        throw new Error("Please select an option")
      }
      if (poll.poll_type === "multiple" && selectedOptions.length === 0) {
        throw new Error("Please select at least one option")
      }

      const votesToInsert =
        poll.poll_type === "single"
          ? [{ poll_id: poll.id, option_id: selectedOption, user_id: currentUserId }]
          : selectedOptions.map((optionId) => ({
              poll_id: poll.id,
              option_id: optionId,
              user_id: currentUserId,
            }))

      const { error } = await supabase.from("poll_votes").insert(votesToInsert)

      if (error) throw error

      toast({
        title: "Vote recorded!",
        description: "Thank you for participating in this poll.",
      })

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsVoting(false)
    }
  }

  const getOptionPercentage = (optionVotes: number) => {
    if (totalVotes === 0) return 0
    return Math.round((optionVotes / totalVotes) * 100)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/10 text-green-500"
      case "closed":
        return "bg-red-500/10 text-red-500"
      default:
        return "bg-gray-500/10 text-gray-500"
    }
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-4">
        <Button asChild variant="ghost" size="icon">
          <Link href="/voting">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold tracking-tight flex-1">{poll.title}</h1>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Poll Information</CardTitle>
            <Badge className={getStatusColor(poll.status)}>{poll.status}</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-muted-foreground">{poll.description}</p>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src={poll.creator?.avatar_url || ""} />
                <AvatarFallback>{poll.creator?.username?.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium">{poll.creator?.full_name || poll.creator?.username}</p>
                <p className="text-xs text-muted-foreground">Poll Creator</p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              {poll.end_date && (
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>Ends {new Date(poll.end_date).toLocaleDateString()}</span>
                </div>
              )}
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                <span>{totalVotes} votes</span>
              </div>
            </div>
          </div>

          {hasVoted && (
            <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/20 rounded-md">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm font-medium text-green-500">You've voted on this poll</p>
                <p className="text-xs text-muted-foreground">
                  Your choice: {poll.poll_type === "single" ? userVote.option?.option_text : "Multiple options"}
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{hasVoted || poll.show_results_before_vote ? "Poll Results" : "Vote"}</CardTitle>
        </CardHeader>
        <CardContent>
          {!hasVoted && !poll.show_results_before_vote ? (
            <div className="space-y-4">
              {poll.poll_type === "single" ? (
                <RadioGroup value={selectedOption} onValueChange={setSelectedOption}>
                  {options.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2 p-3 border rounded-md hover:bg-accent">
                      <RadioGroupItem value={option.id} id={option.id} />
                      <Label htmlFor={option.id} className="flex-1 cursor-pointer">
                        {option.option_text}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              ) : (
                <div className="space-y-2">
                  {options.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2 p-3 border rounded-md hover:bg-accent">
                      <Checkbox
                        id={option.id}
                        checked={selectedOptions.includes(option.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedOptions([...selectedOptions, option.id])
                          } else {
                            setSelectedOptions(selectedOptions.filter((id) => id !== option.id))
                          }
                        }}
                      />
                      <Label htmlFor={option.id} className="flex-1 cursor-pointer">
                        {option.option_text}
                      </Label>
                    </div>
                  ))}
                </div>
              )}

              <Button onClick={handleVote} disabled={isVoting || poll.status !== "active"} className="w-full">
                {isVoting ? "Submitting..." : "Submit Vote"}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {options.map((option) => {
                const voteCount = option.votes?.[0]?.count || 0
                const percentage = getOptionPercentage(voteCount)

                return (
                  <div key={option.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{option.option_text}</span>
                      <span className="text-sm text-muted-foreground">
                        {voteCount} votes ({percentage}%)
                      </span>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
