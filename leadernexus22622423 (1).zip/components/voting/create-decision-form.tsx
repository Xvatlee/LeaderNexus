"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface CreateDecisionFormProps {
  userId: string
}

export default function CreateDecisionForm({ userId }: CreateDecisionFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    decision_type: "policy",
    notes: "",
  })

  const decisionTypes = [
    { value: "policy", label: "Policy Change" },
    { value: "budget", label: "Budget Allocation" },
    { value: "initiative", label: "New Initiative" },
    { value: "procedural", label: "Procedural Change" },
    { value: "other", label: "Other" },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const supabase = createClient()

    try {
      const decisionData: any = {
        proposer_id: userId,
        title: formData.title,
        description: formData.description,
        decision_type: formData.decision_type,
        status: "voting",
      }

      if (formData.notes) decisionData.notes = formData.notes

      const { data, error } = await supabase.from("decisions").insert(decisionData).select().single()

      if (error) throw error

      router.push(`/voting/decisions/${data.id}`)
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost" size="icon">
            <Link href="/voting">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <CardTitle>Decision Proposal</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Decision Title *</Label>
            <Input
              id="title"
              placeholder="Give your proposal a clear title"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="decision_type">Decision Type *</Label>
            <Select
              value={formData.decision_type}
              onValueChange={(value) => setFormData({ ...formData, decision_type: value })}
              disabled={isLoading}
            >
              <SelectTrigger id="decision_type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {decisionTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              placeholder="Explain the decision, its rationale, and expected impact..."
              required
              rows={8}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Additional Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Any additional context or supporting information..."
              rows={4}
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              disabled={isLoading}
            />
          </div>

          {error && (
            <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md p-3">
              {error}
            </div>
          )}

          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Submitting..." : "Submit Proposal"}
            </Button>
            <Button type="button" variant="outline" asChild disabled={isLoading}>
              <Link href="/voting">Cancel</Link>
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
