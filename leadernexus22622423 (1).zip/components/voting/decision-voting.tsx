"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, CheckCircle2, XCircle, Clock } from "lucide-react"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"

interface DecisionVotingProps {
  decision: any
  userVote: any
  currentUserId: string
}

export default function DecisionVoting({ decision, userVote, currentUserId }: DecisionVotingProps) {
  const router = useRouter()
  const [isVoting, setIsVoting] = useState(false)
  const [voteChoice, setVoteChoice] = useState<"yes" | "no" | "abstain" | null>(null)
  const [comment, setComment] = useState("")

  const hasVoted = !!userVote
  const totalVotes = decision.vote_count_yes + decision.vote_count_no + decision.vote_count_abstain
  const yesPercentage = totalVotes > 0 ? Math.round((decision.vote_count_yes / totalVotes) * 100) : 0
  const noPercentage = totalVotes > 0 ? Math.round((decision.vote_count_no / totalVotes) * 100) : 0
  const abstainPercentage = totalVotes > 0 ? Math.round((decision.vote_count_abstain / totalVotes) * 100) : 0

  const handleVote = async () => {
    if (!voteChoice) {
      toast({
        title: "Error",
        description: "Please select your vote",
        variant: "destructive",
      })
      return
    }

    setIsVoting(true)
    const supabase = createClient()

    try {
      // Insert vote
      const { error: voteError } = await supabase.from("decision_votes").insert({
        decision_id: decision.id,
        user_id: currentUserId,
        vote: voteChoice,
        comment: comment || null,
      })

      if (voteError) throw voteError

      // Update vote counts
      const updateField =
        voteChoice === "yes" ? "vote_count_yes" : voteChoice === "no" ? "vote_count_no" : "vote_count_abstain"

      const { error: updateError } = await supabase
        .from("decisions")
        .update({ [updateField]: decision[updateField] + 1 })
        .eq("id", decision.id)

      if (updateError) throw updateError

      toast({
        title: "Vote recorded!",
        description: "Thank you for participating in this decision.",
      })

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsVoting(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "voting":
        return "bg-blue-500/10 text-blue-500"
      case "approved":
        return "bg-green-500/10 text-green-500"
      case "rejected":
        return "bg-red-500/10 text-red-500"
      case "proposed":
        return "bg-yellow-500/10 text-yellow-500"
      case "implemented":
        return "bg-purple-500/10 text-purple-500"
      default:
        return "bg-gray-500/10 text-gray-500"
    }
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-4">
        <Button asChild variant="ghost" size="icon">
          <Link href="/voting">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold tracking-tight flex-1">{decision.title}</h1>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Decision Details</CardTitle>
            <div className="flex gap-2">
              <Badge variant="outline">{decision.decision_type}</Badge>
              <Badge className={getStatusColor(decision.status)}>{decision.status}</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2">Description</h3>
            <p className="text-muted-foreground whitespace-pre-wrap">{decision.description}</p>
          </div>

          {decision.notes && (
            <div>
              <h3 className="font-semibold mb-2">Additional Notes</h3>
              <p className="text-muted-foreground whitespace-pre-wrap">{decision.notes}</p>
            </div>
          )}

          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src={decision.proposer?.avatar_url || ""} />
              <AvatarFallback>{decision.proposer?.username?.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium">{decision.proposer?.full_name || decision.proposer?.username}</p>
              <p className="text-xs text-muted-foreground">Proposed by</p>
            </div>
          </div>

          {hasVoted && (
            <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/20 rounded-md">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm font-medium text-green-500">You've voted on this decision</p>
                <p className="text-xs text-muted-foreground">Your vote: {userVote.vote.toUpperCase()}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Voting Results</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span className="text-sm font-medium">Yes</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  {decision.vote_count_yes} votes ({yesPercentage}%)
                </span>
              </div>
              <Progress value={yesPercentage} className="h-2 bg-gray-200" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <XCircle className="h-4 w-4 text-red-600" />
                  <span className="text-sm font-medium">No</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  {decision.vote_count_no} votes ({noPercentage}%)
                </span>
              </div>
              <Progress value={noPercentage} className="h-2 bg-gray-200" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-gray-600" />
                  <span className="text-sm font-medium">Abstain</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  {decision.vote_count_abstain} votes ({abstainPercentage}%)
                </span>
              </div>
              <Progress value={abstainPercentage} className="h-2 bg-gray-200" />
            </div>
          </div>

          {!hasVoted && decision.status === "voting" && (
            <div className="space-y-4 pt-4 border-t">
              <div>
                <Label className="mb-3 block">Cast Your Vote</Label>
                <div className="grid grid-cols-3 gap-3">
                  <Button
                    variant={voteChoice === "yes" ? "default" : "outline"}
                    onClick={() => setVoteChoice("yes")}
                    className="flex flex-col gap-1 h-auto py-4"
                  >
                    <CheckCircle2 className="h-5 w-5" />
                    <span>Yes</span>
                  </Button>
                  <Button
                    variant={voteChoice === "no" ? "default" : "outline"}
                    onClick={() => setVoteChoice("no")}
                    className="flex flex-col gap-1 h-auto py-4"
                  >
                    <XCircle className="h-5 w-5" />
                    <span>No</span>
                  </Button>
                  <Button
                    variant={voteChoice === "abstain" ? "default" : "outline"}
                    onClick={() => setVoteChoice("abstain")}
                    className="flex flex-col gap-1 h-auto py-4"
                  >
                    <Clock className="h-5 w-5" />
                    <span>Abstain</span>
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="comment">Comment (Optional)</Label>
                <Textarea
                  id="comment"
                  placeholder="Share your thoughts on this decision..."
                  rows={3}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                />
              </div>

              <Button onClick={handleVote} disabled={isVoting || !voteChoice} className="w-full">
                {isVoting ? "Submitting..." : "Submit Vote"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
