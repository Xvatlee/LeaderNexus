"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Plus, X } from "lucide-react"
import Link from "next/link"

interface CreatePollFormProps {
  userId: string
}

export default function CreatePollForm({ userId }: CreatePollFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    poll_type: "single",
    visibility: "all_leaders",
    end_date: "",
    allow_anonymous: false,
    show_results_before_vote: false,
  })

  const [options, setOptions] = useState<string[]>(["", ""])

  const addOption = () => {
    setOptions([...options, ""])
  }

  const removeOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index))
    }
  }

  const updateOption = (index: number, value: string) => {
    const newOptions = [...options]
    newOptions[index] = value
    setOptions(newOptions)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const supabase = createClient()

    try {
      // Validate options
      const validOptions = options.filter((opt) => opt.trim() !== "")
      if (validOptions.length < 2) {
        throw new Error("Please provide at least 2 options")
      }

      const pollData: any = {
        creator_id: userId,
        title: formData.title,
        description: formData.description,
        poll_type: formData.poll_type,
        visibility: formData.visibility,
        status: "active",
        allow_anonymous: formData.allow_anonymous,
        show_results_before_vote: formData.show_results_before_vote,
      }

      if (formData.end_date) pollData.end_date = formData.end_date

      const { data: poll, error: pollError } = await supabase.from("polls").insert(pollData).select().single()

      if (pollError) throw pollError

      // Insert poll options
      const optionsData = validOptions.map((option, index) => ({
        poll_id: poll.id,
        option_text: option,
        option_order: index + 1,
      }))

      const { error: optionsError } = await supabase.from("poll_options").insert(optionsData)

      if (optionsError) throw optionsError

      router.push(`/voting/polls/${poll.id}`)
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost" size="icon">
            <Link href="/voting">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <CardTitle>Poll Details</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Poll Question *</Label>
            <Input
              id="title"
              placeholder="What would you like to ask?"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              placeholder="Provide context and details about this poll..."
              required
              rows={4}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-4">
            <Label>Options *</Label>
            {options.map((option, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  placeholder={`Option ${index + 1}`}
                  value={option}
                  onChange={(e) => updateOption(index, e.target.value)}
                  disabled={isLoading}
                />
                {options.length > 2 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeOption(index)}
                    disabled={isLoading}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button type="button" variant="outline" onClick={addOption} disabled={isLoading}>
              <Plus className="mr-2 h-4 w-4" />
              Add Option
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="poll_type">Poll Type *</Label>
              <Select
                value={formData.poll_type}
                onValueChange={(value) => setFormData({ ...formData, poll_type: value })}
                disabled={isLoading}
              >
                <SelectTrigger id="poll_type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="single">Single Choice</SelectItem>
                  <SelectItem value="multiple">Multiple Choice</SelectItem>
                  <SelectItem value="ranking">Ranking</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="visibility">Visibility *</Label>
              <Select
                value={formData.visibility}
                onValueChange={(value) => setFormData({ ...formData, visibility: value })}
                disabled={isLoading}
              >
                <SelectTrigger id="visibility">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_leaders">All Leaders</SelectItem>
                  <SelectItem value="region_specific">Region Specific</SelectItem>
                  <SelectItem value="admin_only">Admin Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="end_date">End Date (Optional)</Label>
            <Input
              id="end_date"
              type="datetime-local"
              value={formData.end_date}
              onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Allow Anonymous Voting</Label>
                <p className="text-sm text-muted-foreground">Users can vote without revealing their identity</p>
              </div>
              <Switch
                checked={formData.allow_anonymous}
                onCheckedChange={(checked) => setFormData({ ...formData, allow_anonymous: checked })}
                disabled={isLoading}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Show Results Before Voting</Label>
                <p className="text-sm text-muted-foreground">Display current results to users before they vote</p>
              </div>
              <Switch
                checked={formData.show_results_before_vote}
                onCheckedChange={(checked) => setFormData({ ...formData, show_results_before_vote: checked })}
                disabled={isLoading}
              />
            </div>
          </div>

          {error && (
            <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md p-3">
              {error}
            </div>
          )}

          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Creating..." : "Create Poll"}
            </Button>
            <Button type="button" variant="outline" asChild disabled={isLoading}>
              <Link href="/voting">Cancel</Link>
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
