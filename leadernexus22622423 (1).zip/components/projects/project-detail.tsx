"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Calendar, MapPin, DollarSign, MessageSquare, TrendingUp, Edit, UserPlus } from "lucide-react"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"

interface ProjectDetailProps {
  project: any
  collaborators: any[]
  updates: any[]
  comments: any[]
  currentUserId: string
  isCollaborator: boolean
  isOwner: boolean
}

export default function ProjectDetail({
  project,
  collaborators,
  updates,
  comments,
  currentUserId,
  isCollaborator,
  isOwner,
}: ProjectDetailProps) {
  const router = useRouter()
  const [isJoining, setIsJoining] = useState(false)
  const [isAddingUpdate, setIsAddingUpdate] = useState(false)
  const [isAddingComment, setIsAddingComment] = useState(false)
  const [updateForm, setUpdateForm] = useState({
    title: "",
    content: "",
    update_type: "progress",
  })
  const [commentContent, setCommentContent] = useState("")

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/10 text-green-500"
      case "draft":
        return "bg-gray-500/10 text-gray-500"
      case "completed":
        return "bg-blue-500/10 text-blue-500"
      case "cancelled":
        return "bg-red-500/10 text-red-500"
      default:
        return "bg-gray-500/10 text-gray-500"
    }
  }

  const handleJoinProject = async () => {
    setIsJoining(true)
    const supabase = createClient()

    try {
      const { error } = await supabase.from("project_collaborators").insert({
        project_id: project.id,
        user_id: currentUserId,
        role: "supporter",
      })

      if (error) throw error

      toast({
        title: "Success!",
        description: "You've joined the project as a collaborator.",
      })

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsJoining(false)
    }
  }

  const handleAddUpdate = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsAddingUpdate(true)
    const supabase = createClient()

    try {
      const { error } = await supabase.from("project_updates").insert({
        project_id: project.id,
        author_id: currentUserId,
        title: updateForm.title,
        content: updateForm.content,
        update_type: updateForm.update_type,
      })

      if (error) throw error

      toast({
        title: "Update posted!",
        description: "Your project update has been published.",
      })

      setUpdateForm({ title: "", content: "", update_type: "progress" })
      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsAddingUpdate(false)
    }
  }

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsAddingComment(true)
    const supabase = createClient()

    try {
      const { error } = await supabase.from("project_comments").insert({
        project_id: project.id,
        author_id: currentUserId,
        content: commentContent,
      })

      if (error) throw error

      toast({
        title: "Comment added!",
        description: "Your comment has been posted.",
      })

      setCommentContent("")
      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsAddingComment(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button asChild variant="ghost" size="icon">
          <Link href="/projects">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold tracking-tight">{project.title}</h1>
        </div>
        {isOwner && (
          <Button variant="outline">
            <Edit className="mr-2 h-4 w-4" />
            Edit Project
          </Button>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Project Overview</CardTitle>
                <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold mb-2">Description</h3>
                <p className="text-muted-foreground whitespace-pre-wrap">{project.description}</p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                {project.category && (
                  <div>
                    <h3 className="font-semibold mb-2">Category</h3>
                    <Badge variant="outline">{project.category}</Badge>
                  </div>
                )}
                {project.target_region && (
                  <div className="flex items-start gap-2">
                    <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <h3 className="font-semibold">Region</h3>
                      <p className="text-sm text-muted-foreground">{project.target_region}</p>
                    </div>
                  </div>
                )}
                {project.start_date && (
                  <div className="flex items-start gap-2">
                    <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <h3 className="font-semibold">Start Date</h3>
                      <p className="text-sm text-muted-foreground">
                        {new Date(project.start_date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                )}
                {project.end_date && (
                  <div className="flex items-start gap-2">
                    <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <h3 className="font-semibold">End Date</h3>
                      <p className="text-sm text-muted-foreground">{new Date(project.end_date).toLocaleDateString()}</p>
                    </div>
                  </div>
                )}
                {project.budget && (
                  <div className="flex items-start gap-2">
                    <DollarSign className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <h3 className="font-semibold">Budget</h3>
                      <p className="text-sm text-muted-foreground">${project.budget.toLocaleString()}</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="updates" className="space-y-4">
            <TabsList>
              <TabsTrigger value="updates">Updates ({updates.length})</TabsTrigger>
              <TabsTrigger value="discussion">Discussion ({comments.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="updates" className="space-y-4">
              {(isOwner || isCollaborator) && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Post an Update</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleAddUpdate} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="update-title">Title</Label>
                        <Input
                          id="update-title"
                          placeholder="Update title"
                          value={updateForm.title}
                          onChange={(e) => setUpdateForm({ ...updateForm, title: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="update-type">Type</Label>
                        <Select
                          value={updateForm.update_type}
                          onValueChange={(value) => setUpdateForm({ ...updateForm, update_type: value })}
                        >
                          <SelectTrigger id="update-type">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="progress">Progress</SelectItem>
                            <SelectItem value="milestone">Milestone</SelectItem>
                            <SelectItem value="announcement">Announcement</SelectItem>
                            <SelectItem value="challenge">Challenge</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="update-content">Content</Label>
                        <Textarea
                          id="update-content"
                          placeholder="Share your progress or updates..."
                          rows={4}
                          value={updateForm.content}
                          onChange={(e) => setUpdateForm({ ...updateForm, content: e.target.value })}
                          required
                        />
                      </div>
                      <Button type="submit" disabled={isAddingUpdate}>
                        {isAddingUpdate ? "Posting..." : "Post Update"}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              )}

              {updates.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No updates yet</h3>
                    <p className="text-sm text-muted-foreground">Be the first to share progress!</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {updates.map((update: any) => (
                    <Card key={update.id}>
                      <CardHeader>
                        <div className="flex items-start justify-between gap-4">
                          <div className="space-y-1">
                            <CardTitle className="text-lg">{update.title}</CardTitle>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={update.author?.avatar_url || ""} />
                                <AvatarFallback>{update.author?.username?.charAt(0).toUpperCase()}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm text-muted-foreground">
                                {update.author?.full_name || update.author?.username}
                              </span>
                              <span className="text-sm text-muted-foreground">•</span>
                              <span className="text-sm text-muted-foreground">
                                {new Date(update.created_at).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                          <Badge variant="outline">{update.update_type}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground whitespace-pre-wrap">{update.content}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="discussion" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Add a Comment</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddComment} className="space-y-4">
                    <Textarea
                      placeholder="Share your thoughts or ask a question..."
                      rows={3}
                      value={commentContent}
                      onChange={(e) => setCommentContent(e.target.value)}
                      required
                    />
                    <Button type="submit" disabled={isAddingComment}>
                      {isAddingComment ? "Posting..." : "Post Comment"}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {comments.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No comments yet</h3>
                    <p className="text-sm text-muted-foreground">Start the discussion!</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {comments.map((comment: any) => (
                    <Card key={comment.id}>
                      <CardContent className="pt-6">
                        <div className="flex gap-4">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={comment.author?.avatar_url || ""} />
                            <AvatarFallback>{comment.author?.username?.charAt(0).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">
                                {comment.author?.full_name || comment.author?.username}
                              </span>
                              <span className="text-sm text-muted-foreground">
                                {new Date(comment.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{comment.content}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Project Leader</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={project.leader?.avatar_url || ""} />
                  <AvatarFallback>{project.leader?.username?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">{project.leader?.full_name || project.leader?.username}</p>
                  <p className="text-sm text-muted-foreground">{project.leader?.role}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Collaborators ({collaborators.length})</CardTitle>
                {!isCollaborator && !isOwner && (
                  <Button size="sm" onClick={handleJoinProject} disabled={isJoining}>
                    <UserPlus className="mr-2 h-4 w-4" />
                    {isJoining ? "Joining..." : "Join"}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {collaborators.map((collab: any) => (
                  <div key={collab.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={collab.user?.avatar_url || ""} />
                        <AvatarFallback>{collab.user?.username?.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{collab.user?.full_name || collab.user?.username}</p>
                        <p className="text-xs text-muted-foreground">{collab.role}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
