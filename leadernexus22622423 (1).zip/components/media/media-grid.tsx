"use client"

import Image from "next/image"
import { FileText, Play, Star, Eye, Download } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import type { MediaFile } from "@/lib/types/media.types"
import { format } from "date-fns"

interface MediaGridProps {
  media: MediaFile[]
  onMediaClick: (media: MediaFile) => void
}

export function MediaGrid({ media, onMediaClick }: MediaGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {media.map((item) => (
        <div
          key={item.id}
          onClick={() => onMediaClick(item)}
          className="group relative bg-card rounded-lg overflow-hidden border cursor-pointer hover:shadow-lg transition-shadow"
        >
          <div className="aspect-video relative bg-muted">
            {item.file_type === "image" && (
              <Image src={item.thumbnail_url || item.file_url} alt={item.title} fill className="object-cover" />
            )}
            {item.file_type === "video" && (
              <>
                <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                  <Play className="h-12 w-12 text-white" />
                </div>
                {item.thumbnail_url && (
                  <Image
                    src={item.thumbnail_url || "/placeholder.svg"}
                    alt={item.title}
                    fill
                    className="object-cover"
                  />
                )}
              </>
            )}
            {item.file_type === "document" && (
              <div className="absolute inset-0 flex items-center justify-center">
                <FileText className="h-12 w-12 text-muted-foreground" />
              </div>
            )}

            {item.is_featured && (
              <div className="absolute top-2 right-2">
                <Badge variant="default" className="bg-yellow-500">
                  <Star className="h-3 w-3 mr-1 fill-white" />
                  Tanlov
                </Badge>
              </div>
            )}
          </div>

          <div className="p-3 space-y-2">
            <h3 className="font-medium line-clamp-1">{item.title}</h3>
            {item.description && <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>}

            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Eye className="h-3 w-3" />
              <span>{item.view_count}</span>
              <Download className="h-3 w-3 ml-2" />
              <span>{item.download_count}</span>
            </div>

            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>{format(new Date(item.created_at), "dd.MM.yyyy")}</span>
              <Badge variant="secondary">{item.category}</Badge>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
