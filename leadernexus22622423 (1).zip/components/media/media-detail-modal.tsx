"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Download, Heart, MessageCircle, MapPin, Calendar, Users, Eye, Share2 } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"
import type { MediaFile } from "@/lib/types/media.types"
import { format } from "date-fns"
import Image from "next/image"
import { useToast } from "@/hooks/use-toast"

interface MediaDetailModalProps {
  media: MediaFile
  isOpen: boolean
  onClose: () => void
  userId?: string
}

export function MediaDetailModal({ media, isOpen, onClose, userId }: MediaDetailModalProps) {
  const { toast } = useToast()
  const [comments, setComments] = useState<any[]>([])
  const [likeCount, setLikeCount] = useState(0)
  const [isLiked, setIsLiked] = useState(false)
  const [newComment, setNewComment] = useState("")

  useEffect(() => {
    if (isOpen && media) {
      loadCommentsAndLikes()
      incrementViewCount()
    }
  }, [isOpen, media])

  const incrementViewCount = async () => {
    const supabase = createBrowserClient()
    await supabase
      .from("media_files")
      .update({ view_count: media.view_count + 1 })
      .eq("id", media.id)
  }

  const loadCommentsAndLikes = async () => {
    const supabase = createBrowserClient()

    // Load comments
    const { data: commentsData } = await supabase
      .from("media_comments")
      .select("*, profiles!user_id(full_name)")
      .eq("media_id", media.id)
      .order("created_at", { ascending: false })

    setComments(commentsData || [])

    // Load likes
    const { count } = await supabase
      .from("media_likes")
      .select("*", { count: "exact", head: true })
      .eq("media_id", media.id)

    setLikeCount(count || 0)

    if (userId) {
      const { data: userLike } = await supabase
        .from("media_likes")
        .select("id")
        .eq("media_id", media.id)
        .eq("user_id", userId)
        .single()

      setIsLiked(!!userLike)
    }
  }

  const handleLike = async () => {
    if (!userId) {
      toast({
        title: "Kirish talab qilinadi",
        description: "Yoqtirish uchun tizimga kiring",
        variant: "destructive",
      })
      return
    }

    const supabase = createBrowserClient()

    if (isLiked) {
      await supabase.from("media_likes").delete().eq("media_id", media.id).eq("user_id", userId)
      setIsLiked(false)
      setLikeCount((c) => c - 1)
    } else {
      await supabase.from("media_likes").insert({ media_id: media.id, user_id: userId })
      setIsLiked(true)
      setLikeCount((c) => c + 1)
    }
  }

  const handleAddComment = async () => {
    if (!userId) {
      toast({
        title: "Kirish talab qilinadi",
        description: "Izoh qoldirish uchun tizimga kiring",
        variant: "destructive",
      })
      return
    }

    if (!newComment.trim()) return

    const supabase = createBrowserClient()
    await supabase.from("media_comments").insert({
      media_id: media.id,
      user_id: userId,
      comment: newComment,
    })

    setNewComment("")
    loadCommentsAndLikes()
  }

  const handleDownload = async () => {
    const supabase = createBrowserClient()
    await supabase
      .from("media_files")
      .update({ download_count: media.download_count + 1 })
      .eq("id", media.id)

    window.open(media.file_url, "_blank")
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{media.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Media Display */}
          <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
            {media.file_type === "image" && (
              <Image src={media.file_url || "/placeholder.svg"} alt={media.title} fill className="object-contain" />
            )}
            {media.file_type === "video" && (
              <video src={media.file_url} controls className="w-full h-full">
                <track kind="captions" />
              </video>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={handleLike}>
              <Heart className={`h-4 w-4 mr-2 ${isLiked ? "fill-red-500 text-red-500" : ""}`} />
              {likeCount}
            </Button>
            <Button variant="outline" size="sm">
              <MessageCircle className="h-4 w-4 mr-2" />
              {comments.length}
            </Button>
            <Button variant="outline" size="sm">
              <Eye className="h-4 w-4 mr-2" />
              {media.view_count}
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownload}>
              <Download className="h-4 w-4 mr-2" />
              Yuklab olish
            </Button>
            <Button variant="outline" size="sm">
              <Share2 className="h-4 w-4 mr-2" />
              Ulashish
            </Button>
          </div>

          <Separator />

          {/* Details */}
          <div className="space-y-3">
            {media.description && <p className="text-sm">{media.description}</p>}

            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">{media.category}</Badge>
              {media.tags?.map((tag) => (
                <Badge key={tag} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              {media.event_date && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>{format(new Date(media.event_date), "dd.MM.yyyy")}</span>
                </div>
              )}
              {media.location && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{media.location}</span>
                </div>
              )}
              {media.participants_count && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="h-4 w-4" />
                  <span>{media.participants_count} ishtirokchi</span>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Comments */}
          <div className="space-y-4">
            <h3 className="font-semibold">Izohlar ({comments.length})</h3>

            {userId && (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Izoh qoldiring..."
                  className="flex-1 px-3 py-2 border rounded-md"
                  onKeyDown={(e) => e.key === "Enter" && handleAddComment()}
                />
                <Button onClick={handleAddComment}>Yuborish</Button>
              </div>
            )}

            <div className="space-y-3">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{comment.profiles?.full_name?.[0] || "U"}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{comment.profiles?.full_name || "Foydalanuvchi"}</p>
                    <p className="text-sm text-muted-foreground">{comment.comment}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {format(new Date(comment.created_at), "dd.MM.yyyy HH:mm")}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
