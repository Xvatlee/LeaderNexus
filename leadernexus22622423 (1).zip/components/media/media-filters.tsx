"use client"

import type React from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Search, Filter, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"
import { useTranslations } from "@/lib/i18n/use-translations"

interface MediaFiltersProps {
  districts: Array<{ id: string; name: string }>
  directions: Array<{ id: string; name: string }>
  searchParams: { [key: string]: string | string[] | undefined }
}

export function MediaFilters({ districts, directions, searchParams }: MediaFiltersProps) {
  const router = useRouter()
  const params = useSearchParams()
  const { t } = useTranslations()
  const [searchQuery, setSearchQuery] = useState(params.get("search") || "")
  const [showFilters, setShowFilters] = useState(false)

  const updateFilter = (key: string, value: string) => {
    const newParams = new URLSearchParams(params.toString())
    if (value) {
      newParams.set(key, value)
    } else {
      newParams.delete(key)
    }
    router.push(`/media?${newParams.toString()}`)
  }

  const clearFilters = () => {
    setSearchQuery("")
    router.push("/media")
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    updateFilter("search", searchQuery)
  }

  const activeFiltersCount = Object.keys(searchParams).filter((key) => key !== "search").length

  return (
    <div className="space-y-4">
      <div className="flex gap-4">
        <form onSubmit={handleSearch} className="flex-1 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder={t("media.search", "Search...")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button type="submit">{t("media.searchButton", "Search")}</Button>
        </form>

        <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
          <Filter className="mr-2 h-4 w-4" />
          {t("media.filters", "Filters")}
          {activeFiltersCount > 0 && (
            <span className="ml-2 bg-primary text-primary-foreground rounded-full px-2 py-0.5 text-xs">
              {activeFiltersCount}
            </span>
          )}
        </Button>

        {activeFiltersCount > 0 && (
          <Button variant="ghost" onClick={clearFilters}>
            <X className="mr-2 h-4 w-4" />
            {t("media.clearFilters", "Clear")}
          </Button>
        )}
      </div>

      {showFilters && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-muted/50 rounded-lg">
          <div className="space-y-2">
            <label className="text-sm font-medium">{t("media.type", "Type")}</label>
            <Select
              value={params.get("type") || "all"}
              onValueChange={(value) => updateFilter("type", value === "all" ? "" : value)}
            >
              <SelectTrigger>
                <SelectValue placeholder={t("common.all", "All")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all", "All")}</SelectItem>
                <SelectItem value="image">{t("media.types.image", "Image")}</SelectItem>
                <SelectItem value="video">{t("media.types.video", "Video")}</SelectItem>
                <SelectItem value="document">{t("media.types.document", "Document")}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">{t("media.category", "Category")}</label>
            <Select
              value={params.get("category") || "all"}
              onValueChange={(value) => updateFilter("category", value === "all" ? "" : value)}
            >
              <SelectTrigger>
                <SelectValue placeholder={t("common.all", "All")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all", "All")}</SelectItem>
                <SelectItem value="event">{t("media.categories.event", "Event")}</SelectItem>
                <SelectItem value="project">{t("media.categories.project", "Project")}</SelectItem>
                <SelectItem value="achievement">{t("media.categories.achievement", "Achievement")}</SelectItem>
                <SelectItem value="training">{t("media.categories.training", "Training")}</SelectItem>
                <SelectItem value="meeting">{t("media.categories.meeting", "Meeting")}</SelectItem>
                <SelectItem value="other">{t("media.categories.other", "Other")}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">{t("media.district", "District")}</label>
            <Select
              value={params.get("district") || "all"}
              onValueChange={(value) => updateFilter("district", value === "all" ? "" : value)}
            >
              <SelectTrigger>
                <SelectValue placeholder={t("common.all", "All")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all", "All")}</SelectItem>
                {districts.map((district) => (
                  <SelectItem key={district.id} value={district.id}>
                    {district.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">{t("media.direction", "Direction")}</label>
            <Select
              value={params.get("direction") || "all"}
              onValueChange={(value) => updateFilter("direction", value === "all" ? "" : value)}
            >
              <SelectTrigger>
                <SelectValue placeholder={t("common.all", "All")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("common.all", "All")}</SelectItem>
                {directions.map((direction) => (
                  <SelectItem key={direction.id} value={direction.id}>
                    {direction.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      )}
    </div>
  )
}
