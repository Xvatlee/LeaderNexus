"use client"

import { useEffect, useState } from "react"
import { createBrowserClient } from "@/lib/supabase/client"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function MediaSetupCheck() {
  const [isChecking, setIsChecking] = useState(true)
  const [hasStorageBucket, setHasStorageBucket] = useState(false)
  const [hasMediaTable, setHasMediaTable] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    checkSetup()
  }, [])

  const checkSetup = async () => {
    try {
      const supabase = createBrowserClient()

      // Check if storage bucket exists
      const { data: buckets, error: bucketError } = await supabase.storage.listBuckets()

      if (!bucketError && buckets) {
        const mediaBucket = buckets.find((b) => b.name === "media-files")
        setHasStorageBucket(!!mediaBucket)
      }

      // Check if media_files table exists
      const { error: tableError } = await supabase.from("media_files").select("id").limit(1)

      setHasMediaTable(!tableError)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Setup check failed")
    } finally {
      setIsChecking(false)
    }
  }

  if (isChecking) {
    return (
      <Alert>
        <Loader2 className="h-4 w-4 animate-spin" />
        <AlertTitle>Checking media setup...</AlertTitle>
      </Alert>
    )
  }

  if (!hasStorageBucket || !hasMediaTable) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Media System Not Configured</AlertTitle>
        <AlertDescription className="mt-2 space-y-2">
          <p>The media system requires additional database setup:</p>
          <ul className="list-disc list-inside space-y-1 text-sm">
            {!hasStorageBucket && <li>Storage bucket "media-files" not found (run script 018)</li>}
            {!hasMediaTable && <li>Media tables not created (run scripts 020, 021)</li>}
          </ul>
          <div className="mt-4">
            <Button asChild>
              <Link href="/setup">Go to Setup Page</Link>
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <Alert className="bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800">
      <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
      <AlertTitle className="text-green-800 dark:text-green-200">Media System Ready</AlertTitle>
      <AlertDescription className="text-green-700 dark:text-green-300">
        All required tables and storage buckets are configured.
      </AlertDescription>
    </Alert>
  )
}
