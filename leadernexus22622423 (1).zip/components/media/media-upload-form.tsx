"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Upload, X, FileText, ImageIcon, Video, AlertCircle, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { createBrowserClient } from "@/lib/supabase/client"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { useTranslations } from "@/lib/i18n/use-translations"
import type { MediaCategory, MediaVisibility } from "@/lib/types/media.types"

interface MediaUploadFormProps {
  profile: any
  districts: Array<{ id: string; name: string }>
  directions: Array<{ id: string; name: string }>
}

const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"]
const ALLOWED_VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime", "video/x-msvideo"]
const ALLOWED_DOCUMENT_TYPES = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
]
const MAX_FILE_SIZE = 50 * 1024 * 1024 // 50MB

export function MediaUploadForm({ profile, districts, directions }: MediaUploadFormProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { t } = useTranslations()
  const [isLoading, setIsLoading] = useState(false)
  const [files, setFiles] = useState<File[]>([])
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({})
  const [uploadErrors, setUploadErrors] = useState<string[]>([])

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "event" as MediaCategory,
    visibility: "public" as MediaVisibility,
    tags: "",
    event_date: "",
    location: "",
    participants_count: "",
    district_id: profile?.district || profile?.district_id || "",
    direction_id: profile?.direction || profile?.direction_id || "",
  })

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    console.log("[v0] Validating file:", file.name, "Type:", file.type, "Size:", file.size)

    // Check file size
    if (file.size > MAX_FILE_SIZE) {
      return {
        valid: false,
        error: t("media.fileSizeError", `${file.name} ${t("media.exceeds50MB", "exceeds 50MB limit")}`),
      }
    }

    // Check file type
    const allAllowedTypes = [...ALLOWED_IMAGE_TYPES, ...ALLOWED_VIDEO_TYPES, ...ALLOWED_DOCUMENT_TYPES]
    if (!allAllowedTypes.includes(file.type)) {
      return {
        valid: false,
        error: t(
          "media.fileTypeError",
          `${file.name} ${t("media.unsupportedFileType", "is not a supported file type")}`,
        ),
      }
    }

    return { valid: true }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    console.log("[v0] File selection triggered")
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files)
      console.log("[v0] Selected files:", selectedFiles.length)

      const errors: string[] = []
      const validFiles: File[] = []

      selectedFiles.forEach((file) => {
        const validation = validateFile(file)
        if (validation.valid) {
          validFiles.push(file)
        } else if (validation.error) {
          errors.push(validation.error)
        }
      })

      if (errors.length > 0) {
        setUploadErrors(errors)
        toast({
          title: t("media.validationError", "Validation Error"),
          description: errors.join(", "),
          variant: "destructive",
        })
      } else {
        setUploadErrors([])
      }

      if (validFiles.length > 0) {
        setFiles((prev) => [...prev, ...validFiles])
        console.log("[v0] Valid files added:", validFiles.length)
        toast({
          title: t("media.filesSelected", "Files Selected"),
          description: t("media.filesSelectedDesc", `${validFiles.length} file(s) ready to upload`),
        })
      }
    }
  }

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
    console.log("[v0] File removed at index:", index)
  }

  const getFileType = (file: File): "image" | "video" | "document" => {
    if (ALLOWED_IMAGE_TYPES.includes(file.type)) return "image"
    if (ALLOWED_VIDEO_TYPES.includes(file.type)) return "video"
    return "document"
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Form submission started")

    if (files.length === 0) {
      toast({
        title: t("media.noFilesSelected", "No Files Selected"),
        description: t("media.selectAtLeastOne", "Please select at least one file"),
        variant: "destructive",
      })
      return
    }

    if (!formData.title.trim()) {
      toast({
        title: t("media.titleRequired", "Title Required"),
        description: t("media.enterTitle", "Please enter a title for your media"),
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    setUploadErrors([])
    const errors: string[] = []

    try {
      const supabase = createBrowserClient()
      const uploadedMedia = []

      for (let i = 0; i < files.length; i++) {
        const file = files[i]

        try {
          console.log("[v0] Uploading file:", file.name)
          // Update progress
          setUploadProgress((prev) => ({ ...prev, [file.name]: 10 }))

          const formDataBlob = new FormData()
          formDataBlob.append("file", file)

          setUploadProgress((prev) => ({ ...prev, [file.name]: 30 }))

          const uploadResponse = await fetch("/api/media/upload", {
            method: "POST",
            body: formDataBlob,
          })

          setUploadProgress((prev) => ({ ...prev, [file.name]: 60 }))

          if (!uploadResponse.ok) {
            const errorData = await uploadResponse.json()
            console.error("[v0] Upload failed:", errorData)
            throw new Error(errorData.error || "Upload failed")
          }

          const { url, downloadUrl } = await uploadResponse.json()
          console.log("[v0] File uploaded successfully:", url)

          // Save to database
          const tagsArray = formData.tags
            .split(",")
            .map((t) => t.trim())
            .filter(Boolean)

          setUploadProgress((prev) => ({ ...prev, [file.name]: 80 }))

          const { data, error } = await supabase
            .from("media_files")
            .insert({
              title: formData.title || file.name,
              description: formData.description || null,
              file_url: url,
              file_type: getFileType(file),
              file_size: file.size,
              mime_type: file.type,
              category: formData.category,
              visibility: formData.visibility,
              tags: tagsArray.length > 0 ? tagsArray : null,
              event_date: formData.event_date || null,
              location: formData.location || null,
              participants_count: formData.participants_count ? Number.parseInt(formData.participants_count) : null,
              district_id: formData.district_id || null,
              direction_id: formData.direction_id || null,
              status: "pending",
            })
            .select()
            .single()

          if (error) {
            console.error("[v0] Database insert failed:", error)
            throw new Error(error.message || "Database error")
          }

          console.log("[v0] Media record created:", data.id)
          uploadedMedia.push(data)
          setUploadProgress((prev) => ({ ...prev, [file.name]: 100 }))
        } catch (fileError) {
          const errorMessage = fileError instanceof Error ? fileError.message : "Upload failed"
          console.error("[v0] File upload error:", errorMessage)
          errors.push(`${file.name}: ${errorMessage}`)
          // Remove failed file from progress
          setUploadProgress((prev) => {
            const newProgress = { ...prev }
            delete newProgress[file.name]
            return newProgress
          })
        }
      }

      if (uploadedMedia.length > 0) {
        toast({
          title: t("media.uploadSuccess", "Upload Successful!"),
          description: t(
            "media.uploadSuccessDesc",
            `${uploadedMedia.length} file(s) uploaded and submitted for approval`,
          ),
        })

        // Reset form
        setFiles([])
        setFormData({
          title: "",
          description: "",
          category: "event" as MediaCategory,
          visibility: "public" as MediaVisibility,
          tags: "",
          event_date: "",
          location: "",
          participants_count: "",
          district_id: profile?.district || profile?.district_id || "",
          direction_id: profile?.direction || profile?.direction_id || "",
        })

        // Navigate after short delay to show success message
        setTimeout(() => {
          router.push("/media")
          router.refresh()
        }, 1500)
      }

      if (errors.length > 0) {
        setUploadErrors(errors)
        toast({
          title: t("media.partialUploadError", "Some Files Failed"),
          description: t(
            "media.partialUploadErrorDesc",
            `${errors.length} file(s) failed to upload. Check errors below.`,
          ),
          variant: "destructive",
        })
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An error occurred while uploading files"
      toast({
        title: t("media.uploadError", "Upload Error"),
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
      setUploadProgress({})
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {uploadErrors.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <ul className="list-disc list-inside space-y-1">
              {uploadErrors.map((error, i) => (
                <li key={i}>{error}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>{t("media.selectFiles", "Select Files")}</CardTitle>
          <CardDescription>
            {t("media.uploadDescription", "Upload images, videos or documents (max 50MB per file)")}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover:border-muted-foreground/50 transition-colors">
            <input
              type="file"
              id="file-upload"
              multiple
              accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx"
              onChange={handleFileSelect}
              className="hidden"
              disabled={isLoading}
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
              <p className="mt-2 text-sm font-medium">{t("media.clickToUpload", "Click to upload or drag and drop")}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {t("media.supportedFormats", "Images, Videos, PDF, Word, Excel")}
              </p>
              <p className="text-xs text-muted-foreground mt-1">{t("media.maxSize", "Maximum file size: 50MB")}</p>
            </label>
          </div>

          {files.length > 0 && (
            <div className="space-y-2">
              <Label>
                {t("media.selectedFiles", "Selected Files")} ({files.length})
              </Label>
              <div className="space-y-2">
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-3 flex-1">
                      {file.type.startsWith("image/") && <ImageIcon className="h-5 w-5 text-blue-500 flex-shrink-0" />}
                      {file.type.startsWith("video/") && <Video className="h-5 w-5 text-purple-500 flex-shrink-0" />}
                      {!file.type.startsWith("image/") && !file.type.startsWith("video/") && (
                        <FileText className="h-5 w-5 text-orange-500 flex-shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                        {uploadProgress[file.name] !== undefined && (
                          <div className="mt-2">
                            <Progress value={uploadProgress[file.name]} className="h-1" />
                            <p className="text-xs text-muted-foreground mt-1">
                              {uploadProgress[file.name] === 100 ? (
                                <span className="flex items-center gap-1 text-green-600">
                                  <CheckCircle2 className="h-3 w-3" />
                                  {t("media.uploaded", "Uploaded")}
                                </span>
                              ) : (
                                `${uploadProgress[file.name]}%`
                              )}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(index)}
                      disabled={isLoading}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("media.information", "Information")}</CardTitle>
          <CardDescription>{t("media.enterFileInfo", "Enter information about the file")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">{t("media.title", "Title")} *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder={t("media.enterTitle", "Enter file title")}
              required
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">{t("media.description", "Description")}</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder={t("media.enterDescription", "Detailed information about the file")}
              rows={4}
              disabled={isLoading}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">{t("media.category", "Category")} *</Label>
              <Select
                value={formData.category}
                onValueChange={(value: MediaCategory) => setFormData({ ...formData, category: value })}
                disabled={isLoading}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="event">{t("media.categories.event", "Event")}</SelectItem>
                  <SelectItem value="project">{t("media.categories.project", "Project")}</SelectItem>
                  <SelectItem value="achievement">{t("media.categories.achievement", "Achievement")}</SelectItem>
                  <SelectItem value="training">{t("media.categories.training", "Training")}</SelectItem>
                  <SelectItem value="meeting">{t("media.categories.meeting", "Meeting")}</SelectItem>
                  <SelectItem value="other">{t("media.categories.other", "Other")}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="visibility">{t("media.visibility", "Visibility")} *</Label>
              <Select
                value={formData.visibility}
                onValueChange={(value: MediaVisibility) => setFormData({ ...formData, visibility: value })}
                disabled={isLoading}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">{t("media.visibilityOptions.public", "Public")}</SelectItem>
                  <SelectItem value="district">{t("media.visibilityOptions.district", "District Only")}</SelectItem>
                  <SelectItem value="direction">{t("media.visibilityOptions.direction", "Direction Only")}</SelectItem>
                  <SelectItem value="private">{t("media.visibilityOptions.private", "Private")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">{t("media.tags", "Tags")}</Label>
            <Input
              id="tags"
              value={formData.tags}
              onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
              placeholder={t("media.tagsPlaceholder", "Separate tags with commas")}
              disabled={isLoading}
            />
            <p className="text-xs text-muted-foreground">{t("media.tagsExample", "Example: youth, sports, culture")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="event_date">{t("media.eventDate", "Event Date")}</Label>
              <Input
                id="event_date"
                type="date"
                value={formData.event_date}
                onChange={(e) => setFormData({ ...formData, event_date: e.target.value })}
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">{t("media.location", "Location")}</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder={t("media.locationPlaceholder", "Event location")}
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="participants_count">{t("media.participants", "Participants")}</Label>
              <Input
                id="participants_count"
                type="number"
                value={formData.participants_count}
                onChange={(e) => setFormData({ ...formData, participants_count: e.target.value })}
                placeholder="0"
                min="0"
                disabled={isLoading}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-4">
        <Button type="button" variant="outline" onClick={() => router.back()} disabled={isLoading}>
          {t("common.cancel", "Cancel")}
        </Button>
        <Button type="submit" disabled={isLoading || files.length === 0}>
          {isLoading ? t("media.uploading", "Uploading...") : t("media.upload", "Upload")}
        </Button>
      </div>
    </form>
  )
}
