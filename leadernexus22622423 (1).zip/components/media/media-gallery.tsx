"use client"

import { useState, useEffect } from "react"
import { createBrowserClient } from "@/lib/supabase/client"
import { MediaFilters } from "./media-filters"
import { MediaGrid } from "./media-grid"
import { MediaDetailModal } from "./media-detail-modal"
import type { MediaFile } from "@/lib/types/media.types"
import { Loader2 } from "lucide-react"
import { useTranslations } from "@/lib/i18n/use-translations"

interface MediaGalleryProps {
  searchParams: { [key: string]: string | string[] | undefined }
  districts: Array<{ id: string; name: string }>
  directions: Array<{ id: string; name: string }>
  userId?: string
}

export function MediaGallery({ searchParams, districts, directions, userId }: MediaGalleryProps) {
  const { t } = useTranslations()
  const [media, setMedia] = useState<MediaFile[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedMedia, setSelectedMedia] = useState<MediaFile | null>(null)
  const [totalCount, setTotalCount] = useState(0)
  const [page, setPage] = useState(1)
  const itemsPerPage = 12

  const loadMedia = async () => {
    setIsLoading(true)
    const supabase = createBrowserClient()

    try {
      let query = supabase
        .from("media_files")
        .select("*, districts(name), directions(name), profiles!uploaded_by(full_name)", { count: "exact" })
        .eq("status", "approved")
        .order("created_at", { ascending: false })

      // Apply filters from searchParams
      if (searchParams.type) {
        query = query.eq("file_type", searchParams.type)
      }
      if (searchParams.category) {
        query = query.eq("category", searchParams.category)
      }
      if (searchParams.district) {
        query = query.eq("district_id", searchParams.district)
      }
      if (searchParams.direction) {
        query = query.eq("direction_id", searchParams.direction)
      }
      if (searchParams.featured === "true") {
        query = query.eq("is_featured", true)
      }
      if (searchParams.search) {
        query = query.or(
          `title.ilike.%${searchParams.search}%,description.ilike.%${searchParams.search}%,tags.cs.{${searchParams.search}}`,
        )
      }

      // Pagination
      const from = (page - 1) * itemsPerPage
      const to = from + itemsPerPage - 1
      query = query.range(from, to)

      const { data, error, count } = await query

      if (error) throw error

      setMedia((data as any) || [])
      setTotalCount(count || 0)
    } catch (error) {
      console.error("[v0] Error loading media:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadMedia()
  }, [searchParams, page])

  const totalPages = Math.ceil(totalCount / itemsPerPage)

  return (
    <div className="space-y-6">
      <MediaFilters districts={districts} directions={directions} searchParams={searchParams} />

      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : media.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">{t("media.noMediaFound", "No media found")}</p>
        </div>
      ) : (
        <>
          <div className="text-sm text-muted-foreground mb-4">
            {t("media.resultsFound", `Total ${totalCount} results found`)}
          </div>
          <MediaGrid media={media} onMediaClick={setSelectedMedia} />

          {totalPages > 1 && (
            <div className="flex justify-center gap-2 mt-8">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-4 py-2 border rounded-md disabled:opacity-50 hover:bg-muted transition-colors"
              >
                {t("common.previous", "Previous")}
              </button>
              <span className="px-4 py-2">
                {page} / {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="px-4 py-2 border rounded-md disabled:opacity-50 hover:bg-muted transition-colors"
              >
                {t("common.next", "Next")}
              </button>
            </div>
          )}
        </>
      )}

      {selectedMedia && (
        <MediaDetailModal
          media={selectedMedia}
          isOpen={!!selectedMedia}
          onClose={() => setSelectedMedia(null)}
          userId={userId}
        />
      )}
    </div>
  )
}
