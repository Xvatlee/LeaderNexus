"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { ThumbsUp, MessageSquare } from "lucide-react"
import type { Post } from "@/lib/types"

interface PostActionsProps {
  post: Post
  userId: string
  hasLiked: boolean
}

export default function PostActions({ post, userId, hasLiked }: PostActionsProps) {
  const router = useRouter()
  const [liked, setLiked] = useState(hasLiked)
  const [likes, setLikes] = useState(post.likes)
  const [isLoading, setIsLoading] = useState(false)

  const handleLike = async () => {
    if (isLoading) return
    setIsLoading(true)

    const supabase = createClient()

    try {
      if (liked) {
        // Unlike
        await supabase.from("post_likes").delete().eq("post_id", post.id).eq("user_id", userId)
        setLikes(likes - 1)
        setLiked(false)
      } else {
        // Like
        await supabase.from("post_likes").insert({ post_id: post.id, user_id: userId })
        setLikes(likes + 1)
        setLiked(true)
      }
      router.refresh()
    } catch (error) {
      console.error("[v0] Error toggling like:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex items-center gap-4 pt-4 border-t">
      <Button
        variant={liked ? "default" : "outline"}
        size="sm"
        onClick={handleLike}
        disabled={isLoading}
        className={liked ? "bg-accent" : "bg-transparent"}
      >
        <ThumbsUp className={`mr-2 h-4 w-4 ${liked ? "fill-current" : ""}`} />
        {likes} {likes === 1 ? "Like" : "Likes"}
      </Button>
      <Button variant="outline" size="sm" className="bg-transparent">
        <MessageSquare className="mr-2 h-4 w-4" />
        {post.comments_count} {post.comments_count === 1 ? "Comment" : "Comments"}
      </Button>
    </div>
  )
}
