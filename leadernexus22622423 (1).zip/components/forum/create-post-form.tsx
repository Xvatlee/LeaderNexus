"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface CreatePostFormProps {
  userId: string
}

export default function CreatePostForm({ userId }: CreatePostFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: "general",
  })

  const categories = [
    { value: "general", label: "General" },
    { value: "leadership", label: "Leadership" },
    { value: "technology", label: "Technology" },
    { value: "discussion", label: "Discussion" },
    { value: "help", label: "Help" },
    { value: "announcements", label: "Announcements" },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const supabase = createClient()

    try {
      const { data, error } = await supabase
        .from("posts")
        .insert({
          author_id: userId,
          title: formData.title,
          content: formData.content,
          category: formData.category,
        })
        .select()
        .single()

      if (error) throw error

      if (!data || !data.id) {
        throw new Error("Post yaratildi lekin ID qaytmadi")
      }

      // Award points for creating a post (ignore errors)
      await supabase
        .rpc("increment_user_points", {
          user_id: userId,
          points: 10,
        })
        .catch(() => {
          // Ignore RPC errors - points are not critical
        })

      const postId = data.id
      router.push(`/forum/post/${postId}`)
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Xatolik yuz berdi. Iltimos qayta urinib ko'ring.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost" size="icon">
            <Link href="/forum">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <CardTitle>Yangi post</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Sarlavha</Label>
            <Input
              id="title"
              placeholder="Nimani muhokama qilmoqchisiz?"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Kategoriya</Label>
            <Select
              value={formData.category}
              onValueChange={(value) => setFormData({ ...formData, category: value })}
              disabled={isLoading}
            >
              <SelectTrigger id="category">
                <SelectValue placeholder="Kategoriyani tanlang" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Matn</Label>
            <Textarea
              id="content"
              placeholder="Fikrlaringizni yozing, savol bering yoki muhokama boshlang..."
              required
              rows={10}
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              disabled={isLoading}
            />
          </div>

          {error && (
            <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md p-3">
              {error}
            </div>
          )}

          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Yuklanmoqda..." : "E'lon qilish"}
            </Button>
            <Button type="button" variant="outline" asChild disabled={isLoading}>
              <Link href="/forum">Bekor qilish</Link>
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
