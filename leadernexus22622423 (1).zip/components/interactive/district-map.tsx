"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface District {
  id: string
  name: string
  performance: number
  leadersCount: number
  projectsCount: number
}

interface DistrictMapProps {
  districts?: District[]
  selectedDistrict?: string | null
  onDistrictSelect?: (districtId: string) => void
}

export function DistrictMap({ 
  districts = [], 
  selectedDistrict = null, 
  onDistrictSelect 
}: DistrictMapProps) {
  const getPerformanceColor = (performance: number) => {
    if (performance >= 80) return "bg-green-500"
    if (performance >= 60) return "bg-yellow-500"
    if (performance >= 40) return "bg-orange-500"
    return "bg-red-500"
  }

  const getPerformanceBadge = (performance: number) => {
    if (performance >= 80) return "default"
    if (performance >= 60) return "secondary"
    return "destructive"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Tumanlar xaritasi</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {districts.length === 0 ? (
            <div className="col-span-full text-center text-muted-foreground py-8">
              Tumanlar mavjud emas
            </div>
          ) : (
            districts.map((district) => (
              <div
                key={district.id}
                onClick={() => onDistrictSelect?.(district.id)}
                className={`
                  p-4 rounded-lg border cursor-pointer transition-all
                  hover:shadow-md hover:border-primary
                  ${selectedDistrict === district.id ? 'border-primary ring-2 ring-primary/20' : 'border-border'}
                `}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-3 h-3 rounded-full ${getPerformanceColor(district.performance)}`} />
                  <h4 className="font-medium text-sm truncate">{district.name}</h4>
                </div>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Samaradorlik:</span>
                    <Badge variant={getPerformanceBadge(district.performance)} className="text-xs">
                      {district.performance}%
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Liderlar:</span>
                    <span>{district.leadersCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Loyihalar:</span>
                    <span>{district.projectsCount}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
