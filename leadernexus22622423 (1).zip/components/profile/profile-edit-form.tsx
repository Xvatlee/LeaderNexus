"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Profile, District, Direction } from "@/lib/types"
import { ArrowLeft, AlertCircle } from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface ProfileEditFormProps {
  profile: Profile | null
}

export default function ProfileEditForm({ profile }: ProfileEditFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [districts, setDistricts] = useState<District[]>([])
  const [directions, setDirections] = useState<Direction[]>([])
  const [isCheckingAvailability, setIsCheckingAvailability] = useState(false)
  const [directionAvailability, setDirectionAvailability] = useState<{
    available: boolean
    message?: string
  } | null>(null)

  const [formData, setFormData] = useState({
    username: profile?.username || "",
    full_name: profile?.full_name || "",
    avatar_url: profile?.avatar_url || "",
    district: profile?.district || "",
    direction: profile?.direction || "",
  })

  useEffect(() => {
    const fetchOptions = async () => {
      const supabase = createClient()

      const [districtsResult, directionsResult] = await Promise.all([
        supabase.from("districts").select("*").eq("is_active", true).order("name"),
        supabase.from("directions").select("*").eq("is_active", true).order("name"),
      ])

      if (districtsResult.data) setDistricts(districtsResult.data)
      if (directionsResult.data) setDirections(directionsResult.data)
    }

    fetchOptions()
  }, [])

  useEffect(() => {
    const checkAvailability = async () => {
      if (
        !formData.district ||
        !formData.direction ||
        profile?.role !== "leader" ||
        (formData.district === profile.district && formData.direction === profile.direction)
      ) {
        setDirectionAvailability(null)
        return
      }

      setIsCheckingAvailability(true)
      try {
        const response = await fetch("/api/check-direction-availability", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ district: formData.district, direction: formData.direction }),
        })

        const data = await response.json()
        setDirectionAvailability(data)
      } catch (error) {
        console.error("Error checking availability:", error)
      } finally {
        setIsCheckingAvailability(false)
      }
    }

    checkAvailability()
  }, [formData.district, formData.direction, profile?.role, profile?.district, profile?.direction])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)
    setSuccess(false)

    if (profile?.role === "leader") {
      if (!formData.district || !formData.direction) {
        setError("Tuman va yo'nalishni tanlang")
        setIsLoading(false)
        return
      }

      if (
        directionAvailability &&
        !directionAvailability.available &&
        (formData.district !== profile.district || formData.direction !== profile.direction)
      ) {
        setError(directionAvailability.message || "Bu yo'nalish allaqachon band qilingan")
        setIsLoading(false)
        return
      }
    }

    const supabase = createClient()

    try {
      const updateData: any = {
        username: formData.username,
        full_name: formData.full_name,
        avatar_url: formData.avatar_url,
      }

      if (profile?.role === "leader") {
        updateData.district = formData.district
        updateData.direction = formData.direction
      }

      const { error } = await supabase.from("profiles").update(updateData).eq("id", profile?.id)

      if (error) throw error

      setSuccess(true)
      setTimeout(() => {
        router.push("/profile")
        router.refresh()
      }, 1500)
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost" size="icon">
            <Link href="/profile">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription>Update your profile details</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex items-center gap-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={formData.avatar_url || "/placeholder.svg"} />
              <AvatarFallback className="text-2xl">{formData.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
            </Avatar>
            <div className="space-y-2">
              <Label htmlFor="avatar_url">Avatar URL</Label>
              <Input
                id="avatar_url"
                placeholder="https://example.com/avatar.jpg"
                value={formData.avatar_url}
                onChange={(e) => setFormData({ ...formData, avatar_url: e.target.value })}
                disabled={isLoading}
              />
              <p className="text-xs text-muted-foreground">Enter a URL to your profile picture</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              placeholder="johndoe"
              required
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="full_name">Full Name</Label>
            <Input
              id="full_name"
              placeholder="John Doe"
              value={formData.full_name}
              onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
              disabled={isLoading}
            />
          </div>

          {profile?.role === "leader" && (
            <>
              <div className="space-y-2">
                <Label htmlFor="district">Tuman (District)</Label>
                <Select
                  value={formData.district}
                  onValueChange={(value) => setFormData({ ...formData, district: value })}
                  disabled={isLoading}
                >
                  <SelectTrigger id="district">
                    <SelectValue placeholder="Tumanni tanlang" />
                  </SelectTrigger>
                  <SelectContent>
                    {districts.map((d) => (
                      <SelectItem key={d.id} value={d.name}>
                        {d.name} {d.region && `(${d.region})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="direction">Yo'nalish (Direction)</Label>
                <Select
                  value={formData.direction}
                  onValueChange={(value) => setFormData({ ...formData, direction: value })}
                  disabled={isLoading || !formData.district}
                >
                  <SelectTrigger id="direction">
                    <SelectValue placeholder="Yo'nalishni tanlang" />
                  </SelectTrigger>
                  <SelectContent>
                    {directions.map((d) => (
                      <SelectItem key={d.id} value={d.name}>
                        {d.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!formData.district && <p className="text-xs text-muted-foreground">Avval tumanni tanlang</p>}
              </div>

              {isCheckingAvailability && formData.district && formData.direction && (
                <Alert>
                  <AlertDescription className="text-sm">Yo'nalish mavjudligini tekshirmoqda...</AlertDescription>
                </Alert>
              )}

              {directionAvailability && !directionAvailability.available && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-sm">{directionAvailability.message}</AlertDescription>
                </Alert>
              )}

              {directionAvailability && directionAvailability.available && (
                <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
                  <AlertDescription className="text-sm text-green-700 dark:text-green-300">
                    Bu yo'nalish mavjud!
                  </AlertDescription>
                </Alert>
              )}
            </>
          )}

          {error && (
            <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md p-3">
              {error}
            </div>
          )}

          {success && (
            <div className="text-sm text-accent bg-accent/10 border border-accent/20 rounded-md p-3">
              Profile updated successfully! Redirecting...
            </div>
          )}

          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading || (directionAvailability && !directionAvailability.available)}>
              {isLoading ? "Saving..." : "Save Changes"}
            </Button>
            <Button type="button" variant="outline" asChild disabled={isLoading}>
              <Link href="/profile">Cancel</Link>
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
