"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, AlertCircle } from "lucide-react"

interface AdminRequest {
  id: string
  user_id: string
  reason: string | null
  status: string
  profiles: {
    username: string
    full_name: string
    email: string
  }
}

interface AdminRequestApprovalDialogProps {
  request: AdminRequest
  actionType: "approve" | "reject"
  onClose: () => void
  onSuccess: () => void
}

export function AdminRequestApprovalDialog({
  request,
  actionType,
  onClose,
  onSuccess,
}: AdminRequestApprovalDialogProps) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [rejectionReason, setRejectionReason] = useState("")

  const handleSubmit = async () => {
    if (actionType === "reject" && !rejectionReason.trim()) {
      setError("Please provide a reason for rejection")
      return
    }

    setLoading(true)
    setError(null)

    try {
      const endpoint = `/api/admin-requests/${request.id}/${actionType}`
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(actionType === "reject" ? { reason: rejectionReason } : {}),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || `Failed to ${actionType} request`)
      }

      onSuccess()
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{actionType === "approve" ? "Approve Admin Request" : "Reject Admin Request"}</DialogTitle>
          <DialogDescription>
            {actionType === "approve"
              ? `Are you sure you want to grant admin privileges to ${request.profiles.full_name || request.profiles.username}?`
              : `Please provide a reason for rejecting this admin request from ${request.profiles.full_name || request.profiles.username}.`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {actionType === "reject" && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Rejection Reason *</label>
              <Textarea
                placeholder="Explain why this request is being rejected..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                disabled={loading}
                rows={4}
              />
            </div>
          )}

          {actionType === "approve" && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                This action will grant full admin privileges to this user. They will be able to manage other users and
                access all admin features.
              </AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={loading}
            variant={actionType === "approve" ? "default" : "destructive"}
            className={actionType === "approve" ? "bg-green-600 hover:bg-green-700" : ""}
          >
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {actionType === "approve" ? "Approve Request" : "Reject Request"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
