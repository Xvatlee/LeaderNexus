"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, CheckCircle2, XCircle, Clock, AlertCircle } from "lucide-react"

interface AdminRequest {
  id: string
  status: "pending" | "approved" | "rejected"
  reason: string | null
  created_at: string
  reviewed_at: string | null
}

export function AdminRequestCard() {
  const [request, setRequest] = useState<AdminRequest | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [reason, setReason] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    loadRequestStatus()
  }, [])

  const loadRequestStatus = async () => {
    try {
      console.log("[v0] Loading admin request status...")
      const response = await fetch("/api/admin-requests")
      const data = await response.json()

      console.log("[v0] Admin request response:", data)

      if (response.ok) {
        setRequest(data.request)
        setIsAdmin(data.isAdmin)
      } else {
        console.error("[v0] Error response:", data)
      }
    } catch (err) {
      console.error("[v0] Error loading admin request status:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmitRequest = async () => {
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/admin-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason }),
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess(data.message)
        setReason("")
        await loadRequestStatus()
      } else {
        setError(data.error || "Failed to submit admin request")
      }
    } catch (err) {
      setError("An error occurred while submitting your request")
      console.error("[v0] Error submitting admin request:", err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="py-6 text-center text-sm text-muted-foreground">
          Loading admin request status...
        </CardContent>
      </Card>
    )
  }

  // If user is already admin, don't show anything
  if (isAdmin) {
    console.log("[v0] User is admin, hiding request card")
    return null
  }

  console.log("[v0] Rendering admin request card, request:", request)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            <Clock className="h-3 w-3 mr-1" />
            Pending Review
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Approved
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <XCircle className="h-3 w-3 mr-1" />
            Rejected
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <Card className="border-accent/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-accent" />
          Admin Access Request
        </CardTitle>
        <CardDescription>Request admin privileges to access advanced features and management tools</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="bg-green-50 text-green-800 border-green-200">
            <CheckCircle2 className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        {request ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Request Status:</span>
              {getStatusBadge(request.status)}
            </div>

            {request.reason && (
              <div>
                <span className="text-sm font-medium">Your Reason:</span>
                <p className="text-sm text-muted-foreground mt-1">{request.reason}</p>
              </div>
            )}

            <div className="text-sm text-muted-foreground">
              Submitted: {new Date(request.created_at).toLocaleDateString()}
            </div>

            {request.status === "pending" && (
              <Alert>
                <Clock className="h-4 w-4" />
                <AlertDescription>
                  Your request is pending review by the super admin. You will be notified once a decision is made.
                </AlertDescription>
              </Alert>
            )}

            {request.status === "rejected" && (
              <Button onClick={() => setRequest(null)} variant="outline" className="w-full">
                Submit New Request
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Reason for Admin Access (Optional)</label>
              <Textarea
                placeholder="Explain why you need admin privileges..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                disabled={loading}
                rows={4}
              />
            </div>

            <Button onClick={handleSubmitRequest} disabled={loading} className="w-full">
              {loading ? "Submitting..." : "Request Admin Access"}
            </Button>

            <p className="text-xs text-muted-foreground">
              Your request will be reviewed by the super admin. Only approved requests will receive admin privileges.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
