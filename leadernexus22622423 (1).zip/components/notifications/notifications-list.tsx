"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Award, MessageSquare, ThumbsUp, Bell, Check } from "lucide-react"
import type { Notification } from "@/lib/types"

interface NotificationsListProps {
  notifications: Notification[]
  userId: string
}

export default function NotificationsList({ notifications, userId }: NotificationsListProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const markAsRead = async (notificationId: string) => {
    const supabase = createClient()
    await supabase.from("notifications").update({ is_read: true }).eq("id", notificationId)
    router.refresh()
  }

  const markAllAsRead = async () => {
    if (isLoading) return
    setIsLoading(true)

    const supabase = createClient()
    await supabase.from("notifications").update({ is_read: true }).eq("user_id", userId).eq("is_read", false)

    router.refresh()
    setIsLoading(false)
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "achievement":
        return <Award className="h-5 w-5 text-accent" />
      case "comment":
        return <MessageSquare className="h-5 w-5 text-blue-500" />
      case "like":
        return <ThumbsUp className="h-5 w-5 text-pink-500" />
      default:
        return <Bell className="h-5 w-5 text-muted-foreground" />
    }
  }

  const unreadCount = notifications.filter((n) => !n.is_read).length

  return (
    <div className="space-y-4">
      {unreadCount > 0 && (
        <div className="flex items-center justify-between pb-4 border-b">
          <span className="text-sm text-muted-foreground">{unreadCount} unread notifications</span>
          <Button variant="ghost" size="sm" onClick={markAllAsRead} disabled={isLoading}>
            <Check className="mr-2 h-4 w-4" />
            Mark all as read
          </Button>
        </div>
      )}

      {notifications.length > 0 ? (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`flex items-start gap-4 p-4 rounded-lg border transition-colors ${
                !notification.is_read ? "bg-accent/5 border-accent/20" : "border-border"
              }`}
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted">
                {getNotificationIcon(notification.type)}
              </div>

              <div className="flex-1 space-y-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h4 className="font-semibold text-sm">{notification.title}</h4>
                  {!notification.is_read && (
                    <Badge variant="default" className="bg-accent text-xs">
                      New
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{notification.message}</p>
                <p className="text-xs text-muted-foreground">{new Date(notification.created_at).toLocaleString()}</p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {notification.action_url && (
                  <Button asChild size="sm" variant="outline" className="bg-transparent">
                    <Link href={notification.action_url} onClick={() => markAsRead(notification.id)}>
                      View
                    </Link>
                  </Button>
                )}
                {!notification.is_read && (
                  <Button size="sm" variant="ghost" onClick={() => markAsRead(notification.id)}>
                    <Check className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <h3 className="font-semibold mb-2">No notifications yet</h3>
          <p className="text-sm">We'll notify you when there's something new</p>
        </div>
      )}
    </div>
  )
}
