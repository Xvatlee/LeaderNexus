"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Bell, Check } from "lucide-react"
import type { Notification } from "@/lib/types/database.types"
import Link from "next/link"

interface NotificationsListClientProps {
  notifications: Notification[]
  userId: string
}

export function NotificationsListClient({ notifications: initialNotifications, userId }: NotificationsListClientProps) {
  const [notifications, setNotifications] = useState(initialNotifications)

  async function markAsRead(notificationId: string) {
    try {
      const response = await fetch(`/api/notifications/${notificationId}/read`, {
        method: "PATCH",
      })

      if (response.ok) {
        setNotifications((prev) => prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n)))
      }
    } catch (error) {
      console.error("[v0] Mark as read error:", error)
    }
  }

  if (notifications.length === 0) {
    return (
      <div className="text-center py-12">
        <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">Bildirishnomalar yo'q</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`p-4 rounded-lg border ${!notification.read ? "bg-accent/20 border-accent" : ""}`}
        >
          <div className="flex items-start gap-3">
            <Bell className="h-5 w-5 mt-1 text-muted-foreground" />
            <div className="flex-1 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{notification.title}</p>
                  <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                </div>
                {!notification.read && (
                  <Button variant="ghost" size="sm" onClick={() => markAsRead(notification.id)}>
                    <Check className="h-4 w-4 mr-1" />
                    O'qilgan
                  </Button>
                )}
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span>{new Date(notification.created_at).toLocaleString("uz-UZ")}</span>
                <Badge variant="secondary" className="text-xs">
                  {notification.type}
                </Badge>
              </div>
              {notification.link && (
                <Button asChild variant="link" size="sm" className="h-auto p-0">
                  <Link href={notification.link}>Ko'rish</Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
