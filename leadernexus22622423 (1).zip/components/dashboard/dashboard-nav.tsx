"use client"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import {
  Users,
  Home,
  MessageSquare,
  TrendingUp,
  User,
  LogOut,
  Award,
  ShieldCheck,
  Calendar,
  BarChart3,
  Trophy,
  BookOpen,
  Target,
  Lightbulb,
  Vote,
  UserCheck,
  Star,
  MessageCircle,
  LineChart,
  ImageIcon,
  Menu,
  X,
} from "lucide-react"
import type { Profile } from "@/lib/types"
import { useEffect, useState } from "react"
import { LanguageSwitcher } from "@/components/language-switcher"
import { NotificationCenter } from "@/components/notifications/notification-center"
import { useTranslations } from "@/lib/i18n/use-translations"

interface DashboardNavProps {
  user: Profile | null
}

export default function DashboardNav({ user }: DashboardNavProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [isAdmin, setIsAdmin] = useState(false)
  const [isLeader, setIsLeader] = useState(false)
  const [isDistrictHead, setIsDistrictHead] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { t } = useTranslations()

  useEffect(() => {
    if (!user) return

    const checkRole = async () => {
      const supabase = createClient()
      const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle()

      setIsAdmin(profile?.role === "admin")
      setIsLeader(profile?.role === "leader" || profile?.role === "admin")
      setIsDistrictHead(profile?.role === "district_head_leader")
    }

    checkRole()
  }, [user])

  const navItems = [
    { href: "/dashboard", label: t("nav.dashboard"), icon: Home },
    { href: "/forum", label: t("nav.forum"), icon: MessageSquare },
    { href: "/projects", label: t("nav.projects"), icon: Lightbulb },
    { href: "/voting", label: t("nav.voting"), icon: Vote },
    { href: "/leaders", label: t("nav.leaders"), icon: UserCheck },
    { href: "/media", label: t("nav.media"), icon: ImageIcon },
    { href: "/ratings", label: t("nav.ratings"), icon: Trophy },
    { href: "/plans", label: t("nav.plans"), icon: Calendar },
    { href: "/leaderboard", label: t("nav.leaderboard"), icon: TrendingUp },
    { href: "/achievements", label: t("nav.achievements"), icon: Award },
  ]

  if (isLeader) {
    navItems.push({ href: "/leader-dashboard", label: t("nav.leaderPanel"), icon: BarChart3 })
  }

  if (isDistrictHead) {
    navItems.push({ href: `/district-dashboard/${user?.district}`, label: t("nav.boshSardorPanel"), icon: ShieldCheck })
  }

  if (isAdmin) {
    navItems.push({ href: "/admin", label: t("nav.adminPanel"), icon: ShieldCheck })
  }

  const handleSignOut = async () => {
    const supabase = createClient()

    try {
      const { error } = await supabase.auth.signOut()

      if (error) {
        console.error("[v0] Sign out error:", error)
        return
      }

      router.push("/auth/login")
      router.refresh()
    } catch (error) {
      console.error("[v0] Unexpected error during sign out:", error)
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur-xl supports-[backdrop-filter]:bg-background/80 transition-all duration-300 shadow-sm">
      <div className="container mx-auto flex h-16 items-center justify-between gap-4">
        <Link
          href="/dashboard"
          className="flex items-center gap-2.5 flex-shrink-0 group animate-fade-in-up focus-visible-ring rounded-md px-2 py-1"
          aria-label="LeaderNexus Home"
        >
          <div className="relative">
            <Users className="h-7 w-7 text-accent transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6" />
            <div className="absolute inset-0 bg-accent/20 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-foreground to-accent bg-clip-text text-transparent hidden sm:inline group-hover:from-accent group-hover:to-primary transition-all duration-300">
            LeaderNexus
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-2 flex-1 justify-center max-w-3xl" aria-label="Main navigation">
          {navItems.slice(0, 5).map((item, index) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            return (
              <Button
                key={item.href}
                asChild
                variant={isActive ? "secondary" : "ghost"}
                size="sm"
                className={`gap-2 whitespace-nowrap btn-hover focus-visible-ring animate-fade-in-up animate-stagger-${Math.min(index + 1, 4)} ${
                  isActive ? "shadow-sm bg-accent/10 border-accent/20 text-accent" : ""
                }`}
              >
                <Link href={item.href}>
                  <Icon className={`h-4 w-4 transition-transform duration-300 ${isActive ? "text-accent" : ""}`} />
                  <span className="hidden lg:inline">{item.label}</span>
                </Link>
              </Button>
            )
          })}

          {navItems.length > 5 && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2 btn-hover focus-visible-ring">
                  <TrendingUp className="h-4 w-4" />
                  <span className="hidden lg:inline">{t("nav.more")}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="center" className="w-48 animate-scale-in">
                {navItems.slice(5).map((item) => {
                  const Icon = item.icon
                  return (
                    <DropdownMenuItem key={item.href} asChild>
                      <Link href={item.href} className="cursor-pointer">
                        <Icon className="mr-2 h-4 w-4" />
                        {item.label}
                      </Link>
                    </DropdownMenuItem>
                  )
                })}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </nav>

        <div className="flex items-center gap-2 lg:gap-3 flex-shrink-0">
          <LanguageSwitcher />
          {user && <NotificationCenter userId={user.id} />}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="relative h-10 gap-2 px-2 lg:px-3 btn-hover focus-visible-ring rounded-full"
                aria-label="User menu"
              >
                <Avatar className="h-8 w-8 border-2 border-accent/20 transition-all duration-300 hover:border-accent/50">
                  <AvatarImage src={user?.avatar_url || ""} alt={user?.username || "User"} />
                  <AvatarFallback className="bg-accent/10 text-accent font-semibold">
                    {user?.username?.charAt(0).toUpperCase() || "U"}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium hidden lg:inline">{user?.username}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 animate-scale-in">
              <DropdownMenuLabel>
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium">{user?.full_name || user?.username}</p>
                  <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/profile" className="cursor-pointer focus-visible-ring">
                  <User className="mr-2 h-4 w-4" />
                  {t("nav.profile")}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/dashboard" className="cursor-pointer focus-visible-ring">
                  <Home className="mr-2 h-4 w-4" />
                  {t("nav.dashboard")}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/projects" className="cursor-pointer focus-visible-ring">
                  <Lightbulb className="mr-2 h-4 w-4" />
                  {t("nav.myProjects")}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/voting" className="cursor-pointer focus-visible-ring">
                  <Vote className="mr-2 h-4 w-4" />
                  {t("nav.voting")}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/plans" className="cursor-pointer focus-visible-ring">
                  <Calendar className="mr-2 h-4 w-4" />
                  {t("nav.myPlans")}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/media" className="cursor-pointer focus-visible-ring">
                  <ImageIcon className="mr-2 h-4 w-4" />
                  {t("nav.mediaGallery")}
                </Link>
              </DropdownMenuItem>
              {isLeader && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger className="focus-visible-ring">
                      <BarChart3 className="mr-2 h-4 w-4" />
                      {t("nav.leaderTools")}
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent>
                      <DropdownMenuItem asChild>
                        <Link href="/leader-dashboard" className="cursor-pointer focus-visible-ring">
                          <Target className="mr-2 h-4 w-4" />
                          {t("nav.kpiDashboard")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/leader-hub" className="cursor-pointer focus-visible-ring">
                          <BookOpen className="mr-2 h-4 w-4" />
                          {t("nav.trainingHub")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/leader-performance" className="cursor-pointer focus-visible-ring">
                          <Trophy className="mr-2 h-4 w-4" />
                          {t("nav.performance")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/media/upload" className="cursor-pointer focus-visible-ring">
                          <ImageIcon className="mr-2 h-4 w-4" />
                          {t("nav.uploadMedia")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/leaders" className="cursor-pointer focus-visible-ring">
                          <UserCheck className="mr-2 h-4 w-4" />
                          {t("nav.sardorlar")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link href="/ratings" className="cursor-pointer focus-visible-ring">
                          <Trophy className="mr-2 h-4 w-4" />
                          {t("nav.reyting")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/ratings/peer-review" className="cursor-pointer focus-visible-ring">
                          <Star className="mr-2 h-4 w-4" />
                          {t("nav.hamkasblarnibaholash")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/ratings/feedback" className="cursor-pointer focus-visible-ring">
                          <MessageCircle className="mr-2 h-4 w-4" />
                          {t("nav.jamoatchilkfikri")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/ratings/analytics" className="cursor-pointer focus-visible-ring">
                          <LineChart className="mr-2 h-4 w-4" />
                          {t("nav.statistika")}
                        </Link>
                      </DropdownMenuItem>
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                </>
              )}
              {isDistrictHead && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger className="focus-visible-ring">
                      <ShieldCheck className="mr-2 h-4 w-4" />
                      {t("nav.boshSardorTools")}
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent>
                      <DropdownMenuItem asChild>
                        <Link
                          href={`/district-dashboard/${user?.district}`}
                          className="cursor-pointer focus-visible-ring"
                        >
                          <Target className="mr-2 h-4 w-4" />
                          {t("nav.dashboard")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link
                          href={`/district-dashboard/${user?.district}?tab=sardors`}
                          className="cursor-pointer focus-visible-ring"
                        >
                          <UserCheck className="mr-2 h-4 w-4" />
                          {t("nav.sardorlar")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link
                          href={`/district-dashboard/${user?.district}?tab=analytics`}
                          className="cursor-pointer focus-visible-ring"
                        >
                          <LineChart className="mr-2 h-4 w-4" />
                          {t("nav.analytics")}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link
                          href={`/district-dashboard/${user?.district}?tab=notifications`}
                          className="cursor-pointer focus-visible-ring"
                        >
                          <MessageCircle className="mr-2 h-4 w-4" />
                          {t("nav.notifications")}
                        </Link>
                      </DropdownMenuItem>
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                </>
              )}
              {isAdmin && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/admin" className="cursor-pointer focus-visible-ring">
                      <ShieldCheck className="mr-2 h-4 w-4" />
                      {t("nav.adminPanel")}
                    </Link>
                  </DropdownMenuItem>
                </>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-destructive focus-visible-ring">
                <LogOut className="mr-2 h-4 w-4" />
                {t("nav.signOut")}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden btn-hover focus-visible-ring"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 p-0">
              <div className="flex flex-col h-full">
                <div className="p-6 border-b">
                  <Link
                    href="/dashboard"
                    className="flex items-center gap-2.5 group"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Users className="h-6 w-6 text-accent transition-transform duration-300 group-hover:scale-110" />
                    <span className="text-lg font-bold">LeaderNexus</span>
                  </Link>
                </div>

                <nav className="flex-1 overflow-y-auto p-4" aria-label="Mobile navigation">
                  <div className="space-y-1">
                    {navItems.map((item) => {
                      const Icon = item.icon
                      const isActive = pathname === item.href
                      return (
                        <Link
                          key={item.href}
                          href={item.href}
                          onClick={() => setMobileMenuOpen(false)}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 focus-visible-ring ${
                            isActive
                              ? "bg-accent/10 text-accent font-medium"
                              : "hover:bg-muted text-muted-foreground hover:text-foreground"
                          }`}
                        >
                          <Icon className="h-5 w-5" />
                          <span>{item.label}</span>
                        </Link>
                      )
                    })}
                  </div>
                </nav>

                <div className="p-4 border-t bg-muted/30">
                  <Button
                    variant="outline"
                    className="w-full justify-start gap-2 text-destructive hover:text-destructive hover:bg-destructive/10 focus-visible-ring bg-transparent"
                    onClick={handleSignOut}
                  >
                    <LogOut className="h-4 w-4" />
                    {t("nav.signOut")}
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
