"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useState } from "react"

interface ActivityData {
  date: string
  count: number
}

interface ActivityHeatmapProps {
  data: ActivityData[]
  title?: string
  description?: string
}

export function ActivityHeatmap({ data, title = "Activity Overview", description }: ActivityHeatmapProps) {
  const [hoveredDay, setHoveredDay] = useState<ActivityData | null>(null)
  const maxCount = Math.max(...data.map((d) => d.count), 1)

  const getIntensity = (count: number) => {
    const intensity = count / maxCount
    if (intensity === 0) return "bg-muted"
    if (intensity < 0.25) return "bg-accent/20"
    if (intensity < 0.5) return "bg-accent/40"
    if (intensity < 0.75) return "bg-accent/60"
    return "bg-accent"
  }

  // Generate last 12 weeks of days
  const weeks = 12
  const days = weeks * 7

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-12 gap-1">
            {Array.from({ length: days }).map((_, index) => {
              const dayData = data[index] || { date: "", count: 0 }
              const intensity = getIntensity(dayData.count)

              return (
                <div
                  key={index}
                  className={`aspect-square rounded-sm ${intensity} transition-all duration-200 hover:scale-125 hover:shadow-lg cursor-pointer animate-scale-in`}
                  style={{ animationDelay: `${index * 2}ms` }}
                  onMouseEnter={() => setHoveredDay(dayData)}
                  onMouseLeave={() => setHoveredDay(null)}
                  title={`${dayData.date}: ${dayData.count} activities`}
                />
              )
            })}
          </div>

          {hoveredDay && hoveredDay.count > 0 && (
            <div className="text-sm text-center p-2 rounded-lg bg-muted animate-fade-in">
              <span className="font-semibold">{hoveredDay.date}</span>: {hoveredDay.count} activities
            </div>
          )}

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Less</span>
            <div className="flex gap-1">
              <div className="w-3 h-3 rounded-sm bg-muted" />
              <div className="w-3 h-3 rounded-sm bg-accent/20" />
              <div className="w-3 h-3 rounded-sm bg-accent/40" />
              <div className="w-3 h-3 rounded-sm bg-accent/60" />
              <div className="w-3 h-3 rounded-sm bg-accent" />
            </div>
            <span>More</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
