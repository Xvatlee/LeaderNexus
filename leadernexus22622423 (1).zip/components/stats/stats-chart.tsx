"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface DataPoint {
  label: string
  value: number
  color?: string
}

interface StatsChartProps {
  title: string
  description?: string
  data: DataPoint[]
  type?: "bar" | "line"
}

export function StatsChart({ title, description, data, type = "bar" }: StatsChartProps) {
  const [animatedData, setAnimatedData] = useState<number[]>(data.map(() => 0))
  const maxValue = Math.max(...data.map((d) => d.value), 1)

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedData(data.map((d) => d.value))
    }, 100)
    return () => clearTimeout(timer)
  }, [data])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {data.map((item, index) => {
            const heightPercentage = (animatedData[index] / maxValue) * 100
            const prevValue = index > 0 ? data[index - 1].value : item.value
            const trend = item.value > prevValue ? "up" : item.value < prevValue ? "down" : "same"

            return (
              <div key={item.label} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">{item.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{item.value}</span>
                    {trend === "up" && <TrendingUp className="h-4 w-4 text-green-500" />}
                    {trend === "down" && <TrendingDown className="h-4 w-4 text-red-500" />}
                    {trend === "same" && <Minus className="h-4 w-4 text-muted-foreground" />}
                  </div>
                </div>
                <div className="relative h-8 w-full rounded-full bg-muted overflow-hidden">
                  <div
                    className={`absolute left-0 top-0 h-full rounded-full transition-all duration-1000 ease-out ${
                      item.color || "bg-accent"
                    }`}
                    style={{ width: `${heightPercentage}%` }}
                  >
                    <div className="h-full w-full animate-shimmer bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
