"use client"

import { useEffect, useState } from "react"
import { Award, Sparkles } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface AchievementUnlockAnimationProps {
  name: string
  description: string
  points: number
  show: boolean
  onComplete?: () => void
}

export function AchievementUnlockAnimation({
  name,
  description,
  points,
  show,
  onComplete,
}: AchievementUnlockAnimationProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    if (show) {
      setIsVisible(true)
      const timer = setTimeout(() => {
        setIsVisible(false)
        onComplete?.()
      }, 4000)
      return () => clearTimeout(timer)
    }
  }, [show, onComplete])

  if (!isVisible) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
      <Card className="relative max-w-md overflow-hidden border-accent shadow-2xl animate-scale-in">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-transparent to-accent/20 animate-pulse" />
        <CardContent className="relative p-8 text-center space-y-4">
          <div className="relative inline-flex">
            <div className="absolute inset-0 animate-ping">
              <Award className="h-16 w-16 text-accent opacity-75" />
            </div>
            <Award className="h-16 w-16 text-accent relative z-10" />
            <Sparkles className="absolute -top-2 -right-2 h-6 w-6 text-yellow-400 animate-bounce" />
          </div>

          <div className="space-y-2">
            <h3 className="text-2xl font-bold gradient-text">Achievement Unlocked!</h3>
            <p className="text-xl font-semibold">{name}</p>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>

          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent font-semibold">
            +{points} Points
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
