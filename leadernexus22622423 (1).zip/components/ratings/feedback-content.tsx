"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Star, Send, MessageSquare } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

export function FeedbackContent() {
  const [leaders, setLeaders] = useState<any[]>([])
  const [feedbacks, setFeedbacks] = useState<any[]>([])
  const [selectedLeader, setSelectedLeader] = useState<string>("")
  const [loading, setLoading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    rating: 0,
    category: "other",
    feedback_text: "",
    submitter_name: "",
    is_anonymous: false,
  })

  useEffect(() => {
    loadLeaders()
    loadFeedbacks()
  }, [])

  async function loadLeaders() {
    try {
      const res = await fetch("/api/leaders/all")
      if (res.ok) {
        const data = await res.json()
        setLeaders(data.leaders || [])
      }
    } catch (error) {
      console.error("[v0] Error loading leaders:", error)
    }
  }

  async function loadFeedbacks() {
    try {
      setLoading(true)
      const res = await fetch("/api/ratings/community-feedback")
      if (res.ok) {
        const data = await res.json()
        setFeedbacks(data.feedbacks || [])
      }
    } catch (error) {
      console.error("[v0] Error loading feedbacks:", error)
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!selectedLeader) {
      toast({
        title: "Xatolik",
        description: "Iltimos, sardorni tanlang",
        variant: "destructive",
      })
      return
    }

    if (formData.rating === 0) {
      toast({
        title: "Xatolik",
        description: "Iltimos, bahoni kiriting",
        variant: "destructive",
      })
      return
    }

    if (!formData.feedback_text.trim()) {
      toast({
        title: "Xatolik",
        description: "Iltimos, fikr-mulohazangizni yozing",
        variant: "destructive",
      })
      return
    }

    try {
      setSubmitting(true)

      const res = await fetch("/api/ratings/community-feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sardor_id: selectedLeader,
          ...formData,
        }),
      })

      if (res.ok) {
        toast({
          title: "Rahmat!",
          description: "Sizning fikringiz qabul qilindi",
        })

        // Reset form
        setSelectedLeader("")
        setFormData({
          rating: 0,
          category: "other",
          feedback_text: "",
          submitter_name: "",
          is_anonymous: false,
        })

        // Reload feedbacks
        loadFeedbacks()
      } else {
        const error = await res.json()
        toast({
          title: "Xatolik",
          description: error.error || "Fikr saqlanmadi",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("[v0] Error submitting feedback:", error)
      toast({
        title: "Xatolik",
        description: "Tarmoq xatosi yuz berdi",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  function RatingStars({ value, onChange }: { value: number; onChange: (v: number) => void }) {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="transition-colors hover:scale-110 active:scale-95"
          >
            <Star className={`h-10 w-10 ${star <= value ? "fill-yellow-500 text-yellow-500" : "text-gray-300"}`} />
          </button>
        ))}
        <span className="ml-2 text-lg font-medium">{value}/5</span>
      </div>
    )
  }

  function getCategoryLabel(category: string) {
    const labels: Record<string, string> = {
      project: "Loyiha",
      event: "Tadbir",
      leadership: "Yetakchilik",
      communication: "Muloqot",
      other: "Boshqa",
    }
    return labels[category] || category
  }

  return (
    <div className="container mx-auto max-w-6xl py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Jamoatchilik fikri</h1>
        <p className="text-muted-foreground">Sardorlarga fikr va takliflaringizni bildiring</p>
      </div>

      <Tabs defaultValue="submit" className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="submit">Fikr bildirish</TabsTrigger>
          <TabsTrigger value="view">Fikrlarni ko&apos;rish</TabsTrigger>
        </TabsList>

        {/* Submit Feedback Tab */}
        <TabsContent value="submit">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Fikr-mulohaza bildirish
              </CardTitle>
              <CardDescription>Sardor faoliyati haqida o&apos;z fikringizni yozing</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Leader Selection */}
                <div className="space-y-2">
                  <Label htmlFor="leader">Sardorni tanlang *</Label>
                  <Select value={selectedLeader} onValueChange={setSelectedLeader}>
                    <SelectTrigger id="leader">
                      <SelectValue placeholder="Sardorni tanlang" />
                    </SelectTrigger>
                    <SelectContent>
                      {leaders.map((leader) => (
                        <SelectItem key={leader.id} value={leader.id}>
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarImage src={leader.avatar_url || "/placeholder.svg"} />
                              <AvatarFallback>{leader.full_name?.[0]}</AvatarFallback>
                            </Avatar>
                            <span>{leader.full_name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Rating */}
                <div className="space-y-2">
                  <Label>Baho *</Label>
                  <RatingStars value={formData.rating} onChange={(v) => setFormData({ ...formData, rating: v })} />
                </div>

                {/* Category */}
                <div className="space-y-2">
                  <Label htmlFor="category">Kategoriya</Label>
                  <Select value={formData.category} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                    <SelectTrigger id="category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="project">Loyiha</SelectItem>
                      <SelectItem value="event">Tadbir</SelectItem>
                      <SelectItem value="leadership">Yetakchilik</SelectItem>
                      <SelectItem value="communication">Muloqot</SelectItem>
                      <SelectItem value="other">Boshqa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Feedback Text */}
                <div className="space-y-2">
                  <Label htmlFor="feedback">Fikr-mulohaza *</Label>
                  <Textarea
                    id="feedback"
                    placeholder="Sardor faoliyati haqida fikringizni yozing..."
                    value={formData.feedback_text}
                    onChange={(e) => setFormData({ ...formData, feedback_text: e.target.value })}
                    rows={5}
                    className="resize-none"
                  />
                </div>

                {/* Submitter Name (if not anonymous) */}
                {!formData.is_anonymous && (
                  <div className="space-y-2">
                    <Label htmlFor="name">Ismingiz</Label>
                    <Input
                      id="name"
                      placeholder="To'liq ismingiz"
                      value={formData.submitter_name}
                      onChange={(e) => setFormData({ ...formData, submitter_name: e.target.value })}
                    />
                  </div>
                )}

                {/* Anonymous Option */}
                <div className="flex items-center justify-between p-4 bg-accent/50 rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="anonymous">Anonim yuborish</Label>
                    <p className="text-sm text-muted-foreground">Ismingiz ko&apos;rinmaydi</p>
                  </div>
                  <Switch
                    id="anonymous"
                    checked={formData.is_anonymous}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_anonymous: checked })}
                  />
                </div>

                <Button type="submit" className="w-full" size="lg" disabled={submitting || !selectedLeader}>
                  <Send className="h-4 w-4 mr-2" />
                  {submitting ? "Yuklanmoqda..." : "Yuborish"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* View Feedback Tab */}
        <TabsContent value="view">
          <Card>
            <CardHeader>
              <CardTitle>Barcha fikr-mulohazalar</CardTitle>
              <CardDescription>Jamoatchilik tomonidan berilgan fikrlar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {feedbacks.map((feedback) => (
                  <div key={feedback.id} className="p-4 border rounded-lg bg-card">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={feedback.sardor?.avatar_url || "/placeholder.svg"} />
                          <AvatarFallback>{feedback.sardor?.full_name?.[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{feedback.sardor?.full_name}</p>
                          <div className="flex gap-2 items-center">
                            <Badge variant="secondary" className="text-xs">
                              {getCategoryLabel(feedback.category)}
                            </Badge>
                            <div className="flex">
                              {Array.from({ length: feedback.rating }).map((_, i) => (
                                <Star key={i} className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(feedback.created_at).toLocaleDateString("uz-UZ")}
                      </span>
                    </div>
                    <p className="text-sm mb-2">{feedback.feedback_text}</p>
                    <p className="text-xs text-muted-foreground">
                      — {feedback.is_anonymous ? "Anonim" : feedback.submitter_name || "Foydalanuvchi"}
                    </p>
                  </div>
                ))}

                {feedbacks.length === 0 && (
                  <div className="text-center py-12">
                    <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Hozircha fikr-mulohazalar yo&apos;q</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
