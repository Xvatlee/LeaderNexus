"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Star, Send, UserCheck } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export function PeerReviewContent() {
  const [leaders, setLeaders] = useState<any[]>([])
  const [selectedLeader, setSelectedLeader] = useState<string>("")
  const [loading, setLoading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    leadership_rating: 0,
    collaboration_rating: 0,
    communication_rating: 0,
    innovation_rating: 0,
    overall_rating: 0,
    positive_feedback: "",
    constructive_feedback: "",
    suggestions: "",
    is_anonymous: false,
  })

  useEffect(() => {
    loadLeaders()
  }, [])

  async function loadLeaders() {
    try {
      setLoading(true)
      const res = await fetch("/api/leaders/all")
      if (res.ok) {
        const data = await res.json()
        setLeaders(data.leaders || [])
      }
    } catch (error) {
      console.error("[v0] Error loading leaders:", error)
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!selectedLeader) {
      toast({
        title: "Xatolik",
        description: "Iltimos, sardorni tanlang",
        variant: "destructive",
      })
      return
    }

    if (formData.overall_rating === 0) {
      toast({
        title: "Xatolik",
        description: "Iltimos, umumiy bahoni kiriting",
        variant: "destructive",
      })
      return
    }

    try {
      setSubmitting(true)

      const res = await fetch("/api/ratings/peer-review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reviewee_id: selectedLeader,
          period_id: "current", // Backend should handle current period
          ...formData,
        }),
      })

      if (res.ok) {
        toast({
          title: "Muvaffaqiyatli!",
          description: "Sizning bahoyingiz saqlandi",
        })

        // Reset form
        setSelectedLeader("")
        setFormData({
          leadership_rating: 0,
          collaboration_rating: 0,
          communication_rating: 0,
          innovation_rating: 0,
          overall_rating: 0,
          positive_feedback: "",
          constructive_feedback: "",
          suggestions: "",
          is_anonymous: false,
        })
      } else {
        const error = await res.json()
        toast({
          title: "Xatolik",
          description: error.error || "Baholash saqlanmadi",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("[v0] Error submitting review:", error)
      toast({
        title: "Xatolik",
        description: "Tarmoq xatosi yuz berdi",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  function RatingStars({ value, onChange, label }: { value: number; onChange: (v: number) => void; label: string }) {
    return (
      <div className="space-y-2">
        <Label>{label}</Label>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => onChange(star)}
              className="transition-colors hover:scale-110 active:scale-95"
            >
              <Star className={`h-8 w-8 ${star <= value ? "fill-yellow-500 text-yellow-500" : "text-gray-300"}`} />
            </button>
          ))}
          <span className="ml-2 text-sm text-muted-foreground">{value}/5</span>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto max-w-4xl py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Hamkasblarni baholash</h1>
        <p className="text-muted-foreground">Boshqa sardorlar faoliyatini baholang va taklif bering</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            Baholash formasi
          </CardTitle>
          <CardDescription>
            Har bir mezon bo&apos;yicha 1 dan 5 gacha baho bering va o&apos;z fikrlaringizni yozing
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Leader Selection */}
            <div className="space-y-2">
              <Label htmlFor="leader">Sardorni tanlang</Label>
              <Select value={selectedLeader} onValueChange={setSelectedLeader}>
                <SelectTrigger id="leader">
                  <SelectValue placeholder="Sardorni tanlang" />
                </SelectTrigger>
                <SelectContent>
                  {leaders.map((leader) => (
                    <SelectItem key={leader.id} value={leader.id}>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={leader.avatar_url || "/placeholder.svg"} />
                          <AvatarFallback>{leader.full_name?.[0]}</AvatarFallback>
                        </Avatar>
                        <span>{leader.full_name}</span>
                        <span className="text-xs text-muted-foreground">• {leader.direction}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Rating Criteria */}
            <div className="space-y-4 p-4 bg-accent/50 rounded-lg">
              <RatingStars
                label="Yetakchilik qobiliyati"
                value={formData.leadership_rating}
                onChange={(v) => setFormData({ ...formData, leadership_rating: v })}
              />

              <RatingStars
                label="Hamkorlik va jamoaviylik"
                value={formData.collaboration_rating}
                onChange={(v) => setFormData({ ...formData, collaboration_rating: v })}
              />

              <RatingStars
                label="Muloqot qobiliyati"
                value={formData.communication_rating}
                onChange={(v) => setFormData({ ...formData, communication_rating: v })}
              />

              <RatingStars
                label="Innovatsiya va ijodkorlik"
                value={formData.innovation_rating}
                onChange={(v) => setFormData({ ...formData, innovation_rating: v })}
              />

              <RatingStars
                label="Umumiy baho *"
                value={formData.overall_rating}
                onChange={(v) => setFormData({ ...formData, overall_rating: v })}
              />
            </div>

            {/* Feedback */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="positive">Ijobiy tomonlar</Label>
                <Textarea
                  id="positive"
                  placeholder="Sardorning qaysi jihatlari yaxshi ekanligini yozing..."
                  value={formData.positive_feedback}
                  onChange={(e) => setFormData({ ...formData, positive_feedback: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="constructive">Yaxshilanishi kerak jihatlari</Label>
                <Textarea
                  id="constructive"
                  placeholder="Qaysi jihatlarda rivojlanish kerakligini yozing..."
                  value={formData.constructive_feedback}
                  onChange={(e) => setFormData({ ...formData, constructive_feedback: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="suggestions">Takliflar</Label>
                <Textarea
                  id="suggestions"
                  placeholder="Qanday takliflaringiz bor?"
                  value={formData.suggestions}
                  onChange={(e) => setFormData({ ...formData, suggestions: e.target.value })}
                  rows={3}
                />
              </div>
            </div>

            {/* Anonymous Option */}
            <div className="flex items-center justify-between p-4 bg-accent/50 rounded-lg">
              <div className="space-y-0.5">
                <Label htmlFor="anonymous">Anonim baholash</Label>
                <p className="text-sm text-muted-foreground">Sizning ismingiz ko&apos;rinmaydi</p>
              </div>
              <Switch
                id="anonymous"
                checked={formData.is_anonymous}
                onCheckedChange={(checked) => setFormData({ ...formData, is_anonymous: checked })}
              />
            </div>

            <Button type="submit" className="w-full" disabled={submitting || !selectedLeader}>
              <Send className="h-4 w-4 mr-2" />
              {submitting ? "Yuklanmoqda..." : "Baholashni yuborish"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
