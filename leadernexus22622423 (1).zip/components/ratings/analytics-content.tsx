"use client"

import { useEffect, useState } from "react"
import { BarChart3, TrendingUp, Award, Users, Target, Calendar, Download } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

export function AnalyticsContent() {
  const [analytics, setAnalytics] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState<"monthly" | "annual">("monthly")
  const [districtFilter, setDistrictFilter] = useState<string>("all")
  const [districts, setDistricts] = useState<any[]>([])

  useEffect(() => {
    loadData()
  }, [timeRange, districtFilter])

  async function loadData() {
    try {
      setLoading(true)

      // Load analytics data
      const analyticsUrl = `/api/ratings/analytics?time_range=${timeRange}${districtFilter !== "all" ? `&district_id=${districtFilter}` : ""}`
      const res = await fetch(analyticsUrl)
      if (res.ok) {
        const data = await res.json()
        setAnalytics(data)
      }

      // Load districts
      const districtsRes = await fetch("/api/districts")
      if (districtsRes.ok) {
        const data = await districtsRes.json()
        setDistricts(data.districts || [])
      }
    } catch (error) {
      console.error("[v0] Error loading analytics:", error)
    } finally {
      setLoading(false)
    }
  }

  function exportData() {
    // Create CSV export
    const csv = [
      ["Sardor", "Tuman", "Yo'nalish", "Ball", "O'rin"],
      ...(analytics?.top_performers || []).map((p: any) => [
        p.sardor?.full_name,
        p.district?.name_uz,
        p.direction?.name_uz,
        p.weighted_score.toFixed(1),
        p.rank_overall,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `reyting-statistika-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto" />
          <p className="mt-4 text-sm text-muted-foreground">Yuklanmoqda...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto max-w-7xl py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Reyting statistikasi</h1>
            <p className="text-muted-foreground">Sardorlar faoliyati tahlili va tendentsiyalar</p>
          </div>
          <Button onClick={exportData} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Eksport
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4 mb-6">
        <Select value={timeRange} onValueChange={(value: any) => setTimeRange(value)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Davr tanlang" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="monthly">Oylik</SelectItem>
            <SelectItem value="annual">Yillik</SelectItem>
          </SelectContent>
        </Select>

        <Select value={districtFilter} onValueChange={setDistrictFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Tuman tanlang" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Barcha tumanlar</SelectItem>
            {districts.map((district) => (
              <SelectItem key={district.id} value={district.id}>
                {district.name_uz}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full max-w-2xl grid-cols-4">
          <TabsTrigger value="overview">Umumiy</TabsTrigger>
          <TabsTrigger value="districts">Tumanlar</TabsTrigger>
          <TabsTrigger value="trends">Tendentsiyalar</TabsTrigger>
          <TabsTrigger value="performers">Eng yaxshilar</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Jami sardorlar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Users className="h-8 w-8 text-blue-600" />
                  <p className="text-3xl font-bold">{analytics?.overview?.total_sardors || 0}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">O&apos;rtacha ball</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Target className="h-8 w-8 text-green-600" />
                  <p className="text-3xl font-bold">{analytics?.overview?.average_score?.toFixed(1) || "0.0"}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Jami loyihalar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-8 w-8 text-purple-600" />
                  <p className="text-3xl font-bold">{analytics?.overview?.total_projects || 0}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Tugallangan (%)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Award className="h-8 w-8 text-yellow-600" />
                  <p className="text-3xl font-bold">{analytics?.overview?.completion_rate?.toFixed(0) || "0"}%</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Score Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Ball taqsimoti</CardTitle>
              <CardDescription>Sardorlarning ball bo&apos;yicha taqsimlanishi</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>A&apos;lo (80-100)</span>
                  <span className="font-medium">{analytics?.score_distribution?.excellent || 0} sardor</span>
                </div>
                <Progress
                  value={
                    ((analytics?.score_distribution?.excellent || 0) / (analytics?.overview?.total_sardors || 1)) * 100
                  }
                  className="h-3 bg-green-100"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Yaxshi (60-79)</span>
                  <span className="font-medium">{analytics?.score_distribution?.good || 0} sardor</span>
                </div>
                <Progress
                  value={((analytics?.score_distribution?.good || 0) / (analytics?.overview?.total_sardors || 1)) * 100}
                  className="h-3 bg-blue-100"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Qoniqarli (40-59)</span>
                  <span className="font-medium">{analytics?.score_distribution?.average || 0} sardor</span>
                </div>
                <Progress
                  value={
                    ((analytics?.score_distribution?.average || 0) / (analytics?.overview?.total_sardors || 1)) * 100
                  }
                  className="h-3 bg-yellow-100"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Yaxshilanishi kerak (0-39)</span>
                  <span className="font-medium">{analytics?.score_distribution?.needs_improvement || 0} sardor</span>
                </div>
                <Progress
                  value={
                    ((analytics?.score_distribution?.needs_improvement || 0) /
                      (analytics?.overview?.total_sardors || 1)) *
                    100
                  }
                  className="h-3 bg-red-100"
                />
              </div>
            </CardContent>
          </Card>

          {/* Category Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Mezonlar bo&apos;yicha o&apos;rtacha ko&apos;rsatkichlar</CardTitle>
              <CardDescription>Har bir baholash mezonining o&apos;rtacha qiymati</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: "Loyihalar muvaffaqiyati", value: analytics?.category_averages?.projects },
                { label: "Jamoatchilik ishtiroki", value: analytics?.category_averages?.engagement },
                { label: "Tadbirlar tashkil etish", value: analytics?.category_averages?.events },
                { label: "Yetakchilik qobiliyati", value: analytics?.category_averages?.leadership },
                { label: "Jamoatchilik fikri", value: analytics?.category_averages?.feedback },
              ].map((category) => (
                <div key={category.label} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{category.label}</span>
                    <span className="font-medium">{category.value?.toFixed(1) || "0.0"}/100</span>
                  </div>
                  <Progress value={category.value || 0} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Districts Tab */}
        <TabsContent value="districts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tumanlar bo&apos;yicha natijalar</CardTitle>
              <CardDescription>Har bir tumanning o&apos;rtacha ko&apos;rsatkichi</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics?.district_rankings?.map((district: any, index: number) => (
                  <div key={district.district_id} className="flex items-center gap-4 p-4 border rounded-lg">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 font-bold text-primary">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold">{district.district_name}</p>
                      <div className="flex gap-4 text-xs text-muted-foreground mt-1">
                        <span>{district.sardor_count} sardor</span>
                        <span>•</span>
                        <span>{district.total_projects} loyiha</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">{district.average_score?.toFixed(1)}</p>
                      <p className="text-xs text-muted-foreground">o&apos;rtacha ball</p>
                    </div>
                  </div>
                ))}

                {(!analytics?.district_rankings || analytics.district_rankings.length === 0) && (
                  <div className="text-center py-12">
                    <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Ma&apos;lumot yo&apos;q</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Rivojlanish tendentsiyalari
              </CardTitle>
              <CardDescription>Vaqt bo&apos;yicha o&apos;sish ko&apos;rsatkichlari</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <TrendingUp className="h-8 w-8 text-green-600 mb-2" />
                    <p className="text-2xl font-bold text-green-600">{analytics?.trends?.improving_sardors || 0}</p>
                    <p className="text-sm text-green-700">Yaxshilanayotgan sardorlar</p>
                  </div>

                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <Calendar className="h-8 w-8 text-blue-600 mb-2" />
                    <p className="text-2xl font-bold text-blue-600">{analytics?.trends?.stable_sardors || 0}</p>
                    <p className="text-sm text-blue-700">Barqaror ko&apos;rsatkichlar</p>
                  </div>

                  <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <Target className="h-8 w-8 text-yellow-600 mb-2" />
                    <p className="text-2xl font-bold text-yellow-600">{analytics?.trends?.declining_sardors || 0}</p>
                    <p className="text-sm text-yellow-700">E&apos;tibor talab qiladi</p>
                  </div>
                </div>

                <div className="pt-4">
                  <h4 className="font-semibold mb-3">Eng ko&apos;p rivojlangan sardorlar</h4>
                  <div className="space-y-2">
                    {analytics?.trends?.most_improved?.slice(0, 5).map((sardor: any) => (
                      <div
                        key={sardor.sardor_id}
                        className="flex items-center justify-between p-3 bg-accent rounded-lg"
                      >
                        <div>
                          <p className="font-medium">{sardor.sardor_name}</p>
                          <p className="text-xs text-muted-foreground">{sardor.district_name}</p>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-700">
                          +{sardor.improvement_percentage?.toFixed(1)}%
                        </Badge>
                      </div>
                    ))}

                    {(!analytics?.trends?.most_improved || analytics.trends.most_improved.length === 0) && (
                      <p className="text-sm text-muted-foreground text-center py-4">Hozircha ma&apos;lumot yo&apos;q</p>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Top Performers Tab */}
        <TabsContent value="performers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Eng faol sardorlar
              </CardTitle>
              <CardDescription>Yuqori ko&apos;rsatkichlarga erishgan sardorlar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {analytics?.top_performers?.map((performer: any, index: number) => (
                  <div key={performer.sardor_id} className="flex items-center gap-4 p-4 border rounded-lg">
                    <div
                      className={`flex items-center justify-center w-10 h-10 rounded-full font-bold ${
                        index === 0
                          ? "bg-yellow-100 text-yellow-700"
                          : index === 1
                            ? "bg-gray-100 text-gray-700"
                            : index === 2
                              ? "bg-orange-100 text-orange-700"
                              : "bg-accent text-foreground"
                      }`}
                    >
                      {index + 1}
                    </div>

                    <div className="flex-1">
                      <p className="font-semibold">{performer.sardor_name}</p>
                      <div className="flex gap-2 text-xs text-muted-foreground mt-1">
                        <span>{performer.direction_name}</span>
                        <span>•</span>
                        <span>{performer.district_name}</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">{performer.weighted_score?.toFixed(1)}</p>
                      <div className="flex gap-2 text-xs text-muted-foreground mt-1">
                        <span>{performer.total_projects} loyiha</span>
                        <span>•</span>
                        <span>{performer.completed_projects} tugallangan</span>
                      </div>
                    </div>
                  </div>
                ))}

                {(!analytics?.top_performers || analytics.top_performers.length === 0) && (
                  <div className="text-center py-12">
                    <Award className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Ma&apos;lumot yo&apos;q</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
