"use client"

import { useEffect, useState } from "react"
import { Trophy, Medal, Award, TrendingUp, Users, Target, Star, Filter } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function RatingsContent() {
  const [leaderboard, setLeaderboard] = useState<any[]>([])
  const [myRating, setMyRating] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [periodType, setPeriodType] = useState<"monthly" | "annual">("monthly")
  const [districtFilter, setDistrictFilter] = useState<string>("all")
  const [districts, setDistricts] = useState<any[]>([])

  useEffect(() => {
    loadData()
  }, [periodType, districtFilter])

  async function loadData() {
    try {
      setLoading(true)

      // Load leaderboard
      const leaderboardUrl = `/api/ratings/leaderboard?period_type=${periodType}${districtFilter !== "all" ? `&district_id=${districtFilter}` : ""}`
      const leaderboardRes = await fetch(leaderboardUrl)
      if (leaderboardRes.ok) {
        const data = await leaderboardRes.json()
        setLeaderboard(data.leaderboard || [])
      }

      // Load my rating
      const myRatingRes = await fetch("/api/ratings/my-rating")
      if (myRatingRes.ok) {
        const data = await myRatingRes.json()
        setMyRating(data.rating)
      }

      // Load districts
      const districtsRes = await fetch("/api/districts")
      if (districtsRes.ok) {
        const data = await districtsRes.json()
        setDistricts(data.districts || [])
      }
    } catch (error) {
      console.error("[v0] Error loading ratings:", error)
    } finally {
      setLoading(false)
    }
  }

  function getRankBadge(rank: number | null) {
    if (!rank) return null

    if (rank === 1) {
      return <Trophy className="h-5 w-5 text-yellow-500" />
    } else if (rank === 2) {
      return <Medal className="h-5 w-5 text-gray-400" />
    } else if (rank === 3) {
      return <Award className="h-5 w-5 text-orange-600" />
    }
    return <span className="text-sm font-medium text-muted-foreground">#{rank}</span>
  }

  function getScoreColor(score: number) {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-blue-600"
    if (score >= 40) return "text-yellow-600"
    return "text-red-600"
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto" />
          <p className="mt-4 text-sm text-muted-foreground">Yuklanmoqda...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto max-w-7xl py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Sardorlar reytingi</h1>
        <p className="text-muted-foreground">Tuman sardorlari faoliyati va yutuqlari bo&apos;yicha reyting</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={periodType} onValueChange={(value: any) => setPeriodType(value)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Davr tanlang" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="monthly">Oylik</SelectItem>
              <SelectItem value="annual">Yillik</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Select value={districtFilter} onValueChange={setDistrictFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Tuman tanlang" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Barcha tumanlar</SelectItem>
            {districts.map((district) => (
              <SelectItem key={district.id} value={district.id}>
                {district.name_uz}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="leaderboard" className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="leaderboard">Reyting jadvali</TabsTrigger>
          <TabsTrigger value="my-rating">Mening reytingim</TabsTrigger>
        </TabsList>

        {/* Leaderboard Tab */}
        <TabsContent value="leaderboard" className="space-y-4">
          {/* Top 3 Podium */}
          {leaderboard.length >= 3 && (
            <div className="grid grid-cols-3 gap-4 mb-8">
              {/* 2nd Place */}
              <Card className="relative mt-8">
                <CardHeader className="pb-4 text-center">
                  <div className="mx-auto mb-2">
                    <Avatar className="h-16 w-16 border-4 border-gray-400">
                      <AvatarImage src={leaderboard[1]?.sardor?.avatar_url || "/placeholder.svg"} />
                      <AvatarFallback>{leaderboard[1]?.sardor?.full_name?.[0]}</AvatarFallback>
                    </Avatar>
                  </div>
                  <Medal className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <CardTitle className="text-lg">{leaderboard[1]?.sardor?.full_name}</CardTitle>
                  <CardDescription className="text-xs">{leaderboard[1]?.direction?.name_uz}</CardDescription>
                </CardHeader>
                <CardContent className="text-center pb-6">
                  <p className="text-3xl font-bold text-gray-400">{leaderboard[1]?.weighted_score?.toFixed(1)}</p>
                  <p className="text-xs text-muted-foreground">ball</p>
                </CardContent>
              </Card>

              {/* 1st Place */}
              <Card className="relative border-2 border-yellow-500 bg-gradient-to-b from-yellow-50 to-background">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="bg-yellow-500 rounded-full p-2">
                    <Trophy className="h-6 w-6 text-white" />
                  </div>
                </div>
                <CardHeader className="pb-4 text-center pt-8">
                  <div className="mx-auto mb-2">
                    <Avatar className="h-20 w-20 border-4 border-yellow-500">
                      <AvatarImage src={leaderboard[0]?.sardor?.avatar_url || "/placeholder.svg"} />
                      <AvatarFallback>{leaderboard[0]?.sardor?.full_name?.[0]}</AvatarFallback>
                    </Avatar>
                  </div>
                  <CardTitle className="text-xl">{leaderboard[0]?.sardor?.full_name}</CardTitle>
                  <CardDescription>{leaderboard[0]?.direction?.name_uz}</CardDescription>
                </CardHeader>
                <CardContent className="text-center pb-6">
                  <p className="text-4xl font-bold text-yellow-500">{leaderboard[0]?.weighted_score?.toFixed(1)}</p>
                  <p className="text-sm text-muted-foreground">ball</p>
                  <Badge variant="secondary" className="mt-2">
                    <Star className="h-3 w-3 mr-1" />
                    Yetakchi
                  </Badge>
                </CardContent>
              </Card>

              {/* 3rd Place */}
              <Card className="relative mt-8">
                <CardHeader className="pb-4 text-center">
                  <div className="mx-auto mb-2">
                    <Avatar className="h-16 w-16 border-4 border-orange-600">
                      <AvatarImage src={leaderboard[2]?.sardor?.avatar_url || "/placeholder.svg"} />
                      <AvatarFallback>{leaderboard[2]?.sardor?.full_name?.[0]}</AvatarFallback>
                    </Avatar>
                  </div>
                  <Award className="h-8 w-8 text-orange-600 mx-auto mb-2" />
                  <CardTitle className="text-lg">{leaderboard[2]?.sardor?.full_name}</CardTitle>
                  <CardDescription className="text-xs">{leaderboard[2]?.direction?.name_uz}</CardDescription>
                </CardHeader>
                <CardContent className="text-center pb-6">
                  <p className="text-3xl font-bold text-orange-600">{leaderboard[2]?.weighted_score?.toFixed(1)}</p>
                  <p className="text-xs text-muted-foreground">ball</p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Full Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle>To&apos;liq reyting</CardTitle>
              <CardDescription>
                Barcha sardorlarning {periodType === "monthly" ? "oylik" : "yillik"} natijalari
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.map((rating, index) => (
                  <div
                    key={rating.id}
                    className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex items-center justify-center w-12">{getRankBadge(index + 1)}</div>

                    <Avatar className="h-12 w-12">
                      <AvatarImage src={rating.sardor?.avatar_url || "/placeholder.svg"} />
                      <AvatarFallback>{rating.sardor?.full_name?.[0]}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <p className="font-semibold">{rating.sardor?.full_name}</p>
                      <div className="flex gap-2 text-xs text-muted-foreground">
                        <span>{rating.direction?.name_uz}</span>
                        <span>•</span>
                        <span>{rating.district?.name_uz}</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className={`text-2xl font-bold ${getScoreColor(rating.weighted_score)}`}>
                        {rating.weighted_score?.toFixed(1)}
                      </p>
                      <p className="text-xs text-muted-foreground">ball</p>
                    </div>
                  </div>
                ))}

                {leaderboard.length === 0 && (
                  <div className="text-center py-12">
                    <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Hozircha reyting ma&apos;lumotlari yo&apos;q</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* My Rating Tab */}
        <TabsContent value="my-rating" className="space-y-4">
          {myRating ? (
            <>
              {/* Overview Card */}
              <Card>
                <CardHeader>
                  <CardTitle>Umumiy ko&apos;rsatkichlar</CardTitle>
                  <CardDescription>Sizning {periodType === "monthly" ? "oylik" : "yillik"} natijangiz</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-accent rounded-lg">
                      <Target className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                      <p className="text-3xl font-bold">{myRating.weighted_score?.toFixed(1)}</p>
                      <p className="text-xs text-muted-foreground">Umumiy ball</p>
                    </div>

                    <div className="text-center p-4 bg-accent rounded-lg">
                      <Trophy className="h-8 w-8 mx-auto mb-2 text-yellow-600" />
                      <p className="text-3xl font-bold">#{myRating.rank_overall || "-"}</p>
                      <p className="text-xs text-muted-foreground">Umumiy o&apos;rin</p>
                    </div>

                    <div className="text-center p-4 bg-accent rounded-lg">
                      <Medal className="h-8 w-8 mx-auto mb-2 text-green-600" />
                      <p className="text-3xl font-bold">#{myRating.rank_in_district || "-"}</p>
                      <p className="text-xs text-muted-foreground">Tumandagi o&apos;rin</p>
                    </div>

                    <div className="text-center p-4 bg-accent rounded-lg">
                      <TrendingUp className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                      <p className="text-3xl font-bold">{myRating.total_projects || 0}</p>
                      <p className="text-xs text-muted-foreground">Loyihalar</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Detailed Scores */}
              <Card>
                <CardHeader>
                  <CardTitle>Batafsil ko&apos;rsatkichlar</CardTitle>
                  <CardDescription>Har bir mezon bo&apos;yicha baholanganingiz</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Loyihalar muvaffaqiyati</span>
                      <span className="text-sm font-bold">{myRating.project_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={myRating.project_score} className="h-2" />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Jamoatchilik ishtiroki</span>
                      <span className="text-sm font-bold">{myRating.engagement_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={myRating.engagement_score} className="h-2" />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Tadbirlar tashkil etish</span>
                      <span className="text-sm font-bold">{myRating.events_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={myRating.events_score} className="h-2" />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Yetakchilik qobiliyati</span>
                      <span className="text-sm font-bold">{myRating.leadership_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={myRating.leadership_score} className="h-2" />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Jamoatchilik fikri</span>
                      <span className="text-sm font-bold">{myRating.feedback_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={myRating.feedback_score} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              {/* Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle>Statistika</CardTitle>
                  <CardDescription>Sizning faoliyatingiz raqamlarda</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="flex items-center gap-3 p-3 bg-accent rounded-lg">
                      <Target className="h-8 w-8 text-blue-600" />
                      <div>
                        <p className="text-2xl font-bold">{myRating.completed_projects}</p>
                        <p className="text-xs text-muted-foreground">Tugallangan loyihalar</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-accent rounded-lg">
                      <Users className="h-8 w-8 text-green-600" />
                      <div>
                        <p className="text-2xl font-bold">{myRating.total_participants || 0}</p>
                        <p className="text-xs text-muted-foreground">Ishtirokchilar</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-accent rounded-lg">
                      <Star className="h-8 w-8 text-yellow-600" />
                      <div>
                        <p className="text-2xl font-bold">{myRating.community_feedback_count || 0}</p>
                        <p className="text-xs text-muted-foreground">Fikr-mulohazalar</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Trophy className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-lg font-medium mb-2">Sizning reytingingiz hali mavjud emas</p>
                <p className="text-sm text-muted-foreground">
                  Tizim ma&apos;lumotlarni to&apos;playotganda kutib turing
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
