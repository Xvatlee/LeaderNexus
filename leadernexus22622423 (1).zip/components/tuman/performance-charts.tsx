"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Line, LineChart, Bar, BarChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend } from "recharts"
import { createClient } from "@/lib/supabase/client"
import type { DistrictRating, PerformanceMetric } from "@/lib/types/database.types"
import { TrendingUp, TrendingDown, Award } from "lucide-react"

interface TumanPerformanceChartsProps {
  tumanId: string
  currentRating: DistrictRating | null
}

export function TumanPerformanceCharts({ tumanId, currentRating }: TumanPerformanceChartsProps) {
  const [historicalRatings, setHistoricalRatings] = useState<DistrictRating[]>([])
  const [metrics, setMetrics] = useState<PerformanceMetric[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadPerformanceData()
  }, [tumanId])

  async function loadPerformanceData() {
    const supabase = createClient()

    // Load historical ratings (last 6 months)
    const sixMonthsAgo = new Date()
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)

    const { data: ratingsData } = await supabase
      .from("district_ratings")
      .select("*")
      .eq("tuman_id", tumanId)
      .gte("rating_period", sixMonthsAgo.toISOString().split("T")[0])
      .order("rating_period", { ascending: true })

    if (ratingsData) {
      setHistoricalRatings(ratingsData)
    }

    // Load performance metrics
    const { data: metricsData } = await supabase
      .from("performance_metrics")
      .select("*")
      .eq("tuman_id", tumanId)
      .gte("metric_date", sixMonthsAgo.toISOString().split("T")[0])
      .order("metric_date", { ascending: true })

    if (metricsData) {
      setMetrics(metricsData)
    }

    setLoading(false)
  }

  if (loading) {
    return <div className="text-center py-8">Yuklanmoqda...</div>
  }

  const ratingsChartData = historicalRatings.map((r) => ({
    date: new Date(r.rating_period).toLocaleDateString("uz", { month: "short", day: "numeric" }),
    overall: r.overall_score || 0,
    projects: r.project_completion_score || 0,
    engagement: r.community_engagement_score || 0,
    leadership: r.leadership_score || 0,
  }))

  const metricsChartData = metrics.map((m) => ({
    date: new Date(m.metric_date).toLocaleDateString("uz", { month: "short", day: "numeric" }),
    completed: m.projects_completed,
    inProgress: m.projects_in_progress,
    participants: m.total_participants,
    satisfaction: m.community_satisfaction * 100,
  }))

  const improvement =
    historicalRatings.length >= 2
      ? ((historicalRatings[historicalRatings.length - 1].overall_score || 0) -
          (historicalRatings[0].overall_score || 0)) /
        (historicalRatings[0].overall_score || 1)
      : 0

  return (
    <div className="space-y-6">
      {/* Performance Trend */}
      {improvement !== 0 && (
        <Card className={improvement > 0 ? "border-green-200 bg-green-50" : "border-orange-200 bg-orange-50"}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {improvement > 0 ? (
                <TrendingUp className="h-5 w-5 text-green-600" />
              ) : (
                <TrendingDown className="h-5 w-5 text-orange-600" />
              )}
              Tendentsiya tahlili
            </CardTitle>
            <CardDescription>So'nggi 6 oylik o'zgarish</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <p className={`text-4xl font-bold ${improvement > 0 ? "text-green-600" : "text-orange-600"}`}>
                {improvement > 0 ? "+" : ""}
                {(improvement * 100).toFixed(1)}%
              </p>
              <p className="text-sm text-muted-foreground">
                {improvement > 0
                  ? "Ko'rsatkichlaringiz yaxshilanmoqda! Davom eting!"
                  : "Ko'rsatkichlarni yaxshilash uchun qo'shimcha harakat qiling"}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Ratings Trend Chart */}
      {ratingsChartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Reyting tendentsiyasi</CardTitle>
            <CardDescription>Vaqt bo'yicha reytinglaringizning o'zgarishi</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                overall: {
                  label: "Umumiy",
                  color: "hsl(var(--chart-1))",
                },
                projects: {
                  label: "Loyihalar",
                  color: "hsl(var(--chart-2))",
                },
                engagement: {
                  label: "Jamoatchilik",
                  color: "hsl(var(--chart-3))",
                },
                leadership: {
                  label: "Yetakchilik",
                  color: "hsl(var(--chart-4))",
                },
              }}
              className="h-[350px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ratingsChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" fontSize={12} />
                  <YAxis domain={[0, 100]} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Line type="monotone" dataKey="overall" stroke="var(--color-overall)" strokeWidth={3} />
                  <Line type="monotone" dataKey="projects" stroke="var(--color-projects)" strokeWidth={2} />
                  <Line type="monotone" dataKey="engagement" stroke="var(--color-engagement)" strokeWidth={2} />
                  <Line type="monotone" dataKey="leadership" stroke="var(--color-leadership)" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      )}

      {/* Activity Metrics Chart */}
      {metricsChartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Faoliyat ko'rsatkichlari</CardTitle>
            <CardDescription>Loyihalar va ishtirokchilar statistikasi</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                completed: {
                  label: "Tugallangan",
                  color: "hsl(var(--chart-1))",
                },
                inProgress: {
                  label: "Jarayonda",
                  color: "hsl(var(--chart-2))",
                },
                participants: {
                  label: "Ishtirokchilar",
                  color: "hsl(var(--chart-3))",
                },
              }}
              className="h-[350px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={metricsChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" fontSize={12} />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Bar dataKey="completed" fill="var(--color-completed)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="inProgress" fill="var(--color-inProgress)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      )}

      {ratingsChartData.length === 0 && metricsChartData.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Award className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Tarixiy ma'lumotlar to'planmoqda...</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
