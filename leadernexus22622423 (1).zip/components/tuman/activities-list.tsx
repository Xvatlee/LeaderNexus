"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Activity, Calendar, Users, Plus } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { Activity as ActivityType } from "@/lib/types/database.types"
import Link from "next/link"

interface TumanActivitiesListProps {
  tumanId: string
}

export function TumanActivitiesList({ tumanId }: TumanActivitiesListProps) {
  const [activities, setActivities] = useState<ActivityType[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadActivities()
  }, [tumanId])

  async function loadActivities() {
    const supabase = createClient()

    const { data, error } = await supabase
      .from("activities")
      .select("*")
      .eq("tuman_id", tumanId)
      .order("start_date", { ascending: false })

    if (!error && data) {
      setActivities(data)
    }

    setLoading(false)
  }

  function isUpcoming(activity: ActivityType) {
    return new Date(activity.start_date) > new Date()
  }

  function isPast(activity: ActivityType) {
    return activity.end_date && new Date(activity.end_date) < new Date()
  }

  if (loading) {
    return <div className="text-center py-8">Yuklanmoqda...</div>
  }

  const upcomingActivities = activities.filter(isUpcoming)
  const pastActivities = activities.filter(isPast)
  const ongoingActivities = activities.filter((a) => !isUpcoming(a) && !isPast(a))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold">Tadbirlar va faoliyat</h3>
          <p className="text-muted-foreground">Barcha o'tkazilgan va rejalashtirilgan tadbirlar</p>
        </div>
        <Button asChild>
          <Link href="/tuman/activities/new">
            <Plus className="h-4 w-4 mr-2" />
            Yangi tadbir
          </Link>
        </Button>
      </div>

      {/* Ongoing Activities */}
      {ongoingActivities.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-lg font-semibold flex items-center gap-2">
            <Activity className="h-5 w-5 text-green-600" />
            Hozirgi tadbirlar
          </h4>
          <div className="grid gap-4">
            {ongoingActivities.map((activity) => (
              <Card key={activity.id} className="border-green-200">
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1 flex-1">
                      <CardTitle className="text-lg">{activity.title}</CardTitle>
                      <CardDescription>{activity.description}</CardDescription>
                    </div>
                    <Badge className="bg-green-600">Davom etmoqda</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">{activity.activity_type}</Badge>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{new Date(activity.start_date).toLocaleDateString()}</span>
                      {activity.end_date && <span> - {new Date(activity.end_date).toLocaleDateString()}</span>}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span>{activity.participants_count} ishtirokchi</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Upcoming Activities */}
      {upcomingActivities.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-lg font-semibold flex items-center gap-2">
            <Calendar className="h-5 w-5 text-blue-600" />
            Rejalashtirilgan tadbirlar
          </h4>
          <div className="grid gap-4">
            {upcomingActivities.map((activity) => (
              <Card key={activity.id} className="border-blue-200">
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1 flex-1">
                      <CardTitle className="text-lg">{activity.title}</CardTitle>
                      <CardDescription>{activity.description}</CardDescription>
                    </div>
                    <Badge variant="secondary">Rejalashtirilgan</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">{activity.activity_type}</Badge>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{new Date(activity.start_date).toLocaleDateString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Past Activities */}
      {pastActivities.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-lg font-semibold">O'tgan tadbirlar</h4>
          <div className="grid gap-4">
            {pastActivities.slice(0, 5).map((activity) => (
              <Card key={activity.id}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1 flex-1">
                      <CardTitle className="text-base">{activity.title}</CardTitle>
                      <CardDescription className="text-xs">{activity.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-4 text-xs">
                    <Badge variant="secondary" className="text-xs">
                      {activity.activity_type}
                    </Badge>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{new Date(activity.start_date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Users className="h-3 w-3" />
                      <span>{activity.participants_count} ishtirokchi</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {activities.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">Hozircha tadbirlar yo'q</p>
            <Button asChild>
              <Link href="/tuman/activities/new">
                <Plus className="h-4 w-4 mr-2" />
                Birinchi tadbirni tashkil qiling
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
