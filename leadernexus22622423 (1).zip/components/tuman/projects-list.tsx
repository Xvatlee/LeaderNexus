"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Target, Calendar, TrendingUp, Plus, Edit } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { Project } from "@/lib/types/database.types"
import Link from "next/link"

interface TumanProjectsListProps {
  tumanId: string
}

export function TumanProjectsList({ tumanId }: TumanProjectsListProps) {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadProjects()
  }, [tumanId])

  async function loadProjects() {
    const supabase = createClient()

    const { data, error } = await supabase
      .from("projects")
      .select("*")
      .eq("tuman_id", tumanId)
      .order("created_at", { ascending: false })

    if (!error && data) {
      setProjects(data)
    }

    setLoading(false)
  }

  function getStatusBadge(status: string) {
    const statusMap = {
      planning: { label: "Rejalashtirish", variant: "secondary" as const },
      in_progress: { label: "Jarayonda", variant: "default" as const },
      completed: { label: "Tugallangan", variant: "default" as const },
      on_hold: { label: "To'xtatilgan", variant: "secondary" as const },
      cancelled: { label: "Bekor qilingan", variant: "destructive" as const },
    }
    const config = statusMap[status as keyof typeof statusMap] || statusMap.planning
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  if (loading) {
    return <div className="text-center py-8">Yuklanmoqda...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold">Loyihalarim</h3>
          <p className="text-muted-foreground">Barcha aktiv va tugallangan loyihalar</p>
        </div>
        <Button asChild>
          <Link href="/projects/new">
            <Plus className="h-4 w-4 mr-2" />
            Yangi loyiha
          </Link>
        </Button>
      </div>

      <div className="grid gap-4">
        {projects.map((project) => (
          <Card key={project.id}>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1 flex-1">
                  <CardTitle className="text-xl">{project.title}</CardTitle>
                  <CardDescription className="line-clamp-2">{project.description}</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusBadge(project.status)}
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/projects/${project.id}/edit`}>
                      <Edit className="h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Boshlanish</p>
                      <p className="font-medium">
                        {project.start_date ? new Date(project.start_date).toLocaleDateString() : "Belgilanmagan"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Tugash</p>
                      <p className="font-medium">
                        {project.end_date ? new Date(project.end_date).toLocaleDateString() : "Belgilanmagan"}
                      </p>
                    </div>
                  </div>

                  {project.budget && (
                    <div className="flex items-center gap-2 text-sm">
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Byudjet</p>
                        <p className="font-medium">{project.budget.toLocaleString()} so'm</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">Progress</span>
                    <span className="font-bold">{project.progress_percentage}%</span>
                  </div>
                  <Progress value={project.progress_percentage || 0} className="h-3" />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="flex gap-3 text-sm">
                    <div>
                      <span className="text-muted-foreground">Ta'sir: </span>
                      <span className="font-semibold">{project.impact_score}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Ishtir: </span>
                      <span className="font-semibold">{project.community_involvement}</span>
                    </div>
                  </div>
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/projects/${project.id}`}>Batafsil</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {projects.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">Hozircha loyihalar yo'q</p>
              <Button asChild>
                <Link href="/projects/new">
                  <Plus className="h-4 w-4 mr-2" />
                  Birinchi loyihani yarating
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
