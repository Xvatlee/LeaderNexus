"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, XCircle, Clock, Database } from "lucide-react"
import { createBrowserClient } from "@/lib/supabase/client"

interface TableStatus {
  name: string
  exists: boolean
  rowCount?: number
}

interface BucketStatus {
  name: string
  exists: boolean
}

export function DatabaseStatusChecker() {
  const [tables, setTables] = useState<TableStatus[]>([])
  const [buckets, setBuckets] = useState<BucketStatus[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    checkDatabaseStatus()
  }, [])

  async function checkDatabaseStatus() {
    try {
      const supabase = createBrowserClient()

      // Check critical tables
      const criticalTables = ["viloyat", "tuman", "profiles", "projects", "issues", "notifications", "media_files"]

      const tableStatuses: TableStatus[] = []

      for (const tableName of criticalTables) {
        try {
          const { count, error } = await supabase.from(tableName).select("*", { count: "exact", head: true })

          tableStatuses.push({
            name: tableName,
            exists: !error,
            rowCount: count || 0,
          })
        } catch {
          tableStatuses.push({
            name: tableName,
            exists: false,
          })
        }
      }

      setTables(tableStatuses)

      // Check storage buckets
      const { data: bucketsData } = await supabase.storage.listBuckets()
      const mediaFilesExists = bucketsData?.some((b) => b.id === "media-files") || false

      setBuckets([{ name: "media-files", exists: mediaFilesExists }])
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to check database status")
    } finally {
      setLoading(false)
    }
  }

  const coreTablesReady = tables
    .filter((t) => ["viloyat", "tuman", "profiles"].includes(t.name))
    .every((t) => t.exists && (t.rowCount || 0) > 0)

  const allTablesReady = tables.every((t) => t.exists)
  const mediaReady =
    buckets.find((b) => b.name === "media-files")?.exists && tables.find((t) => t.name === "media_files")?.exists

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="h-4 w-4 animate-spin" />
            <span className="text-sm">Checking database status...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <XCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Database Status
        </CardTitle>
        <CardDescription>Current setup verification</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Core System</span>
            {coreTablesReady ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Ready
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                <XCircle className="h-3 w-3 mr-1" />
                Not Ready
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {coreTablesReady ? "Base tables created and populated with data" : "Run Phase 1 scripts (01, 02, 03)"}
          </p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">All Features</span>
            {allTablesReady ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Complete
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                <Clock className="h-3 w-3 mr-1" />
                Partial
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {allTablesReady ? "All database tables have been created" : "Some tables are missing. Run Phase 2 scripts"}
          </p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Media System</span>
            {mediaReady ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Enabled
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                <XCircle className="h-3 w-3 mr-1" />
                Disabled
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {mediaReady
              ? "Media upload and storage are configured"
              : "Run Phase 3 scripts (018, 020, 021) to enable media"}
          </p>
        </div>

        <div className="pt-4 border-t">
          <details className="text-xs">
            <summary className="cursor-pointer font-medium mb-2">View detailed status</summary>
            <div className="space-y-1 pl-4">
              {tables.map((table) => (
                <div key={table.name} className="flex items-center justify-between">
                  <span className="font-mono text-xs">{table.name}</span>
                  <div className="flex items-center gap-2">
                    {table.exists ? (
                      <>
                        <CheckCircle2 className="h-3 w-3 text-green-600" />
                        {table.rowCount !== undefined && (
                          <span className="text-muted-foreground">{table.rowCount} rows</span>
                        )}
                      </>
                    ) : (
                      <XCircle className="h-3 w-3 text-red-600" />
                    )}
                  </div>
                </div>
              ))}
              {buckets.map((bucket) => (
                <div key={bucket.name} className="flex items-center justify-between">
                  <span className="font-mono text-xs">bucket:{bucket.name}</span>
                  {bucket.exists ? (
                    <CheckCircle2 className="h-3 w-3 text-green-600" />
                  ) : (
                    <XCircle className="h-3 w-3 text-red-600" />
                  )}
                </div>
              ))}
            </div>
          </details>
        </div>
      </CardContent>
    </Card>
  )
}
