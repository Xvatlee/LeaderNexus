"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Bar, BarChart, Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend } from "recharts"
import type { DistrictRating } from "@/lib/types/database.types"

interface ViloyatOverviewChartsProps {
  viloyatId: string
  ratings: DistrictRating[]
}

export function ViloyatOverviewCharts({ viloyatId, ratings }: ViloyatOverviewChartsProps) {
  const chartData = ratings.map((rating) => ({
    name: rating.tuman?.name?.substring(0, 15) || "N/A",
    overall: rating.overall_score || 0,
    projects: rating.project_completion_score || 0,
    engagement: rating.community_engagement_score || 0,
    leadership: rating.leadership_score || 0,
    innovation: rating.innovation_score || 0,
  }))

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Overall Scores Bar Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Tumanlar umumiy reytingi</CardTitle>
          <CardDescription>Har bir tumanning umumiy ko'rsatkichi</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              overall: {
                label: "Umumiy ball",
                color: "hsl(var(--chart-1))",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis domain={[0, 100]} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="overall" fill="var(--color-overall)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Category Comparison */}
      <Card>
        <CardHeader>
          <CardTitle>Mezonlar bo'yicha taqqoslash</CardTitle>
          <CardDescription>Turli ko'rsatkichlarning o'rtacha qiymatlari</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              projects: {
                label: "Loyihalar",
                color: "hsl(var(--chart-1))",
              },
              engagement: {
                label: "Jamoatchilik",
                color: "hsl(var(--chart-2))",
              },
              leadership: {
                label: "Yetakchilik",
                color: "hsl(var(--chart-3))",
              },
              innovation: {
                label: "Innovatsiya",
                color: "hsl(var(--chart-4))",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis domain={[0, 100]} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Legend />
                <Line type="monotone" dataKey="projects" stroke="var(--color-projects)" strokeWidth={2} />
                <Line type="monotone" dataKey="engagement" stroke="var(--color-engagement)" strokeWidth={2} />
                <Line type="monotone" dataKey="leadership" stroke="var(--color-leadership)" strokeWidth={2} />
                <Line type="monotone" dataKey="innovation" stroke="var(--color-innovation)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
