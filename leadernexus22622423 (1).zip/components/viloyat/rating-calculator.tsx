"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calculator, CheckCircle2, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import type { Tuman } from "@/lib/types/database.types"

interface RatingCalculatorProps {
  districts: Tuman[]
  viloyatId: string
}

export function RatingCalculator({ districts, viloyatId }: RatingCalculatorProps) {
  const [selectedDistrict, setSelectedDistrict] = useState<string>("")
  const [ratingPeriod, setRatingPeriod] = useState<string>(new Date().toISOString().split("T")[0])
  const [calculating, setCalculating] = useState(false)
  const { toast } = useToast()

  async function calculateRating() {
    if (!selectedDistrict) {
      toast({
        title: "Xato",
        description: "Tumanni tanlang",
        variant: "destructive",
      })
      return
    }

    setCalculating(true)

    try {
      const response = await fetch("/api/ratings/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tumanId: selectedDistrict,
          ratingPeriod,
        }),
      })

      if (response.ok) {
        const result = await response.json()
        toast({
          title: "Muvaffaqiyatli",
          description: `Reyting hisoblandi: ${result.rating.overall_score.toFixed(1)} ball`,
        })
      } else {
        throw new Error("Calculation failed")
      }
    } catch (error) {
      toast({
        title: "Xato",
        description: "Reytingni hisoblashda xatolik yuz berdi",
        variant: "destructive",
      })
    } finally {
      setCalculating(false)
    }
  }

  async function calculateAllRatings() {
    setCalculating(true)

    try {
      const response = await fetch("/api/ratings/calculate-all", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          viloyatId,
          ratingPeriod,
        }),
      })

      if (response.ok) {
        const result = await response.json()
        toast({
          title: "Muvaffaqiyatli",
          description: result.message,
        })
      } else {
        throw new Error("Batch calculation failed")
      }
    } catch (error) {
      toast({
        title: "Xato",
        description: "Reytinglarni hisoblashda xatolik yuz berdi",
        variant: "destructive",
      })
    } finally {
      setCalculating(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          Reyting kalkulyatori
        </CardTitle>
        <CardDescription>Tumanlar reytingini hisoblash va yangilash</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium">Tuman</label>
            <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
              <SelectTrigger>
                <SelectValue placeholder="Tumanni tanlang" />
              </SelectTrigger>
              <SelectContent>
                {districts.map((district) => (
                  <SelectItem key={district.id} value={district.id}>
                    {district.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Reyting davri</label>
            <input
              type="date"
              value={ratingPeriod}
              onChange={(e) => setRatingPeriod(e.target.value)}
              className="w-full h-10 px-3 rounded-md border border-input bg-background"
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={calculateRating} disabled={calculating || !selectedDistrict}>
            <CheckCircle2 className="h-4 w-4 mr-2" />
            {calculating ? "Hisoblanmoqda..." : "Tanlangan tumanni hisoblash"}
          </Button>

          <Button onClick={calculateAllRatings} disabled={calculating} variant="outline">
            <Calculator className="h-4 w-4 mr-2" />
            {calculating ? "Hisoblanmoqda..." : "Barcha tumanlarni hisoblash"}
          </Button>
        </div>

        <div className="mt-4 p-4 bg-muted rounded-lg">
          <h4 className="font-semibold flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4" />
            Hisoblash mezonlari
          </h4>
          <ul className="text-sm space-y-1 text-muted-foreground">
            <li>• Loyihalar muvaffaqiyati: 30%</li>
            <li>• Jamoatchilik ishtiroki: 30%</li>
            <li>• Yetakchilik qobiliyati: 25%</li>
            <li>• Innovatsiya: 15%</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
