"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Target, Calendar, TrendingUp } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { Project, Tuman } from "@/lib/types/database.types"
import Link from "next/link"

interface ProjectsOverviewProps {
  viloyatId: string
  districts: Tuman[]
}

export function ProjectsOverview({ viloyatId, districts }: ProjectsOverviewProps) {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadProjects()
  }, [viloyatId])

  async function loadProjects() {
    const supabase = createClient()

    const districtIds = districts.map((d) => d.id)

    const { data, error } = await supabase
      .from("projects")
      .select("*, tuman:tuman_id(*), created_by:created_by(*)")
      .in("tuman_id", districtIds)
      .order("created_at", { ascending: false })
      .limit(20)

    if (!error && data) {
      setProjects(data)
    }

    setLoading(false)
  }

  function getStatusBadge(status: string) {
    const statusMap = {
      planning: { label: "Rejalashtirish", variant: "secondary" as const },
      in_progress: { label: "Jarayonda", variant: "default" as const },
      completed: { label: "Tugallangan", variant: "default" as const },
      on_hold: { label: "To'xtatilgan", variant: "secondary" as const },
      cancelled: { label: "Bekor qilingan", variant: "destructive" as const },
    }
    const config = statusMap[status as keyof typeof statusMap] || statusMap.planning
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  if (loading) {
    return <div className="text-center py-8">Yuklanmoqda...</div>
  }

  return (
    <div className="space-y-6">
      {/* Project Statistics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Jami loyihalar</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{projects.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Jarayonda</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-blue-600">
              {projects.filter((p) => p.status === "in_progress").length}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Tugallangan</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-600">
              {projects.filter((p) => p.status === "completed").length}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">O'rtacha progress</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">
              {projects.length > 0
                ? (projects.reduce((sum, p) => sum + (p.progress_percentage || 0), 0) / projects.length).toFixed(0)
                : 0}
              %
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Projects List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            So'nggi loyihalar
          </CardTitle>
          <CardDescription>Viloyatdagi barcha aktiv va tugallangan loyihalar</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {projects.map((project) => (
              <div key={project.id} className="flex items-start gap-4 p-4 rounded-lg border">
                <div className="flex-1 space-y-2">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h4 className="font-semibold">{project.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2">{project.description}</p>
                    </div>
                    {getStatusBadge(project.status)}
                  </div>

                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Target className="h-3 w-3" />
                      {project.tuman?.name}
                    </span>
                    {project.start_date && (
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {new Date(project.start_date).toLocaleDateString()}
                      </span>
                    )}
                    {project.budget && (
                      <span className="flex items-center gap-1">
                        <TrendingUp className="h-3 w-3" />
                        {project.budget.toLocaleString()} so'm
                      </span>
                    )}
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span>Progress</span>
                      <span className="font-semibold">{project.progress_percentage}%</span>
                    </div>
                    <Progress value={project.progress_percentage || 0} className="h-2" />
                  </div>
                </div>

                <Button asChild variant="outline" size="sm">
                  <Link href={`/projects/${project.id}`}>Ko'rish</Link>
                </Button>
              </div>
            ))}

            {projects.length === 0 && (
              <div className="text-center py-12">
                <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Hozircha loyihalar yo'q</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
