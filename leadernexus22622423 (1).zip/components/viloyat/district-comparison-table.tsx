"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface DistrictComparison {
  id: string
  name: string
  rating: number
  ratingChange: number
  completedTasks: number
  totalTasks: number
  activeLeaders: number
  pendingReports: number
}

interface DistrictComparisonTableProps {
  districts?: DistrictComparison[]
  title?: string
}

export function DistrictComparisonTable({ 
  districts = [],
  title = "Tumanlar reytingi"
}: DistrictComparisonTableProps) {
  const getRatingBadge = (rating: number) => {
    if (rating >= 80) return "default"
    if (rating >= 60) return "secondary"
    if (rating >= 40) return "outline"
    return "destructive"
  }

  const getRatingChangeDisplay = (change: number) => {
    if (change > 0) {
      return (
        <div className="flex items-center gap-1 text-green-600">
          <TrendingUp className="h-4 w-4" />
          <span>+{change}</span>
        </div>
      )
    }
    if (change < 0) {
      return (
        <div className="flex items-center gap-1 text-red-600">
          <TrendingDown className="h-4 w-4" />
          <span>{change}</span>
        </div>
      )
    }
    return (
      <div className="flex items-center gap-1 text-muted-foreground">
        <Minus className="h-4 w-4" />
        <span>0</span>
      </div>
    )
  }

  const sortedDistricts = [...districts].sort((a, b) => b.rating - a.rating)

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {sortedDistricts.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            Ma'lumotlar mavjud emas
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead>Tuman</TableHead>
                <TableHead>Reyting</TableHead>
                <TableHead>O'zgarish</TableHead>
                <TableHead>Vazifalar</TableHead>
                <TableHead>Liderlar</TableHead>
                <TableHead>Kutilayotgan</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedDistricts.map((district, index) => (
                <TableRow key={district.id}>
                  <TableCell className="font-bold text-muted-foreground">
                    {index + 1}
                  </TableCell>
                  <TableCell className="font-medium">{district.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={district.rating} className="w-16 h-2" />
                      <Badge variant={getRatingBadge(district.rating)}>
                        {district.rating}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    {getRatingChangeDisplay(district.ratingChange)}
                  </TableCell>
                  <TableCell>
                    <span className="text-green-600">{district.completedTasks}</span>
                    <span className="text-muted-foreground"> / {district.totalTasks}</span>
                  </TableCell>
                  <TableCell>{district.activeLeaders}</TableCell>
                  <TableCell>
                    {district.pendingReports > 0 ? (
                      <Badge variant="outline">{district.pendingReports}</Badge>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  )
}
