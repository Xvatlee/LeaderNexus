"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertCircle, Clock, CheckCircle2, XCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { Issue, Tuman } from "@/lib/types/database.types"
import Link from "next/link"

interface IssuesTrackingProps {
  viloyatId: string
  districts: Tuman[]
}

export function IssuesTracking({ viloyatId, districts }: IssuesTrackingProps) {
  const [issues, setIssues] = useState<Issue[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadIssues()
  }, [viloyatId])

  async function loadIssues() {
    const supabase = createClient()

    const districtIds = districts.map((d) => d.id)

    const { data, error } = await supabase
      .from("issues")
      .select("*, tuman:tuman_id(*), reported_by:reported_by(*)")
      .in("tuman_id", districtIds)
      .order("created_at", { ascending: false })
      .limit(20)

    if (!error && data) {
      setIssues(data)
    }

    setLoading(false)
  }

  function getPriorityBadge(priority: string) {
    const priorityMap = {
      low: { label: "Past", variant: "secondary" as const, color: "text-gray-600" },
      medium: { label: "O'rta", variant: "secondary" as const, color: "text-blue-600" },
      high: { label: "Yuqori", variant: "default" as const, color: "text-orange-600" },
      critical: { label: "Juda muhim", variant: "destructive" as const, color: "text-red-600" },
    }
    const config = priorityMap[priority as keyof typeof priorityMap] || priorityMap.medium
    return (
      <Badge variant={config.variant} className={config.color}>
        {config.label}
      </Badge>
    )
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case "open":
        return <AlertCircle className="h-4 w-4 text-orange-600" />
      case "in_progress":
        return <Clock className="h-4 w-4 text-blue-600" />
      case "resolved":
        return <CheckCircle2 className="h-4 w-4 text-green-600" />
      case "closed":
        return <XCircle className="h-4 w-4 text-gray-600" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  function getStatusLabel(status: string) {
    const statusMap = {
      open: "Ochiq",
      in_progress: "Hal qilinmoqda",
      resolved: "Hal qilindi",
      closed: "Yopilgan",
    }
    return statusMap[status as keyof typeof statusMap] || status
  }

  if (loading) {
    return <div className="text-center py-8">Yuklanmoqda...</div>
  }

  const activeIssues = issues.filter((i) => i.status === "open" || i.status === "in_progress")
  const resolvedIssues = issues.filter((i) => i.status === "resolved" || i.status === "closed")

  return (
    <div className="space-y-6">
      {/* Issues Statistics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Jami muammolar</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{issues.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Aktiv</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-orange-600">{activeIssues.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Hal qilindi</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-600">{resolvedIssues.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Hal qilish foizi</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">
              {issues.length > 0 ? ((resolvedIssues.length / issues.length) * 100).toFixed(0) : 0}%
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Active Issues */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-orange-600" />
            Aktiv muammolar
          </CardTitle>
          <CardDescription>Hal qilish talab qiladigan muammolar</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {activeIssues.map((issue) => (
              <div key={issue.id} className="flex items-start gap-4 p-4 rounded-lg border">
                <div className="mt-1">{getStatusIcon(issue.status)}</div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h4 className="font-semibold">{issue.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2">{issue.description}</p>
                    </div>
                    {getPriorityBadge(issue.priority)}
                  </div>

                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                    <span>{issue.tuman?.name}</span>
                    <span>•</span>
                    <span>{getStatusLabel(issue.status)}</span>
                    <span>•</span>
                    <span>{new Date(issue.created_at).toLocaleDateString()}</span>
                  </div>
                </div>

                <Button asChild variant="outline" size="sm">
                  <Link href={`/viloyat/issues/${issue.id}`}>Ko'rish</Link>
                </Button>
              </div>
            ))}

            {activeIssues.length === 0 && (
              <div className="text-center py-8">
                <CheckCircle2 className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <p className="text-muted-foreground">Barcha muammolar hal qilindi!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
