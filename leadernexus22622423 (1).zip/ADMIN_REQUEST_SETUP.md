# Admin Request Approval System - Setup Guide

This system prevents users from self-assigning admin privileges. All admin requests must be approved by the super admin.

## Overview

The system works as follows:
1. Users can only register as **Leaders** (admin role removed from registration)
2. Leaders can request admin privileges from their dashboard
3. Super admin receives email notification with approve/reject links
4. Only approved users gain admin access
5. All operations are secured at the database level with RLS

## Database Setup

### 1. Run the Migration Script

Execute the SQL script to create the necessary tables:

\`\`\`bash
# In your v0 project, run this script:
scripts/022_create_admin_request_system.sql
\`\`\`

This creates:
- `admins` table - stores approved admin users
- `admin_requests` table - tracks all admin privilege requests
- Proper RLS policies to prevent client-side role manipulation

### 2. Verify Tables Created

Check that these tables exist in your Supabase database:
- `admins`
- `admin_requests`

## Environment Variables

Add these to your project's environment variables (in v0 Vars section or `.env.local`):

\`\`\`env
# Required
SUPER_ADMIN_EMAIL=xvatkee@gmail.com
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
APP_URL=https://yourdomain.com

# Optional (for email notifications)
RESEND_API_KEY=your_resend_api_key
\`\`\`

### Getting a Resend API Key

1. Sign up at [resend.com](https://resend.com)
2. Verify your domain (or use their test domain for development)
3. Create an API key in the dashboard
4. Add it to your environment variables

**Note:** Email notifications are optional. If `RESEND_API_KEY` is not set, the system will still work but approval links will be logged to console instead of emailed.

## How It Works

### For Leaders (Regular Users)

1. **Registration**: Users can only register as "Leader" role
2. **Request Admin Access**: 
   - Go to Leader Dashboard
   - Find "Admin Access Request" card
   - Enter reason (optional) and submit
3. **Status Tracking**: View request status (pending/approved/rejected)

### For Super Admin (xvatkee@gmail.com)

1. **Receive Notification**: Get email when user requests admin access
2. **Review Request**: Email contains:
   - Requester details (name, email)
   - Reason for request
   - Approve button (secure link, 60 min expiry)
   - Reject button
3. **Take Action**: Click approve or reject
4. **Result**: User is granted admin privileges or remains as leader

### Security Features

✅ **RLS Policies**: Users cannot directly modify their role or admin status
✅ **Server-Only Operations**: Admin approval happens server-side with service role
✅ **Token Security**: Approval links use hashed tokens with expiration
✅ **Single Pending Request**: Users cannot spam multiple requests
✅ **Super Admin Verification**: Only designated super admin email can approve

## API Endpoints

### Submit Admin Request
\`\`\`
POST /api/admin-requests
Body: { reason: "string (optional)" }
\`\`\`

### Check Request Status
\`\`\`
GET /api/admin-requests
Returns: { request: {...}, isAdmin: boolean }
\`\`\`

### Approve Request (Token-based)
\`\`\`
GET /api/admin-requests/[id]/approve?token=xxx
\`\`\`

### Reject Request (Token-based)
\`\`\`
GET /api/admin-requests/[id]/reject?token=xxx
\`\`\`

## Testing

### 1. Create Test Request

1. Register as a leader
2. Log in and go to Leader Dashboard
3. Find "Admin Access Request" card
4. Submit a request with a test reason

### 2. Check Email or Console

**With RESEND_API_KEY set:**
- Check super admin email inbox for approval email

**Without RESEND_API_KEY:**
- Check server console logs for approval URLs
- Copy the approve URL and paste in browser

### 3. Verify Admin Access

After approval:
- User should see admin navigation options
- User can access `/admin` routes
- `admins` table has entry for user
- `profiles.role` is updated to "admin"

## Troubleshooting

### Request Not Created
- Check that script 022 was executed successfully
- Verify RLS policies are enabled
- Check browser console for errors

### Email Not Received
- Verify `RESEND_API_KEY` is set correctly
- Check Resend dashboard for email status
- Look for approval URLs in server console logs
- Verify `SUPER_ADMIN_EMAIL` is correct

### Approval Link Expired
- Tokens expire after 60 minutes
- User needs to submit a new request
- Old requests are kept for audit trail

### User Still Not Admin
- Check `admins` table has entry for user_id
- Verify `profiles.role` was updated to "admin"
- Clear browser cache and re-login
- Check server logs for errors during approval

## Manual Admin Promotion (Emergency)

If needed, you can manually promote a user to admin using the service role key:

\`\`\`sql
-- Add to admins table
INSERT INTO admins (user_id, notes)
VALUES ('user-uuid-here', 'Manually promoted');

-- Update profile role
UPDATE profiles 
SET role = 'admin' 
WHERE id = 'user-uuid-here';
\`\`\`

## Security Best Practices

1. **Keep Service Role Key Secret**: Never expose `SUPABASE_SERVICE_ROLE_KEY` in client code
2. **Monitor Admin Requests**: Regularly check `admin_requests` table for suspicious patterns
3. **Audit Trail**: The system keeps all requests (pending/approved/rejected) for audit purposes
4. **Token Expiry**: Approval links expire in 60 minutes - don't extend this unnecessarily
5. **Single Super Admin**: Keep `SUPER_ADMIN_EMAIL` limited to trusted administrators

## Database Schema

### admins
\`\`\`sql
user_id UUID PRIMARY KEY
created_at TIMESTAMPTZ
created_by UUID (nullable)
notes TEXT (nullable)
\`\`\`

### admin_requests
\`\`\`sql
id UUID PRIMARY KEY
user_id UUID (references auth.users)
email TEXT
reason TEXT (nullable)
status TEXT (pending/approved/rejected)
created_at TIMESTAMPTZ
reviewed_at TIMESTAMPTZ (nullable)
reviewed_by UUID (nullable)
token_hash TEXT
token_expires_at TIMESTAMPTZ
\`\`\`

## Next Steps

After setup:
1. Test the entire flow with a test account
2. Update your domain in `APP_URL` for production
3. Set up Resend domain verification for production emails
4. Monitor the `admin_requests` table for requests
5. Document your admin approval workflow for your team
