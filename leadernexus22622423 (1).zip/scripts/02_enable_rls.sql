-- Enable Row Level Security on all tables
ALTER TABLE viloyat ENABLE ROW LEVEL SECURITY;
ALTER TABLE tuman ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE district_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE issues ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_metrics ENABLE ROW LEVEL SECURITY;

-- Viloyat policies: Everyone can read, only admins can modify
CREATE POLICY "Anyone can view viloyat" ON viloyat
  FOR SELECT USING (true);

CREATE POLICY "Only admins can insert viloyat" ON viloyat
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Only admins can update viloyat" ON viloyat
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Tuman policies: Everyone can read, admins and viloyat sardori can modify their region
CREATE POLICY "Anyone can view tuman" ON tuman
  FOR SELECT USING (true);

CREATE POLICY "Admins and viloyat sardori can insert tuman" ON tuman
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() 
      AND (role = 'admin' OR (role = 'viloyat_sardori' AND viloyat_id = tuman.viloyat_id))
    )
  );

CREATE POLICY "Admins and viloyat sardori can update tuman" ON tuman
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() 
      AND (role = 'admin' OR (role = 'viloyat_sardori' AND viloyat_id = tuman.viloyat_id))
    )
  );

-- Profiles policies
CREATE POLICY "Users can view profiles in their region" ON profiles
  FOR SELECT USING (
    auth.uid() = id OR
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() 
      AND (
        p.role = 'admin' OR
        (p.role = 'viloyat_sardori' AND p.viloyat_id = profiles.viloyat_id) OR
        (p.role = 'tuman_sardori' AND p.viloyat_id = profiles.viloyat_id)
      )
    )
  );

CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "New users can insert their profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Projects policies
CREATE POLICY "Anyone in viloyat can view projects" ON projects
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON projects.tuman_id = t.id
      WHERE p.id = auth.uid() AND p.viloyat_id = t.viloyat_id
    )
  );

CREATE POLICY "Tuman sardori can manage their district projects" ON projects
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() 
      AND tuman_id = projects.tuman_id
    )
  );

CREATE POLICY "Viloyat sardori can view all projects in their region" ON projects
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON projects.tuman_id = t.id
      WHERE p.id = auth.uid() 
      AND p.role = 'viloyat_sardori' 
      AND p.viloyat_id = t.viloyat_id
    )
  );

-- Project milestones policies
CREATE POLICY "View milestones if can view project" ON project_milestones
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM projects p
      JOIN tuman t ON p.tuman_id = t.id
      JOIN profiles pr ON pr.id = auth.uid()
      WHERE p.id = project_milestones.project_id
      AND pr.viloyat_id = t.viloyat_id
    )
  );

CREATE POLICY "Manage milestones if can manage project" ON project_milestones
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM projects p
      JOIN profiles pr ON pr.id = auth.uid()
      WHERE p.id = project_milestones.project_id
      AND pr.tuman_id = p.tuman_id
    )
  );

-- District ratings policies
CREATE POLICY "Anyone in viloyat can view ratings" ON district_ratings
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON district_ratings.tuman_id = t.id
      WHERE p.id = auth.uid() AND p.viloyat_id = t.viloyat_id
    )
  );

CREATE POLICY "Only viloyat sardori and admins can manage ratings" ON district_ratings
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON district_ratings.tuman_id = t.id
      WHERE p.id = auth.uid() 
      AND (p.role = 'admin' OR (p.role = 'viloyat_sardori' AND p.viloyat_id = t.viloyat_id))
    )
  );

-- Activities policies
CREATE POLICY "Anyone in viloyat can view activities" ON activities
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON activities.tuman_id = t.id
      WHERE p.id = auth.uid() AND p.viloyat_id = t.viloyat_id
    )
  );

CREATE POLICY "Tuman sardori can manage their activities" ON activities
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() 
      AND tuman_id = activities.tuman_id
    )
  );

-- Issues policies
CREATE POLICY "Anyone in viloyat can view issues" ON issues
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON issues.tuman_id = t.id
      WHERE p.id = auth.uid() AND p.viloyat_id = t.viloyat_id
    )
  );

CREATE POLICY "Anyone can report issues" ON issues
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid())
  );

CREATE POLICY "Assigned users and leaders can update issues" ON issues
  FOR UPDATE USING (
    auth.uid() = assigned_to OR
    auth.uid() = reported_by OR
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON issues.tuman_id = t.id
      WHERE p.id = auth.uid() 
      AND (
        p.tuman_id = issues.tuman_id OR 
        (p.role = 'viloyat_sardori' AND p.viloyat_id = t.viloyat_id)
      )
    )
  );

-- Feedback policies
CREATE POLICY "Users can view feedback they sent or received" ON feedback
  FOR SELECT USING (
    auth.uid() = from_user OR 
    auth.uid() = to_user OR
    is_public = true
  );

CREATE POLICY "Users can insert feedback" ON feedback
  FOR INSERT WITH CHECK (auth.uid() = from_user);

-- Notifications policies
CREATE POLICY "Users can view their own notifications" ON notifications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" ON notifications
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "System can insert notifications" ON notifications
  FOR INSERT WITH CHECK (true);

-- Performance metrics policies
CREATE POLICY "Anyone in viloyat can view metrics" ON performance_metrics
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON performance_metrics.tuman_id = t.id
      WHERE p.id = auth.uid() AND p.viloyat_id = t.viloyat_id
    )
  );

CREATE POLICY "Leaders can manage metrics" ON performance_metrics
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN tuman t ON performance_metrics.tuman_id = t.id
      WHERE p.id = auth.uid() 
      AND (
        p.tuman_id = performance_metrics.tuman_id OR 
        (p.role = 'viloyat_sardori' AND p.viloyat_id = t.viloyat_id) OR
        p.role = 'admin'
      )
    )
  );
