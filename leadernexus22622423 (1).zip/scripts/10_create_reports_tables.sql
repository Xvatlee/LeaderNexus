-- Create tables for the reporting and monitoring system

-- Reports table for monthly and yearly reports
CREATE TABLE IF NOT EXISTS reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  district_id UUID NOT NULL REFERENCES districts(id) ON DELETE CASCADE,
  report_type VARCHAR(20) NOT NULL CHECK (report_type IN ('monthly', 'yearly')),
  report_period VARCHAR(20) NOT NULL, -- e.g., "2025-01" for monthly, "2025" for yearly
  
  -- Report content sections
  title VARCHAR(255) NOT NULL,
  summary TEXT,
  
  -- Project updates
  completed_projects_count INTEGER DEFAULT 0,
  ongoing_projects_count INTEGER DEFAULT 0,
  projects_details JSONB DEFAULT '[]'::jsonb,
  
  -- Community engagement
  events_count INTEGER DEFAULT 0,
  initiatives_count INTEGER DEFAULT 0,
  participation_rate DECIMAL(5,2), -- percentage
  community_activities JSONB DEFAULT '[]'::jsonb,
  
  -- Performance metrics
  project_success_rate DECIMAL(5,2),
  leadership_effectiveness_score DECIMAL(5,2),
  innovation_score DECIMAL(5,2),
  performance_metrics JSONB DEFAULT '{}'::jsonb,
  
  -- Challenges and solutions
  challenges_faced TEXT,
  solutions_implemented TEXT,
  
  -- Status and metadata
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'reviewed', 'approved')),
  submitted_at TIMESTAMPTZ,
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES auth.users(id),
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Report feedback and ratings from Viloyat sardori
CREATE TABLE IF NOT EXISTS report_feedback (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  report_id UUID NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Ratings
  overall_rating INTEGER CHECK (overall_rating BETWEEN 1 AND 5),
  project_success_rating INTEGER CHECK (project_success_rating BETWEEN 1 AND 5),
  community_participation_rating INTEGER CHECK (community_participation_rating BETWEEN 1 AND 5),
  leadership_rating INTEGER CHECK (leadership_rating BETWEEN 1 AND 5),
  
  -- Feedback text
  feedback_text TEXT,
  suggestions TEXT,
  areas_for_improvement TEXT,
  
  -- Status
  is_read BOOLEAN DEFAULT FALSE,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Report comments for communication between Viloyat and Tuman sardorlari
CREATE TABLE IF NOT EXISTS report_comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  report_id UUID NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  parent_comment_id UUID REFERENCES report_comments(id) ON DELETE CASCADE,
  
  comment_text TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Report alerts for missing or overdue reports
CREATE TABLE IF NOT EXISTS report_alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  district_id UUID NOT NULL REFERENCES districts(id) ON DELETE CASCADE,
  report_type VARCHAR(20) NOT NULL CHECK (report_type IN ('monthly', 'yearly')),
  expected_period VARCHAR(20) NOT NULL,
  
  alert_type VARCHAR(30) NOT NULL CHECK (alert_type IN ('missing', 'overdue', 'reminder')),
  alert_message TEXT NOT NULL,
  
  is_resolved BOOLEAN DEFAULT FALSE,
  resolved_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Audit trail for tracking changes
CREATE TABLE IF NOT EXISTS report_audit_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  report_id UUID REFERENCES reports(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id),
  
  action VARCHAR(50) NOT NULL, -- e.g., 'created', 'updated', 'submitted', 'reviewed', 'approved'
  changes JSONB, -- stores what changed
  ip_address INET,
  user_agent TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_reports_user_id ON reports(user_id);
CREATE INDEX IF NOT EXISTS idx_reports_district_id ON reports(district_id);
CREATE INDEX IF NOT EXISTS idx_reports_type_period ON reports(report_type, report_period);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_report_feedback_report_id ON report_feedback(report_id);
CREATE INDEX IF NOT EXISTS idx_report_feedback_reviewer_id ON report_feedback(reviewer_id);
CREATE INDEX IF NOT EXISTS idx_report_comments_report_id ON report_comments(report_id);
CREATE INDEX IF NOT EXISTS idx_report_alerts_district_id ON report_alerts(district_id);
CREATE INDEX IF NOT EXISTS idx_report_alerts_resolved ON report_alerts(is_resolved);
CREATE INDEX IF NOT EXISTS idx_audit_log_report_id ON report_audit_log(report_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_user_id ON report_audit_log(user_id);

-- Create unique constraint to prevent duplicate reports for same period
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_district_report_period 
ON reports(district_id, report_type, report_period) 
WHERE status != 'draft';

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_reports_updated_at BEFORE UPDATE ON reports
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_report_feedback_updated_at BEFORE UPDATE ON report_feedback
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_report_comments_updated_at BEFORE UPDATE ON report_comments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to create audit log entry
CREATE OR REPLACE FUNCTION create_report_audit_log()
RETURNS TRIGGER AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    INSERT INTO report_audit_log (report_id, user_id, action, changes)
    VALUES (NEW.id, NEW.user_id, 'created', row_to_json(NEW)::jsonb);
    RETURN NEW;
  ELSIF (TG_OP = 'UPDATE') THEN
    INSERT INTO report_audit_log (report_id, user_id, action, changes)
    VALUES (NEW.id, NEW.user_id, 'updated', jsonb_build_object(
      'old', row_to_json(OLD)::jsonb,
      'new', row_to_json(NEW)::jsonb
    ));
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger for audit logging
CREATE TRIGGER report_audit_trigger
AFTER INSERT OR UPDATE ON reports
FOR EACH ROW EXECUTE FUNCTION create_report_audit_log();
