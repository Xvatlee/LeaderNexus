-- Create storage bucket for media files if it doesn't exist
DO $$
BEGIN
  -- Added error handling to check if bucket exists before insertion
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'media-files') THEN
    INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
    VALUES (
      'media-files',
      'media-files',
      true,
      52428800, -- 50MB in bytes
      ARRAY[
        'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp',
        'video/mp4', 'video/webm', 'video/quicktime',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      ]
    );
  END IF;
END $$;

-- Drop existing policies before creating to avoid conflicts
DROP POLICY IF EXISTS "Authenticated users can upload media" ON storage.objects;
DROP POLICY IF EXISTS "Public media files are viewable by everyone" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their own media files" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own media files" ON storage.objects;

-- Storage policies for media files
CREATE POLICY "Authenticated users can upload media"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'media-files');

CREATE POLICY "Public media files are viewable by everyone"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'media-files');

CREATE POLICY "Users can update their own media files"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'media-files');

CREATE POLICY "Users can delete their own media files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'media-files');
