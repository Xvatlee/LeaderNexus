-- Replaced all regions with only Surxondaryo viloyati and its 14 districts

-- Insert only Surxondaryo viloyati
INSERT INTO viloyat (id, name, description) VALUES
  ('11111111-1111-1111-1111-111111111111', 'Surxondaryo viloyati', 'Southern region with 14 districts');

-- Insert all 14 tuman (districts) of Surxondaryo viloyati
INSERT INTO tuman (id, viloyat_id, name, description, population, area_km2) VALUES
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 'Angor tumani', 'Border district', 45000, 620.5),
  ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '11111111-1111-1111-1111-111111111111', 'Boysun tumani', 'Mountain district with UNESCO heritage', 58000, 980.2),
  ('cccccccc-cccc-cccc-cccc-cccccccccccc', '11111111-1111-1111-1111-111111111111', 'Denov tumani', 'Agricultural district', 145000, 720.8),
  ('dddddddd-dddd-dddd-dddd-dddddddddddd', '11111111-1111-1111-1111-111111111111', 'Jarqorgon tumani', 'Agricultural and trade district', 95000, 450.3),
  ('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', '11111111-1111-1111-1111-111111111111', 'Muzrabot tumani', 'Rural district', 72000, 580.7),
  ('ffffffff-ffff-ffff-ffff-ffffffffffff', '11111111-1111-1111-1111-111111111111', 'Qumqo''rg''on tumani', 'Desert district', 68000, 920.4),
  ('11111111-2222-3333-4444-555555555555', '11111111-1111-1111-1111-111111111111', 'Sariosiyo tumani', 'Central district', 82000, 540.6),
  ('22222222-3333-4444-5555-666666666666', '11111111-1111-1111-1111-111111111111', 'Sherobod tumani', 'Industrial district', 125000, 680.9),
  ('33333333-4444-5555-6666-777777777777', '11111111-1111-1111-1111-111111111111', 'Shurchi tumani', 'Agricultural district', 98000, 590.2),
  ('44444444-5555-6666-7777-888888888888', '11111111-1111-1111-1111-111111111111', 'Termiz shahri', 'Regional capital city', 185000, 95.5),
  ('55555555-6666-7777-8888-999999999999', '11111111-1111-1111-1111-111111111111', 'Uzun tumani', 'Border district', 52000, 640.3),
  ('66666666-7777-8888-9999-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 'Oltinsoy tumani', 'Rural district', 48000, 510.8),
  ('77777777-8888-9999-aaaa-bbbbbbbbbbbb', '11111111-1111-1111-1111-111111111111', 'Bandixon tumani', 'Agricultural district', 38000, 480.5),
  ('88888888-9999-aaaa-bbbb-cccccccccccc', '11111111-1111-1111-1111-111111111111', 'Altynkul tumani', 'Rural district', 42000, 520.7);

-- Sample district ratings for all 14 districts
INSERT INTO district_ratings (tuman_id, rating_period, overall_score, project_completion_score, community_engagement_score, leadership_score, innovation_score, rank) VALUES
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2025-01-01', 78.5, 75.0, 80.0, 78.0, 81.0, 11),
  ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '2025-01-01', 85.3, 88.0, 83.0, 85.0, 85.0, 5),
  ('cccccccc-cccc-cccc-cccc-cccccccccccc', '2025-01-01', 91.2, 95.0, 88.0, 92.0, 90.0, 1),
  ('dddddddd-dddd-dddd-dddd-dddddddddddd', '2025-01-01', 82.6, 85.0, 80.0, 83.0, 82.0, 7),
  ('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', '2025-01-01', 76.9, 73.0, 78.0, 77.0, 79.0, 13),
  ('ffffffff-ffff-ffff-ffff-ffffffffffff', '2025-01-01', 79.4, 82.0, 77.0, 80.0, 78.0, 10),
  ('11111111-2222-3333-4444-555555555555', '2025-01-01', 87.2, 90.0, 85.0, 88.0, 86.0, 3),
  ('22222222-3333-4444-5555-666666666666', '2025-01-01', 89.8, 92.0, 88.0, 90.0, 89.0, 2),
  ('33333333-4444-5555-6666-777777777777', '2025-01-01', 83.5, 86.0, 81.0, 84.0, 83.0, 6),
  ('44444444-5555-6666-7777-888888888888', '2025-01-01', 86.7, 89.0, 84.0, 87.0, 87.0, 4),
  ('55555555-6666-7777-8888-999999999999', '2025-01-01', 77.8, 76.0, 79.0, 78.0, 78.0, 12),
  ('66666666-7777-8888-9999-aaaaaaaaaaaa', '2025-01-01', 80.4, 83.0, 78.0, 81.0, 79.0, 9),
  ('77777777-8888-9999-aaaa-bbbbbbbbbbbb', '2025-01-01', 74.6, 72.0, 76.0, 75.0, 75.0, 14),
  ('88888888-9999-aaaa-bbbb-cccccccccccc', '2025-01-01', 81.2, 84.0, 79.0, 82.0, 80.0, 8);
