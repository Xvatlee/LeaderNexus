-- Added checks to ensure tables exist before creating triggers

-- Function to notify on project status change
CREATE OR REPLACE FUNCTION notify_project_status_change()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO notifications (user_id, title, message, type, link)
    SELECT 
      p.id,
      'Loyiha holati o''zgartirildi',
      'Loyiha "' || NEW.title || '" holati: ' || NEW.status,
      'project_update',
      '/projects/' || NEW.id
    FROM profiles p
    WHERE p.tuman_id = NEW.tuman_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing triggers before creating to avoid conflicts
DROP TRIGGER IF EXISTS project_status_change_trigger ON projects;
DROP TRIGGER IF EXISTS issue_assignment_trigger ON issues;
DROP TRIGGER IF EXISTS issue_resolution_trigger ON issues;
DROP TRIGGER IF EXISTS rating_update_trigger ON district_ratings;
DROP TRIGGER IF EXISTS new_project_notification_trigger ON projects;

-- Trigger for project status changes (only if projects table exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'projects') THEN
    CREATE TRIGGER project_status_change_trigger
      AFTER UPDATE ON projects
      FOR EACH ROW
      EXECUTE FUNCTION notify_project_status_change();
  END IF;
END $$;

-- Function to notify on issue assignment
CREATE OR REPLACE FUNCTION notify_issue_assignment()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.assigned_to IS NOT NULL AND (OLD.assigned_to IS NULL OR OLD.assigned_to != NEW.assigned_to) THEN
    INSERT INTO notifications (user_id, title, message, type, link)
    VALUES (
      NEW.assigned_to,
      'Sizga muammo tayinlandi',
      'Yangi muammo: ' || NEW.title,
      'issue_assigned',
      '/viloyat/issues/' || NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for issue assignment (only if issues table exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'issues') THEN
    CREATE TRIGGER issue_assignment_trigger
      AFTER INSERT OR UPDATE ON issues
      FOR EACH ROW
      EXECUTE FUNCTION notify_issue_assignment();
  END IF;
END $$;

-- Function to notify on issue resolution
CREATE OR REPLACE FUNCTION notify_issue_resolution()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status IN ('resolved', 'closed') AND OLD.status NOT IN ('resolved', 'closed') THEN
    INSERT INTO notifications (user_id, title, message, type, link)
    VALUES (
      NEW.reported_by,
      'Muammo hal qilindi',
      '"' || NEW.title || '" muammosi hal qilindi',
      'issue_resolved',
      '/viloyat/issues/' || NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for issue resolution (only if issues table exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'issues') THEN
    CREATE TRIGGER issue_resolution_trigger
      AFTER UPDATE ON issues
      FOR EACH ROW
      EXECUTE FUNCTION notify_issue_resolution();
  END IF;
END $$;

-- Function to notify on rating updates
CREATE OR REPLACE FUNCTION notify_rating_update()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.overall_score IS DISTINCT FROM NEW.overall_score THEN
    INSERT INTO notifications (user_id, title, message, type, link)
    SELECT 
      p.id,
      'Reytingingiz yangilandi',
      'Yangi reyting: ' || ROUND(NEW.overall_score::numeric, 1) || ' (O''rin: ' || COALESCE(NEW.rank::text, 'N/A') || ')',
      'rating_change',
      '/tuman/dashboard'
    FROM profiles p
    WHERE p.tuman_id = NEW.tuman_id AND p.role = 'tuman_sardori';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for rating updates (only if district_ratings table exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'district_ratings') THEN
    CREATE TRIGGER rating_update_trigger
      AFTER UPDATE ON district_ratings
      FOR EACH ROW
      EXECUTE FUNCTION notify_rating_update();
  END IF;
END $$;

-- Function to send activity reminders (called manually or via cron)
CREATE OR REPLACE FUNCTION send_activity_reminders()
RETURNS void AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'activities') THEN
    INSERT INTO notifications (user_id, title, message, type, link)
    SELECT 
      p.id,
      'Tadbir eslatmasi',
      '"' || a.title || '" tadbiriga ' || TO_CHAR(a.start_date, 'DD.MM.YYYY') || ' da qatnashing',
      'activity_reminder',
      '/tuman/activities/' || a.id
    FROM activities a
    JOIN profiles p ON p.tuman_id = a.tuman_id
    WHERE a.start_date::date = CURRENT_DATE + INTERVAL '1 day'
      AND a.start_date > NOW();
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to notify viloyat sardori about new projects
CREATE OR REPLACE FUNCTION notify_viloyat_new_project()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO notifications (user_id, title, message, type, link)
  SELECT 
    p.id,
    'Yangi loyiha yaratildi',
    (SELECT name FROM tuman WHERE id = NEW.tuman_id) || ' tumanida yangi loyiha: ' || NEW.title,
    'project_update',
    '/projects/' || NEW.id
  FROM profiles p
  JOIN tuman t ON p.viloyat_id = t.viloyat_id
  WHERE t.id = NEW.tuman_id AND p.role = 'viloyat_sardori';
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for new projects (only if projects table exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'projects') THEN
    CREATE TRIGGER new_project_notification_trigger
      AFTER INSERT ON projects
      FOR EACH ROW
      EXECUTE FUNCTION notify_viloyat_new_project();
  END IF;
END $$;
