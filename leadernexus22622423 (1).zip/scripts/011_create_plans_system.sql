-- Plans table for leaders to manage their weekly, monthly, and yearly plans
create table if not exists public.plans (
  id uuid primary key default uuid_generate_v4(),
  leader_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text,
  plan_type text not null check (plan_type in ('weekly', 'monthly', 'yearly')),
  start_date date not null,
  end_date date not null,
  status text not null default 'pending' check (status in ('pending', 'in_progress', 'completed', 'cancelled')),
  progress integer not null default 0 check (progress >= 0 and progress <= 100),
  notes text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Plan tasks/goals table for tracking individual tasks within each plan
create table if not exists public.plan_tasks (
  id uuid primary key default uuid_generate_v4(),
  plan_id uuid not null references public.plans(id) on delete cascade,
  title text not null,
  description text,
  status text not null default 'pending' check (status in ('pending', 'in_progress', 'completed')),
  priority text default 'medium' check (priority in ('low', 'medium', 'high')),
  due_date date,
  completed_at timestamp with time zone,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Plan collaborators table for sharing plans with other leaders
create table if not exists public.plan_collaborators (
  id uuid primary key default uuid_generate_v4(),
  plan_id uuid not null references public.plans(id) on delete cascade,
  collaborator_id uuid not null references public.profiles(id) on delete cascade,
  can_edit boolean not null default false,
  invited_at timestamp with time zone default now(),
  unique(plan_id, collaborator_id)
);

-- Indexes for better performance
create index if not exists idx_plans_leader on public.plans(leader_id);
create index if not exists idx_plans_type on public.plans(plan_type);
create index if not exists idx_plans_status on public.plans(status);
create index if not exists idx_plans_dates on public.plans(start_date, end_date);
create index if not exists idx_plan_tasks_plan on public.plan_tasks(plan_id);
create index if not exists idx_plan_tasks_status on public.plan_tasks(status);
create index if not exists idx_plan_collaborators_plan on public.plan_collaborators(plan_id);
create index if not exists idx_plan_collaborators_user on public.plan_collaborators(collaborator_id);

-- Enable RLS on plans tables
alter table public.plans enable row level security;
alter table public.plan_tasks enable row level security;
alter table public.plan_collaborators enable row level security;

-- Plans RLS policies
-- Leaders can view their own plans and plans they're collaborating on
create policy "plans_select_own_or_collaborator" on public.plans
  for select using (
    auth.uid() = leader_id 
    or exists (
      select 1 from public.plan_collaborators 
      where plan_id = plans.id and collaborator_id = auth.uid()
    )
  );

-- Only leaders can create plans
create policy "plans_insert_leader_only" on public.plans
  for insert with check (
    auth.uid() = leader_id
    and exists (
      select 1 from public.profiles 
      where id = auth.uid() and role in ('leader', 'admin')
    )
  );

-- Leaders can update their own plans, collaborators with edit permission can also update
create policy "plans_update_own_or_editor" on public.plans
  for update using (
    auth.uid() = leader_id
    or exists (
      select 1 from public.plan_collaborators 
      where plan_id = plans.id and collaborator_id = auth.uid() and can_edit = true
    )
  );

-- Leaders can delete their own plans
create policy "plans_delete_own" on public.plans
  for delete using (auth.uid() = leader_id);

-- Plan tasks RLS policies
create policy "plan_tasks_select_via_plan" on public.plan_tasks
  for select using (
    exists (
      select 1 from public.plans 
      where id = plan_tasks.plan_id 
      and (leader_id = auth.uid() 
        or exists (
          select 1 from public.plan_collaborators 
          where plan_id = plans.id and collaborator_id = auth.uid()
        )
      )
    )
  );

create policy "plan_tasks_insert_via_plan" on public.plan_tasks
  for insert with check (
    exists (
      select 1 from public.plans 
      where id = plan_tasks.plan_id 
      and (leader_id = auth.uid()
        or exists (
          select 1 from public.plan_collaborators 
          where plan_id = plans.id and collaborator_id = auth.uid() and can_edit = true
        )
      )
    )
  );

create policy "plan_tasks_update_via_plan" on public.plan_tasks
  for update using (
    exists (
      select 1 from public.plans 
      where id = plan_tasks.plan_id 
      and (leader_id = auth.uid()
        or exists (
          select 1 from public.plan_collaborators 
          where plan_id = plans.id and collaborator_id = auth.uid() and can_edit = true
        )
      )
    )
  );

create policy "plan_tasks_delete_via_plan" on public.plan_tasks
  for delete using (
    exists (
      select 1 from public.plans 
      where id = plan_tasks.plan_id 
      and leader_id = auth.uid()
    )
  );

-- Plan collaborators RLS policies
create policy "plan_collaborators_select_via_plan" on public.plan_collaborators
  for select using (
    exists (
      select 1 from public.plans 
      where id = plan_collaborators.plan_id 
      and (leader_id = auth.uid() or collaborator_id = auth.uid())
    )
  );

create policy "plan_collaborators_insert_own_plan" on public.plan_collaborators
  for insert with check (
    exists (
      select 1 from public.plans 
      where id = plan_collaborators.plan_id and leader_id = auth.uid()
    )
  );

create policy "plan_collaborators_delete_own_plan" on public.plan_collaborators
  for delete using (
    exists (
      select 1 from public.plans 
      where id = plan_collaborators.plan_id and leader_id = auth.uid()
    )
  );

-- Trigger to update plan progress based on completed tasks
create or replace function update_plan_progress()
returns trigger as $$
declare
  total_tasks integer;
  completed_tasks integer;
  new_progress integer;
begin
  select count(*) into total_tasks
  from public.plan_tasks
  where plan_id = coalesce(NEW.plan_id, OLD.plan_id);
  
  select count(*) into completed_tasks
  from public.plan_tasks
  where plan_id = coalesce(NEW.plan_id, OLD.plan_id)
    and status = 'completed';
  
  if total_tasks > 0 then
    new_progress := (completed_tasks * 100) / total_tasks;
  else
    new_progress := 0;
  end if;
  
  update public.plans
  set progress = new_progress,
      updated_at = now()
  where id = coalesce(NEW.plan_id, OLD.plan_id);
  
  return coalesce(NEW, OLD);
end;
$$ language plpgsql security definer;

-- Attach trigger to plan_tasks table
drop trigger if exists trigger_update_plan_progress on public.plan_tasks;
create trigger trigger_update_plan_progress
  after insert or update or delete on public.plan_tasks
  for each row
  execute function update_plan_progress();

-- Function to auto-update updated_at timestamp
create or replace function update_updated_at_column()
returns trigger as $$
begin
  NEW.updated_at = now();
  return NEW;
end;
$$ language plpgsql;

-- Attach update trigger to plans table
drop trigger if exists trigger_plans_updated_at on public.plans;
create trigger trigger_plans_updated_at
  before update on public.plans
  for each row
  execute function update_updated_at_column();

-- Attach update trigger to plan_tasks table
drop trigger if exists trigger_plan_tasks_updated_at on public.plan_tasks;
create trigger trigger_plan_tasks_updated_at
  before update on public.plan_tasks
  for each row
  execute function update_updated_at_column();
