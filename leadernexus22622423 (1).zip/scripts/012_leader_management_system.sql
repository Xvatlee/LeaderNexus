-- Leader KPIs and tracking tables
create table if not exists public.leader_kpis (
  id uuid primary key default uuid_generate_v4(),
  leader_id uuid not null references public.profiles(id) on delete cascade,
  period_type text not null check (period_type in ('daily', 'weekly', 'monthly', 'quarterly', 'yearly')),
  period_start date not null,
  period_end date not null,
  projects_count integer default 0,
  tasks_completed integer default 0,
  active_members integer default 0,
  engagement_score decimal(5,2) default 0.0,
  impact_score decimal(5,2) default 0.0,
  performance_rating text check (performance_rating in ('excellent', 'good', 'average', 'needs_improvement')),
  notes text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  unique(leader_id, period_type, period_start)
);

-- Training resources table
create table if not exists public.training_resources (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  description text not null,
  content_type text not null check (content_type in ('video', 'article', 'webinar', 'course')),
  category text not null check (category in ('leadership', 'communication', 'organizational', 'technical', 'management')),
  url text,
  duration_minutes integer,
  difficulty_level text check (difficulty_level in ('beginner', 'intermediate', 'advanced')),
  instructor_name text,
  thumbnail_url text,
  is_published boolean default true,
  created_at timestamp with time zone default now()
);

-- Training completion tracking
create table if not exists public.leader_training (
  id uuid primary key default uuid_generate_v4(),
  leader_id uuid not null references public.profiles(id) on delete cascade,
  resource_id uuid not null references public.training_resources(id) on delete cascade,
  status text not null default 'not_started' check (status in ('not_started', 'in_progress', 'completed')),
  progress_percentage integer default 0 check (progress_percentage >= 0 and progress_percentage <= 100),
  started_at timestamp with time zone,
  completed_at timestamp with time zone,
  notes text,
  created_at timestamp with time zone default now(),
  unique(leader_id, resource_id)
);

-- Discussion forums for leaders
create table if not exists public.leader_discussions (
  id uuid primary key default uuid_generate_v4(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  content text not null,
  category text not null,
  is_pinned boolean default false,
  views_count integer default 0,
  replies_count integer default 0,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Discussion replies
create table if not exists public.leader_discussion_replies (
  id uuid primary key default uuid_generate_v4(),
  discussion_id uuid not null references public.leader_discussions(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  parent_reply_id uuid references public.leader_discussion_replies(id) on delete cascade,
  created_at timestamp with time zone default now()
);

-- Mentorship programs
create table if not exists public.mentorship_relationships (
  id uuid primary key default uuid_generate_v4(),
  mentor_id uuid not null references public.profiles(id) on delete cascade,
  mentee_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'active', 'completed', 'cancelled')),
  start_date date,
  end_date date,
  focus_areas text[],
  notes text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  unique(mentor_id, mentee_id)
);

-- Performance reviews table
create table if not exists public.leader_reviews (
  id uuid primary key default uuid_generate_v4(),
  leader_id uuid not null references public.profiles(id) on delete cascade,
  reviewer_id uuid not null references public.profiles(id) on delete cascade,
  review_period text not null,
  leadership_score integer check (leadership_score >= 1 and leadership_score <= 5),
  communication_score integer check (communication_score >= 1 and communication_score <= 5),
  project_management_score integer check (project_management_score >= 1 and project_management_score <= 5),
  innovation_score integer check (innovation_score >= 1 and innovation_score <= 5),
  overall_rating decimal(3,2),
  strengths text,
  areas_for_improvement text,
  comments text,
  created_at timestamp with time zone default now()
);

-- Rewards and recognition
create table if not exists public.leader_rewards (
  id uuid primary key default uuid_generate_v4(),
  leader_id uuid not null references public.profiles(id) on delete cascade,
  reward_type text not null check (reward_type in ('badge', 'certificate', 'award', 'bonus_points')),
  title text not null,
  description text not null,
  icon text,
  points_awarded integer default 0,
  issued_date date not null default current_date,
  issued_by uuid references public.profiles(id),
  created_at timestamp with time zone default now()
);

-- Monthly rankings
create table if not exists public.leader_rankings (
  id uuid primary key default uuid_generate_v4(),
  leader_id uuid not null references public.profiles(id) on delete cascade,
  ranking_period text not null, -- Format: 'YYYY-MM' or 'YYYY'
  rank_position integer not null,
  total_points integer not null,
  projects_completed integer default 0,
  participation_rate decimal(5,2),
  is_top_performer boolean default false,
  created_at timestamp with time zone default now(),
  unique(leader_id, ranking_period)
);

-- Create indexes
create index if not exists idx_leader_kpis_leader on public.leader_kpis(leader_id);
create index if not exists idx_leader_kpis_period on public.leader_kpis(period_type, period_start);
create index if not exists idx_training_resources_category on public.training_resources(category);
create index if not exists idx_leader_training_leader on public.leader_training(leader_id);
create index if not exists idx_leader_discussions_author on public.leader_discussions(author_id);
create index if not exists idx_mentorship_mentor on public.mentorship_relationships(mentor_id);
create index if not exists idx_mentorship_mentee on public.mentorship_relationships(mentee_id);
create index if not exists idx_leader_reviews_leader on public.leader_reviews(leader_id);
create index if not exists idx_leader_rewards_leader on public.leader_rewards(leader_id);
create index if not exists idx_leader_rankings_leader on public.leader_rankings(leader_id);
create index if not exists idx_leader_rankings_period on public.leader_rankings(ranking_period);

-- Enable RLS
alter table public.leader_kpis enable row level security;
alter table public.training_resources enable row level security;
alter table public.leader_training enable row level security;
alter table public.leader_discussions enable row level security;
alter table public.leader_discussion_replies enable row level security;
alter table public.mentorship_relationships enable row level security;
alter table public.leader_reviews enable row level security;
alter table public.leader_rewards enable row level security;
alter table public.leader_rankings enable row level security;

-- RLS Policies for KPIs (leaders can view own, admins can view all)
create policy "kpis_select_own_or_admin" on public.leader_kpis
  for select using (
    auth.uid() = leader_id 
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create policy "kpis_insert_admin" on public.leader_kpis
  for insert with check (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create policy "kpis_update_admin" on public.leader_kpis
  for update using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- RLS for training resources (all leaders can view published)
create policy "training_select_published" on public.training_resources
  for select using (is_published = true or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

create policy "training_insert_admin" on public.training_resources
  for insert with check (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- RLS for training tracking (leaders see own progress)
create policy "leader_training_select_own" on public.leader_training
  for select using (auth.uid() = leader_id);

create policy "leader_training_insert_own" on public.leader_training
  for insert with check (auth.uid() = leader_id);

create policy "leader_training_update_own" on public.leader_training
  for update using (auth.uid() = leader_id);

-- RLS for discussions (all leaders can view and create)
create policy "discussions_select_all" on public.leader_discussions
  for select using (
    exists (select 1 from public.profiles where id = auth.uid() and role in ('leader', 'admin'))
  );

create policy "discussions_insert_leaders" on public.leader_discussions
  for insert with check (
    auth.uid() = author_id 
    and exists (select 1 from public.profiles where id = auth.uid() and role in ('leader', 'admin'))
  );

create policy "discussions_update_own" on public.leader_discussions
  for update using (auth.uid() = author_id);

-- RLS for discussion replies
create policy "discussion_replies_select_all" on public.leader_discussion_replies
  for select using (
    exists (select 1 from public.profiles where id = auth.uid() and role in ('leader', 'admin'))
  );

create policy "discussion_replies_insert_leaders" on public.leader_discussion_replies
  for insert with check (
    auth.uid() = author_id 
    and exists (select 1 from public.profiles where id = auth.uid() and role in ('leader', 'admin'))
  );

-- RLS for mentorship (mentors and mentees can view their relationships)
create policy "mentorship_select_involved" on public.mentorship_relationships
  for select using (
    auth.uid() = mentor_id 
    or auth.uid() = mentee_id
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create policy "mentorship_insert_involved" on public.mentorship_relationships
  for insert with check (
    auth.uid() = mentor_id 
    or auth.uid() = mentee_id
  );

create policy "mentorship_update_involved" on public.mentorship_relationships
  for update using (
    auth.uid() = mentor_id 
    or auth.uid() = mentee_id
  );

-- RLS for reviews
create policy "reviews_select_own_or_admin" on public.leader_reviews
  for select using (
    auth.uid() = leader_id 
    or auth.uid() = reviewer_id
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create policy "reviews_insert_leaders" on public.leader_reviews
  for insert with check (
    auth.uid() = reviewer_id
    and exists (select 1 from public.profiles where id = auth.uid() and role in ('leader', 'admin'))
  );

-- RLS for rewards
create policy "rewards_select_own" on public.leader_rewards
  for select using (
    auth.uid() = leader_id
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create policy "rewards_insert_admin" on public.leader_rewards
  for insert with check (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- RLS for rankings (all can view)
create policy "rankings_select_all" on public.leader_rankings
  for select using (
    exists (select 1 from public.profiles where id = auth.uid() and role in ('leader', 'admin'))
  );

create policy "rankings_insert_admin" on public.leader_rankings
  for insert with check (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Seed some training resources
insert into public.training_resources (title, description, content_type, category, difficulty_level, duration_minutes) values
  ('Effective Leadership Principles', 'Learn the core principles of effective leadership and how to apply them', 'video', 'leadership', 'beginner', 45),
  ('Communication for Leaders', 'Master communication skills essential for successful leadership', 'course', 'communication', 'intermediate', 120),
  ('Organizational Management', 'Understanding organizational structures and management techniques', 'article', 'organizational', 'intermediate', 30),
  ('Team Building Strategies', 'Build and maintain high-performing teams', 'webinar', 'management', 'intermediate', 60),
  ('Conflict Resolution', 'Handle conflicts effectively in leadership roles', 'video', 'leadership', 'advanced', 50)
on conflict do nothing;
