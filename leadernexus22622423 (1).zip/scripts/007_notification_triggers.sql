-- Function to create notification for new comments on user's posts
create or replace function notify_post_comment()
returns trigger
language plpgsql
security definer
as $$
declare
  post_author_id uuid;
  post_title text;
  commenter_username text;
begin
  -- Get the post author and title
  select author_id, title into post_author_id, post_title
  from posts
  where id = new.post_id;
  
  -- Get commenter username
  select username into commenter_username
  from profiles
  where id = new.author_id;
  
  -- Only notify if the commenter is not the post author
  if post_author_id != new.author_id then
    insert into notifications (user_id, type, title, message, action_url)
    values (
      post_author_id,
      'comment',
      'New comment on your post',
      commenter_username || ' commented on "' || post_title || '"',
      '/forum/post/' || new.post_id
    );
  end if;
  
  return new;
end;
$$;

-- Trigger for comment notifications
drop trigger if exists notify_comment_trigger on comments;
create trigger notify_comment_trigger
  after insert on comments
  for each row
  execute function notify_post_comment();

-- Function to create notification for likes
create or replace function notify_post_like()
returns trigger
language plpgsql
security definer
as $$
declare
  post_author_id uuid;
  post_title text;
  liker_username text;
begin
  -- Get the post author and title
  select author_id, title into post_author_id, post_title
  from posts
  where id = new.post_id;
  
  -- Get liker username
  select username into liker_username
  from profiles
  where id = new.user_id;
  
  -- Only notify if the liker is not the post author
  if post_author_id != new.user_id then
    insert into notifications (user_id, type, title, message, action_url)
    values (
      post_author_id,
      'like',
      'Someone liked your post',
      liker_username || ' liked your post "' || post_title || '"',
      '/forum/post/' || new.post_id
    );
  end if;
  
  return new;
end;
$$;

-- Trigger for like notifications
drop trigger if exists notify_like_trigger on post_likes;
create trigger notify_like_trigger
  after insert on post_likes
  for each row
  execute function notify_post_like();
