-- Add district and direction columns to profiles table
-- This script adds the missing columns needed for leader registration

-- First, check if profiles table exists, if not create a basic one
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  role TEXT NOT NULL DEFAULT 'leader' CHECK (role IN ('admin', 'leader')),
  points INTEGER NOT NULL DEFAULT 0,
  language TEXT NOT NULL DEFAULT 'en',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add district column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'district'
  ) THEN
    ALTER TABLE profiles ADD COLUMN district TEXT;
  END IF;
END $$;

-- Add direction column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'direction'
  ) THEN
    ALTER TABLE profiles ADD COLUMN direction TEXT;
  END IF;
END $$;

-- Add district_id column if it doesn't exist (for foreign key relationship)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'district_id'
  ) THEN
    ALTER TABLE profiles ADD COLUMN district_id UUID REFERENCES districts(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Add direction_id column if it doesn't exist (for foreign key relationship)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'direction_id'
  ) THEN
    ALTER TABLE profiles ADD COLUMN direction_id UUID REFERENCES directions(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_profiles_district ON profiles(district);
CREATE INDEX IF NOT EXISTS idx_profiles_direction ON profiles(direction);
CREATE INDEX IF NOT EXISTS idx_profiles_district_id ON profiles(district_id);
CREATE INDEX IF NOT EXISTS idx_profiles_direction_id ON profiles(direction_id);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);

-- Add a unique constraint to ensure only one leader per district+direction combination
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_leader_district_direction 
ON profiles(district, direction) 
WHERE role = 'leader' AND district IS NOT NULL AND direction IS NOT NULL;

-- Create a trigger to automatically populate district_id and direction_id from district and direction names
CREATE OR REPLACE FUNCTION sync_profile_district_direction_ids()
RETURNS TRIGGER AS $$
BEGIN
  -- Update district_id based on district name
  IF NEW.district IS NOT NULL THEN
    SELECT id INTO NEW.district_id FROM districts WHERE name = NEW.district LIMIT 1;
  END IF;
  
  -- Update direction_id based on direction name
  IF NEW.direction IS NOT NULL THEN
    SELECT id INTO NEW.direction_id FROM directions WHERE name = NEW.direction LIMIT 1;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS sync_profile_ids_trigger ON profiles;
CREATE TRIGGER sync_profile_ids_trigger
BEFORE INSERT OR UPDATE ON profiles
FOR EACH ROW
EXECUTE FUNCTION sync_profile_district_direction_ids();
