-- Insert default achievements
insert into public.achievements (name, description, icon, points_required, category) values
  ('First Steps', 'Join the community', 'Trophy', 0, 'engagement'),
  ('Contributor', 'Make your first post', 'MessageSquare', 10, 'engagement'),
  ('Helpful', 'Post 5 helpful comments', 'Heart', 50, 'engagement'),
  ('Rising Star', 'Earn 100 points', 'Star', 100, 'points'),
  ('Community Leader', 'Earn 500 points', 'Crown', 500, 'points'),
  ('Legend', 'Earn 1000 points', 'Zap', 1000, 'points'),
  ('Conversation Starter', 'Create 10 posts', 'MessageCircle', 100, 'content'),
  ('Problem Solver', 'Have 5 posts marked as solved', 'CheckCircle', 200, 'content')
on conflict do nothing;
