-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum types for roles
CREATE TYPE user_role AS ENUM ('viloyat_sardori', 'tuman_sardori', 'admin');

-- Create enum types for project status
CREATE TYPE project_status AS ENUM ('planning', 'in_progress', 'completed', 'on_hold', 'cancelled');

-- Create enum types for issue priority
CREATE TYPE issue_priority AS ENUM ('low', 'medium', 'high', 'critical');

-- Create enum types for issue status
CREATE TYPE issue_status AS ENUM ('open', 'in_progress', 'resolved', 'closed');

-- Viloyat (Regions) table
CREATE TABLE viloyat (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tuman (Districts) table
CREATE TABLE tuman (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  viloyat_id UUID NOT NULL REFERENCES viloyat(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  population INTEGER,
  area_km2 DECIMAL(10, 2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(viloyat_id, name)
);

-- Extended user profiles table
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'tuman_sardori',
  viloyat_id UUID REFERENCES viloyat(id) ON DELETE SET NULL,
  tuman_id UUID REFERENCES tuman(id) ON DELETE SET NULL,
  avatar_url TEXT,
  phone TEXT,
  bio TEXT,
  total_points INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT role_assignment_check CHECK (
    (role = 'viloyat_sardori' AND viloyat_id IS NOT NULL AND tuman_id IS NULL) OR
    (role = 'tuman_sardori' AND tuman_id IS NOT NULL AND viloyat_id IS NOT NULL) OR
    (role = 'admin')
  )
);

-- Projects table
CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tuman_id UUID NOT NULL REFERENCES tuman(id) ON DELETE CASCADE,
  created_by UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  status project_status DEFAULT 'planning',
  start_date DATE,
  end_date DATE,
  budget DECIMAL(15, 2),
  progress_percentage INTEGER DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
  impact_score INTEGER DEFAULT 0,
  community_involvement INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Project milestones table
CREATE TABLE project_milestones (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  due_date DATE,
  completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- District ratings table
CREATE TABLE district_ratings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tuman_id UUID NOT NULL REFERENCES tuman(id) ON DELETE CASCADE,
  rating_period DATE NOT NULL,
  overall_score DECIMAL(5, 2) DEFAULT 0,
  project_completion_score DECIMAL(5, 2) DEFAULT 0,
  community_engagement_score DECIMAL(5, 2) DEFAULT 0,
  leadership_score DECIMAL(5, 2) DEFAULT 0,
  innovation_score DECIMAL(5, 2) DEFAULT 0,
  rank INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(tuman_id, rating_period)
);

-- Activities/Events table
CREATE TABLE activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tuman_id UUID NOT NULL REFERENCES tuman(id) ON DELETE CASCADE,
  created_by UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  activity_type TEXT NOT NULL,
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ,
  participants_count INTEGER DEFAULT 0,
  impact_points INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Issues/Problems reporting table
CREATE TABLE issues (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tuman_id UUID NOT NULL REFERENCES tuman(id) ON DELETE CASCADE,
  reported_by UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  priority issue_priority DEFAULT 'medium',
  status issue_status DEFAULT 'open',
  assigned_to UUID REFERENCES profiles(id) ON DELETE SET NULL,
  resolved_at TIMESTAMPTZ,
  resolution_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Feedback table
CREATE TABLE feedback (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  from_user UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  to_user UUID REFERENCES profiles(id) ON DELETE CASCADE,
  tuman_id UUID REFERENCES tuman(id) ON DELETE CASCADE,
  feedback_type TEXT NOT NULL,
  content TEXT NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  is_public BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notifications table
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL,
  link TEXT,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Performance metrics table (for analytics)
CREATE TABLE performance_metrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tuman_id UUID NOT NULL REFERENCES tuman(id) ON DELETE CASCADE,
  metric_date DATE NOT NULL,
  projects_completed INTEGER DEFAULT 0,
  projects_in_progress INTEGER DEFAULT 0,
  total_participants INTEGER DEFAULT 0,
  total_budget_spent DECIMAL(15, 2) DEFAULT 0,
  community_satisfaction DECIMAL(3, 2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(tuman_id, metric_date)
);

-- Create indexes for better query performance
CREATE INDEX idx_tuman_viloyat ON tuman(viloyat_id);
CREATE INDEX idx_profiles_role ON profiles(role);
CREATE INDEX idx_profiles_viloyat ON profiles(viloyat_id);
CREATE INDEX idx_profiles_tuman ON profiles(tuman_id);
CREATE INDEX idx_projects_tuman ON projects(tuman_id);
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_district_ratings_tuman ON district_ratings(tuman_id);
CREATE INDEX idx_district_ratings_period ON district_ratings(rating_period);
CREATE INDEX idx_activities_tuman ON activities(tuman_id);
CREATE INDEX idx_issues_tuman ON issues(tuman_id);
CREATE INDEX idx_issues_status ON issues(status);
CREATE INDEX idx_notifications_user ON notifications(user_id, read);
CREATE INDEX idx_performance_metrics_tuman ON performance_metrics(tuman_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at triggers
CREATE TRIGGER update_viloyat_updated_at BEFORE UPDATE ON viloyat
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tuman_updated_at BEFORE UPDATE ON tuman
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_district_ratings_updated_at BEFORE UPDATE ON district_ratings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_activities_updated_at BEFORE UPDATE ON activities
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_issues_updated_at BEFORE UPDATE ON issues
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
