-- Rating System for District Leaders (Sardors)
-- This system tracks and evaluates the performance of tuman sardorlari

-- Rating Criteria Table: Defines the criteria for evaluating sardors
CREATE TABLE IF NOT EXISTS rating_criteria (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_uz VARCHAR(255) NOT NULL,
  name_ru VARCHAR(255) NOT NULL,
  description_uz TEXT NOT NULL,
  description_ru TEXT NOT NULL,
  category VARCHAR(100) NOT NULL CHECK (category IN ('projects', 'engagement', 'events', 'leadership', 'feedback')),
  weight DECIMAL(5,2) DEFAULT 1.0 CHECK (weight >= 0 AND weight <= 10),
  max_score INTEGER DEFAULT 100,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Rating Periods: Monthly and Annual evaluation periods
CREATE TABLE IF NOT EXISTS rating_periods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  period_type VARCHAR(20) NOT NULL CHECK (period_type IN ('monthly', 'annual')),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  year INTEGER NOT NULL,
  month INTEGER CHECK (month >= 1 AND month <= 12),
  is_active BOOLEAN DEFAULT true,
  is_finalized BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(period_type, year, month)
);

-- Sardor Ratings: Main rating records for each sardor in a period
CREATE TABLE IF NOT EXISTS sardor_ratings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sardor_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  period_id UUID NOT NULL REFERENCES rating_periods(id) ON DELETE CASCADE,
  district_id UUID REFERENCES districts(id) ON DELETE SET NULL,
  direction_id UUID REFERENCES directions(id) ON DELETE SET NULL,
  
  -- Criteria scores
  project_score DECIMAL(5,2) DEFAULT 0,
  engagement_score DECIMAL(5,2) DEFAULT 0,
  events_score DECIMAL(5,2) DEFAULT 0,
  leadership_score DECIMAL(5,2) DEFAULT 0,
  feedback_score DECIMAL(5,2) DEFAULT 0,
  
  -- Calculated totals
  total_score DECIMAL(8,2) DEFAULT 0,
  weighted_score DECIMAL(8,2) DEFAULT 0,
  rank_in_district INTEGER,
  rank_overall INTEGER,
  
  -- Metrics
  total_projects INTEGER DEFAULT 0,
  completed_projects INTEGER DEFAULT 0,
  total_events INTEGER DEFAULT 0,
  total_participants INTEGER DEFAULT 0,
  community_feedback_count INTEGER DEFAULT 0,
  
  -- Status
  is_finalized BOOLEAN DEFAULT false,
  notes TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(sardor_id, period_id)
);

-- Rating Details: Detailed breakdown of scores by criteria
CREATE TABLE IF NOT EXISTS rating_details (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rating_id UUID NOT NULL REFERENCES sardor_ratings(id) ON DELETE CASCADE,
  criteria_id UUID NOT NULL REFERENCES rating_criteria(id) ON DELETE CASCADE,
  score DECIMAL(5,2) DEFAULT 0,
  max_score INTEGER DEFAULT 100,
  weight DECIMAL(5,2) DEFAULT 1.0,
  weighted_score DECIMAL(8,2) DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(rating_id, criteria_id)
);

-- Peer Reviews: Sardors review each other
CREATE TABLE IF NOT EXISTS peer_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reviewer_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reviewee_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  period_id UUID NOT NULL REFERENCES rating_periods(id) ON DELETE CASCADE,
  
  -- Review scores
  leadership_rating INTEGER CHECK (leadership_rating >= 1 AND leadership_rating <= 5),
  collaboration_rating INTEGER CHECK (collaboration_rating >= 1 AND collaboration_rating <= 5),
  communication_rating INTEGER CHECK (communication_rating >= 1 AND communication_rating <= 5),
  innovation_rating INTEGER CHECK (innovation_rating >= 1 AND innovation_rating <= 5),
  overall_rating INTEGER CHECK (overall_rating >= 1 AND overall_rating <= 5),
  
  -- Feedback
  positive_feedback TEXT,
  constructive_feedback TEXT,
  suggestions TEXT,
  
  is_anonymous BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(reviewer_id, reviewee_id, period_id)
);

-- Community Feedback: Public feedback about sardors
CREATE TABLE IF NOT EXISTS community_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sardor_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  period_id UUID REFERENCES rating_periods(id) ON DELETE SET NULL,
  
  -- Feedback details
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  category VARCHAR(50) CHECK (category IN ('project', 'event', 'leadership', 'communication', 'other')),
  feedback_text TEXT NOT NULL,
  
  -- Submitter info (optional)
  submitter_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  submitter_name VARCHAR(255),
  is_anonymous BOOLEAN DEFAULT false,
  
  -- Status
  is_verified BOOLEAN DEFAULT false,
  is_approved BOOLEAN DEFAULT true,
  admin_notes TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Achievements and Rewards: Badges and recognition for high performers
CREATE TABLE IF NOT EXISTS rating_achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sardor_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  period_id UUID NOT NULL REFERENCES rating_periods(id) ON DELETE CASCADE,
  
  achievement_type VARCHAR(50) CHECK (achievement_type IN ('top_district', 'top_overall', 'most_improved', 'best_engagement', 'best_projects', 'best_leader', 'monthly_star', 'annual_star')),
  rank INTEGER,
  badge_name_uz VARCHAR(255),
  badge_name_ru VARCHAR(255),
  description_uz TEXT,
  description_ru TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(sardor_id, period_id, achievement_type)
);

-- Rating History: Track changes over time
CREATE TABLE IF NOT EXISTS rating_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sardor_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  period_id UUID NOT NULL REFERENCES rating_periods(id) ON DELETE CASCADE,
  
  previous_score DECIMAL(8,2),
  new_score DECIMAL(8,2),
  change_percentage DECIMAL(5,2),
  previous_rank INTEGER,
  new_rank INTEGER,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_sardor_ratings_sardor_id ON sardor_ratings(sardor_id);
CREATE INDEX IF NOT EXISTS idx_sardor_ratings_period_id ON sardor_ratings(period_id);
CREATE INDEX IF NOT EXISTS idx_sardor_ratings_district_id ON sardor_ratings(district_id);
CREATE INDEX IF NOT EXISTS idx_sardor_ratings_total_score ON sardor_ratings(total_score DESC);
CREATE INDEX IF NOT EXISTS idx_rating_details_rating_id ON rating_details(rating_id);
CREATE INDEX IF NOT EXISTS idx_peer_reviews_reviewee_id ON peer_reviews(reviewee_id);
CREATE INDEX IF NOT EXISTS idx_peer_reviews_period_id ON peer_reviews(period_id);
CREATE INDEX IF NOT EXISTS idx_community_feedback_sardor_id ON community_feedback(sardor_id);
CREATE INDEX IF NOT EXISTS idx_rating_achievements_sardor_id ON rating_achievements(sardor_id);

-- Enable Row Level Security
ALTER TABLE rating_criteria ENABLE ROW LEVEL SECURITY;
ALTER TABLE rating_periods ENABLE ROW LEVEL SECURITY;
ALTER TABLE sardor_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE rating_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE peer_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE rating_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE rating_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for rating_criteria
CREATE POLICY "Anyone can view rating criteria"
  ON rating_criteria FOR SELECT
  USING (true);

CREATE POLICY "Only admins can manage rating criteria"
  ON rating_criteria FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- RLS Policies for rating_periods
CREATE POLICY "Anyone can view rating periods"
  ON rating_periods FOR SELECT
  USING (true);

CREATE POLICY "Only admins can manage rating periods"
  ON rating_periods FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- RLS Policies for sardor_ratings
CREATE POLICY "Anyone can view finalized ratings"
  ON sardor_ratings FOR SELECT
  USING (is_finalized = true OR sardor_id = auth.uid());

CREATE POLICY "Sardors can view their own ratings"
  ON sardor_ratings FOR SELECT
  USING (sardor_id = auth.uid());

CREATE POLICY "Admins can manage all ratings"
  ON sardor_ratings FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- RLS Policies for rating_details
CREATE POLICY "Users can view rating details for visible ratings"
  ON rating_details FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM sardor_ratings 
    WHERE id = rating_details.rating_id 
    AND (is_finalized = true OR sardor_id = auth.uid())
  ));

-- RLS Policies for peer_reviews
CREATE POLICY "Reviewers can view their own reviews"
  ON peer_reviews FOR SELECT
  USING (reviewer_id = auth.uid());

CREATE POLICY "Reviewees can view reviews about them"
  ON peer_reviews FOR SELECT
  USING (reviewee_id = auth.uid() AND is_anonymous = false);

CREATE POLICY "Leaders can submit peer reviews"
  ON peer_reviews FOR INSERT
  WITH CHECK (
    reviewer_id = auth.uid() AND
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'leader')
  );

CREATE POLICY "Admins can view all peer reviews"
  ON peer_reviews FOR SELECT
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- RLS Policies for community_feedback
CREATE POLICY "Users can view approved feedback"
  ON community_feedback FOR SELECT
  USING (is_approved = true);

CREATE POLICY "Authenticated users can submit feedback"
  ON community_feedback FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can manage all feedback"
  ON community_feedback FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- RLS Policies for rating_achievements
CREATE POLICY "Anyone can view achievements"
  ON rating_achievements FOR SELECT
  USING (true);

CREATE POLICY "Admins can manage achievements"
  ON rating_achievements FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- RLS Policies for rating_history
CREATE POLICY "Sardors can view their own history"
  ON rating_history FOR SELECT
  USING (sardor_id = auth.uid());

CREATE POLICY "Admins can view all history"
  ON rating_history FOR SELECT
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Insert default rating criteria
INSERT INTO rating_criteria (name_uz, name_ru, description_uz, description_ru, category, weight, max_score) VALUES
('Loyihalar muvaffaqiyati', 'Успех проектов', 'Sardor tomonidan amalga oshirilgan loyihalar soni va ularning ta''siri', 'Количество и влияние проектов, реализованных лидером', 'projects', 3.0, 100),
('Jamoatchilik ishtiroki', 'Участие общественности', 'Jamoa a''zolari va jamoatchilik faolligi darajasi', 'Уровень активности членов команды и общественности', 'engagement', 2.5, 100),
('Tadbirlar tashkil etish', 'Организация мероприятий', 'Tashkil etilgan tadbirlar soni va sifati', 'Количество и качество организованных мероприятий', 'events', 2.0, 100),
('Yetakchilik qobiliyati', 'Лидерские качества', 'Jamoa boshqaruvi va ilhomlantirish qobiliyati', 'Способность управлять командой и вдохновлять', 'leadership', 2.5, 100),
('Jamoatchilik fikri', 'Общественное мнение', 'Jamoa va jamoatchilik tomonidan berilgan baholash', 'Оценка со стороны команды и общественности', 'feedback', 2.0, 100);

-- Create a current rating period (current month)
INSERT INTO rating_periods (period_type, start_date, end_date, year, month, is_active)
VALUES (
  'monthly',
  DATE_TRUNC('month', CURRENT_DATE),
  (DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::DATE,
  EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER,
  EXTRACT(MONTH FROM CURRENT_DATE)::INTEGER,
  true
);
