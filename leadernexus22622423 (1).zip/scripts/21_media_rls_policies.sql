-- Row Level Security Policies for Media Management

-- Enable RLS
ALTER TABLE media_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE media_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE media_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE media_collections ENABLE ROW LEVEL SECURITY;
ALTER TABLE media_collection_items ENABLE ROW LEVEL SECURITY;

-- Media Files Policies
-- Anyone can view approved public media
CREATE POLICY "Anyone can view approved public media"
    ON media_files FOR SELECT
    USING (status = 'approved' AND visibility = 'public');

-- Users can view their district's media if visibility is district
CREATE POLICY "Users can view district media"
    ON media_files FOR SELECT
    USING (
        auth.uid() IS NOT NULL AND
        status = 'approved' AND
        visibility = 'district' AND
        district_id IN (
            SELECT district_id FROM profiles WHERE id = auth.uid()
        )
    );

-- Users can view their direction's media if visibility is direction
CREATE POLICY "Users can view direction media"
    ON media_files FOR SELECT
    USING (
        auth.uid() IS NOT NULL AND
        status = 'approved' AND
        visibility = 'direction' AND
        direction_id IN (
            SELECT direction_id FROM profiles WHERE id = auth.uid()
        )
    );

-- Users can view their own media regardless of status
CREATE POLICY "Users can view own media"
    ON media_files FOR SELECT
    USING (uploaded_by = auth.uid());

-- Viloyat sardori can view all media
CREATE POLICY "Viloyat sardori can view all media"
    ON media_files FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'viloyat_sardori'
        )
    );

-- Authenticated users can upload media
CREATE POLICY "Authenticated users can upload media"
    ON media_files FOR INSERT
    WITH CHECK (auth.uid() = uploaded_by);

-- Users can update their own media (only if not yet approved)
CREATE POLICY "Users can update own pending media"
    ON media_files FOR UPDATE
    USING (uploaded_by = auth.uid() AND status = 'pending')
    WITH CHECK (uploaded_by = auth.uid());

-- Viloyat sardori can update any media (for approval/rejection)
CREATE POLICY "Viloyat sardori can moderate media"
    ON media_files FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'viloyat_sardori'
        )
    );

-- Users can delete their own media (only if not yet approved)
CREATE POLICY "Users can delete own pending media"
    ON media_files FOR DELETE
    USING (uploaded_by = auth.uid() AND status = 'pending');

-- Viloyat sardori can delete any media
CREATE POLICY "Viloyat sardori can delete any media"
    ON media_files FOR DELETE
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'viloyat_sardori'
        )
    );

-- Media Comments Policies
-- Anyone can view comments on approved media
CREATE POLICY "Anyone can view comments on approved media"
    ON media_comments FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM media_files
            WHERE media_files.id = media_comments.media_id
            AND media_files.status = 'approved'
        )
    );

-- Authenticated users can add comments
CREATE POLICY "Authenticated users can add comments"
    ON media_comments FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- Users can update their own comments
CREATE POLICY "Users can update own comments"
    ON media_comments FOR UPDATE
    USING (user_id = auth.uid());

-- Users can delete their own comments
CREATE POLICY "Users can delete own comments"
    ON media_comments FOR DELETE
    USING (user_id = auth.uid());

-- Media Likes Policies
-- Anyone can view likes
CREATE POLICY "Anyone can view likes"
    ON media_likes FOR SELECT
    USING (true);

-- Authenticated users can like media
CREATE POLICY "Authenticated users can like media"
    ON media_likes FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- Users can unlike media
CREATE POLICY "Users can unlike media"
    ON media_likes FOR DELETE
    USING (user_id = auth.uid());

-- Media Collections Policies
-- Anyone can view public collections
CREATE POLICY "Anyone can view public collections"
    ON media_collections FOR SELECT
    USING (is_public = TRUE);

-- Users can view their own collections
CREATE POLICY "Users can view own collections"
    ON media_collections FOR SELECT
    USING (created_by = auth.uid());

-- Authenticated users can create collections
CREATE POLICY "Authenticated users can create collections"
    ON media_collections FOR INSERT
    WITH CHECK (auth.uid() = created_by);

-- Users can update their own collections
CREATE POLICY "Users can update own collections"
    ON media_collections FOR UPDATE
    USING (created_by = auth.uid());

-- Users can delete their own collections
CREATE POLICY "Users can delete own collections"
    ON media_collections FOR DELETE
    USING (created_by = auth.uid());

-- Collection Items Policies
-- Users can view items in accessible collections
CREATE POLICY "Users can view collection items"
    ON media_collection_items FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM media_collections
            WHERE media_collections.id = media_collection_items.collection_id
            AND (media_collections.is_public = TRUE OR media_collections.created_by = auth.uid())
        )
    );

-- Collection owners can manage items
CREATE POLICY "Collection owners can manage items"
    ON media_collection_items FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM media_collections
            WHERE media_collections.id = media_collection_items.collection_id
            AND media_collections.created_by = auth.uid()
        )
    );
