-- Row Level Security policies for reports system

-- Enable RLS on all tables
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_audit_log ENABLE ROW LEVEL SECURITY;

-- Reports policies
-- Tuman sardori can view and manage their own district's reports
CREATE POLICY "Tuman sardori can view own district reports"
ON reports FOR SELECT
TO authenticated
USING (
  district_id IN (
    SELECT ld.district_id 
    FROM leader_directions ld 
    WHERE ld.user_id = auth.uid()
  )
);

CREATE POLICY "Tuman sardori can create reports for own district"
ON reports FOR INSERT
TO authenticated
WITH CHECK (
  district_id IN (
    SELECT ld.district_id 
    FROM leader_directions ld 
    WHERE ld.user_id = auth.uid()
  )
);

CREATE POLICY "Tuman sardori can update own district reports"
ON reports FOR UPDATE
TO authenticated
USING (
  district_id IN (
    SELECT ld.district_id 
    FROM leader_directions ld 
    WHERE ld.user_id = auth.uid()
  )
);

-- Viloyat sardori can view all reports in their region
CREATE POLICY "Viloyat sardori can view all district reports"
ON reports FOR SELECT
TO authenticated
USING (
  district_id IN (
    SELECT d.id 
    FROM districts d
    WHERE d.region = 'Surxondaryo'
  )
  AND EXISTS (
    SELECT 1 FROM leader_directions ld
    JOIN directions dir ON ld.direction_id = dir.id
    WHERE ld.user_id = auth.uid() 
    AND dir.name = 'Bosh sardori'
  )
);

-- Report feedback policies
CREATE POLICY "Users can view feedback on their reports"
ON report_feedback FOR SELECT
TO authenticated
USING (
  report_id IN (
    SELECT r.id FROM reports r WHERE r.user_id = auth.uid()
  )
);

CREATE POLICY "Viloyat sardori can create feedback"
ON report_feedback FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM leader_directions ld
    JOIN directions dir ON ld.direction_id = dir.id
    WHERE ld.user_id = auth.uid() 
    AND dir.name = 'Bosh sardori'
  )
);

CREATE POLICY "Viloyat sardori can view all feedback"
ON report_feedback FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM leader_directions ld
    JOIN directions dir ON ld.direction_id = dir.id
    WHERE ld.user_id = auth.uid() 
    AND dir.name = 'Bosh sardori'
  )
);

-- Report comments policies
CREATE POLICY "Users can view comments on accessible reports"
ON report_comments FOR SELECT
TO authenticated
USING (
  report_id IN (
    SELECT r.id FROM reports r 
    WHERE r.user_id = auth.uid()
    OR r.district_id IN (
      SELECT d.id FROM districts d WHERE d.region = 'Surxondaryo'
    )
  )
);

CREATE POLICY "Users can create comments on accessible reports"
ON report_comments FOR INSERT
TO authenticated
WITH CHECK (
  report_id IN (
    SELECT r.id FROM reports r 
    WHERE r.user_id = auth.uid()
    OR r.district_id IN (
      SELECT d.id FROM districts d WHERE d.region = 'Surxondaryo'
    )
  )
);

-- Report alerts policies
CREATE POLICY "Viloyat sardori can view all alerts"
ON report_alerts FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM leader_directions ld
    JOIN directions dir ON ld.direction_id = dir.id
    WHERE ld.user_id = auth.uid() 
    AND dir.name = 'Bosh sardori'
  )
);

CREATE POLICY "Tuman sardori can view own district alerts"
ON report_alerts FOR SELECT
TO authenticated
USING (
  district_id IN (
    SELECT ld.district_id 
    FROM leader_directions ld 
    WHERE ld.user_id = auth.uid()
  )
);

-- Audit log policies
CREATE POLICY "Users can view audit logs for accessible reports"
ON report_audit_log FOR SELECT
TO authenticated
USING (
  report_id IN (
    SELECT r.id FROM reports r 
    WHERE r.user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM leader_directions ld
      JOIN directions dir ON ld.direction_id = dir.id
      WHERE ld.user_id = auth.uid() 
      AND dir.name = 'Bosh sardori'
    )
  )
);
