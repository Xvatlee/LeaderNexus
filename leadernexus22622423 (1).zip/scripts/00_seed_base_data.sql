-- Insert the 14 districts (tuman) of Surxondaryo viloyati
INSERT INTO districts (name, region, description, is_active) VALUES
  -- Using exact district names from user's list
  ('Angor', 'Surxondaryo', 'Angor tumani', true),
  ('Boysun', 'Surxondaryo', 'Boysun tumani', true),
  ('Denov', 'Surxondaryo', 'Denov tumani', true),
  ('Jarqorgon', 'Surxondaryo', 'Jarqorgon tumani', true),
  ('Muzrabot', 'Surxondaryo', 'Muzrabot tumani', true),
  ('Kumqorgon', 'Surxondaryo', 'Kumqorgon tumani', true),
  ('Sariosiyo', 'Surxondaryo', 'Sariosiyo tumani', true),
  ('Sherobod', 'Surxondaryo', 'Sherobod tumani', true),
  ('Shurchi', 'Surxondaryo', 'Shurchi tumani', true),
  ('Termiz', 'Surxondaryo', 'Termiz shahri', true),
  ('Uzun', 'Surxondaryo', 'Uzun tumani', true),
  ('Altinsoy', 'Surxondaryo', 'Altinsoy tumani', true),
  ('Bandixon', 'Surxondaryo', 'Bandixon tumani', true),
  ('Altynkul', 'Surxondaryo', 'Altynkul tumani', true)
ON CONFLICT DO NOTHING;

-- Insert sample directions (areas of expertise/work)
INSERT INTO directions (name, description, is_active) VALUES
  ('Education', 'Educational initiatives and programs', true),
  ('Healthcare', 'Healthcare services and medical programs', true),
  ('Infrastructure', 'Roads, buildings, and public infrastructure', true),
  ('Agriculture', 'Farming, irrigation, and agricultural development', true),
  ('Technology', 'IT and digital transformation initiatives', true),
  ('Culture', 'Cultural events and heritage preservation', true),
  ('Sports', 'Sports programs and athletic development', true),
  ('Environment', 'Environmental protection and sustainability', true),
  ('Economy', 'Economic development and business support', true),
  ('Social Services', 'Social welfare and community support', true),
  ('Youth Development', 'Youth programs and opportunities', true),
  ('Tourism', 'Tourism development and promotion', true)
ON CONFLICT DO NOTHING;
