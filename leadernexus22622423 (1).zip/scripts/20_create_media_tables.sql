-- Media Management System Tables for LeaderNexus
-- Stores photos, videos, documents from all 14 districts and 9 leadership directions

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Media Files Table
CREATE TABLE IF NOT EXISTS media_files (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    file_url TEXT NOT NULL,
    file_type VARCHAR(50) NOT NULL CHECK (file_type IN ('image', 'video', 'document')),
    file_size BIGINT, -- in bytes
    mime_type VARCHAR(100),
    thumbnail_url TEXT,
    
    -- Uploader Information
    uploaded_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    district_id UUID REFERENCES districts(id) ON DELETE SET NULL,
    direction_id UUID REFERENCES directions(id) ON DELETE SET NULL,
    
    -- Categorization
    category VARCHAR(50) NOT NULL CHECK (category IN ('event', 'project', 'achievement', 'training', 'meeting', 'other')),
    tags TEXT[], -- Array of tags for searching
    
    -- Moderation
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'archived')),
    reviewed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    reviewed_at TIMESTAMPTZ,
    rejection_reason TEXT,
    
    -- Visibility & Access
    visibility VARCHAR(20) NOT NULL DEFAULT 'public' CHECK (visibility IN ('public', 'district', 'direction', 'private')),
    is_featured BOOLEAN DEFAULT FALSE,
    
    -- Metadata
    event_date DATE,
    location VARCHAR(255),
    participants_count INTEGER,
    related_project_id UUID, -- Could link to projects table if exists
    
    -- Statistics
    view_count INTEGER DEFAULT 0,
    download_count INTEGER DEFAULT 0,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Media Comments Table
CREATE TABLE IF NOT EXISTS media_comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    media_id UUID NOT NULL REFERENCES media_files(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    comment TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Media Likes Table
CREATE TABLE IF NOT EXISTS media_likes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    media_id UUID NOT NULL REFERENCES media_files(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(media_id, user_id)
);

-- Media Collections/Albums Table
CREATE TABLE IF NOT EXISTS media_collections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    district_id UUID REFERENCES districts(id) ON DELETE SET NULL,
    direction_id UUID REFERENCES directions(id) ON DELETE SET NULL,
    cover_image_url TEXT,
    is_public BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Media Collection Items (many-to-many relationship)
CREATE TABLE IF NOT EXISTS media_collection_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    collection_id UUID NOT NULL REFERENCES media_collections(id) ON DELETE CASCADE,
    media_id UUID NOT NULL REFERENCES media_files(id) ON DELETE CASCADE,
    position INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(collection_id, media_id)
);

-- Indexes for performance
CREATE INDEX idx_media_files_uploaded_by ON media_files(uploaded_by);
CREATE INDEX idx_media_files_district ON media_files(district_id);
CREATE INDEX idx_media_files_direction ON media_files(direction_id);
CREATE INDEX idx_media_files_status ON media_files(status);
CREATE INDEX idx_media_files_category ON media_files(category);
CREATE INDEX idx_media_files_created_at ON media_files(created_at DESC);
CREATE INDEX idx_media_files_featured ON media_files(is_featured) WHERE is_featured = TRUE;
CREATE INDEX idx_media_files_visibility ON media_files(visibility);
CREATE INDEX idx_media_comments_media_id ON media_comments(media_id);
CREATE INDEX idx_media_likes_media_id ON media_likes(media_id);
CREATE INDEX idx_media_collection_items_collection ON media_collection_items(collection_id);

-- Update timestamp trigger function
CREATE OR REPLACE FUNCTION update_media_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers
CREATE TRIGGER update_media_files_updated_at
    BEFORE UPDATE ON media_files
    FOR EACH ROW
    EXECUTE FUNCTION update_media_updated_at();

CREATE TRIGGER update_media_collections_updated_at
    BEFORE UPDATE ON media_collections
    FOR EACH ROW
    EXECUTE FUNCTION update_media_updated_at();
