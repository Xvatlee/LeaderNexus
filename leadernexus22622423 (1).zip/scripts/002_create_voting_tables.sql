-- Polls/Surveys for decision-making
CREATE TABLE IF NOT EXISTS polls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  creator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  poll_type VARCHAR(50) DEFAULT 'single' CHECK (poll_type IN ('single', 'multiple', 'ranking')),
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('draft', 'active', 'closed')),
  visibility VARCHAR(50) DEFAULT 'all_leaders' CHECK (visibility IN ('all_leaders', 'region_specific', 'admin_only')),
  target_region VARCHAR(100),
  start_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  end_date TIMESTAMP WITH TIME ZONE,
  allow_anonymous BOOLEAN DEFAULT false,
  show_results_before_vote BOOLEAN DEFAULT false,
  show_results_after_close BOOLEAN DEFAULT true,
  min_votes_required INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Poll options
CREATE TABLE IF NOT EXISTS poll_options (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id UUID NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
  option_text TEXT NOT NULL,
  option_order INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Poll votes
CREATE TABLE IF NOT EXISTS poll_votes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id UUID NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
  option_id UUID NOT NULL REFERENCES poll_options(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  is_anonymous BOOLEAN DEFAULT false,
  ranking INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(poll_id, user_id, option_id)
);

-- Decision records for transparency
CREATE TABLE IF NOT EXISTS decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  decision_type VARCHAR(50) DEFAULT 'policy' CHECK (decision_type IN ('policy', 'budget', 'initiative', 'procedural', 'other')),
  status VARCHAR(50) DEFAULT 'proposed' CHECK (status IN ('proposed', 'voting', 'approved', 'rejected', 'implemented')),
  proposer_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  poll_id UUID REFERENCES polls(id) ON DELETE SET NULL,
  vote_count_yes INTEGER DEFAULT 0,
  vote_count_no INTEGER DEFAULT 0,
  vote_count_abstain INTEGER DEFAULT 0,
  decision_date TIMESTAMP WITH TIME ZONE,
  implementation_date TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Decision votes (direct voting on decisions)
CREATE TABLE IF NOT EXISTS decision_votes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  vote VARCHAR(20) CHECK (vote IN ('yes', 'no', 'abstain')),
  comment TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(decision_id, user_id)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_polls_creator_id ON polls(creator_id);
CREATE INDEX IF NOT EXISTS idx_polls_status ON polls(status);
CREATE INDEX IF NOT EXISTS idx_poll_options_poll_id ON poll_options(poll_id);
CREATE INDEX IF NOT EXISTS idx_poll_votes_poll_id ON poll_votes(poll_id);
CREATE INDEX IF NOT EXISTS idx_poll_votes_user_id ON poll_votes(user_id);
CREATE INDEX IF NOT EXISTS idx_decisions_proposer_id ON decisions(proposer_id);
CREATE INDEX IF NOT EXISTS idx_decisions_status ON decisions(status);
CREATE INDEX IF NOT EXISTS idx_decision_votes_decision_id ON decision_votes(decision_id);

-- Enable Row Level Security
ALTER TABLE polls ENABLE ROW LEVEL SECURITY;
ALTER TABLE poll_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE poll_votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE decision_votes ENABLE ROW LEVEL SECURITY;

-- RLS Policies for polls
CREATE POLICY "Users can view polls based on visibility"
  ON polls FOR SELECT
  USING (
    status = 'active' AND (
      visibility = 'all_leaders' OR
      (visibility = 'region_specific' AND EXISTS (
        SELECT 1 FROM profiles WHERE id = auth.uid() AND region = polls.target_region
      )) OR
      (visibility = 'admin_only' AND EXISTS (
        SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
      ))
    )
  );

CREATE POLICY "Leaders can create polls"
  ON polls FOR INSERT
  WITH CHECK (auth.uid() = creator_id);

CREATE POLICY "Poll creators can update their polls"
  ON polls FOR UPDATE
  USING (auth.uid() = creator_id);

-- RLS Policies for poll_options
CREATE POLICY "Users can view poll options for accessible polls"
  ON poll_options FOR SELECT
  USING (EXISTS (SELECT 1 FROM polls WHERE id = poll_id));

CREATE POLICY "Poll creators can insert options"
  ON poll_options FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM polls WHERE id = poll_id AND creator_id = auth.uid()));

-- RLS Policies for poll_votes
CREATE POLICY "Users can view votes based on poll settings"
  ON poll_votes FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM polls 
      WHERE id = poll_id 
      AND (show_results_before_vote = true OR show_results_after_close = true)
    )
  );

CREATE POLICY "Users can vote on polls"
  ON poll_votes FOR INSERT
  WITH CHECK (auth.uid() = user_id OR is_anonymous = true);

-- RLS Policies for decisions
CREATE POLICY "Users can view approved/implemented decisions"
  ON decisions FOR SELECT
  USING (status IN ('approved', 'rejected', 'implemented') OR proposer_id = auth.uid());

CREATE POLICY "Leaders can propose decisions"
  ON decisions FOR INSERT
  WITH CHECK (auth.uid() = proposer_id);

CREATE POLICY "Decision proposers can update their decisions"
  ON decisions FOR UPDATE
  USING (auth.uid() = proposer_id);

-- RLS Policies for decision_votes
CREATE POLICY "Users can view decision votes for transparent decisions"
  ON decision_votes FOR SELECT
  USING (true);

CREATE POLICY "Users can vote on decisions"
  ON decision_votes FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own decision votes"
  ON decision_votes FOR UPDATE
  USING (auth.uid() = user_id);
