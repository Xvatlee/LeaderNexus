-- Admin Request Approval System
-- This system prevents users from self-assigning admin privileges
-- All admin requests must be approved by the super admin

-- Drop existing policies and tables if they exist (for idempotency)
DROP POLICY IF EXISTS "Users can insert their own admin requests" ON admin_requests;
DROP POLICY IF EXISTS "Users can view their own admin requests" ON admin_requests;
DROP POLICY IF EXISTS "Service role can update admin requests" ON admin_requests;
DROP POLICY IF EXISTS "Users can view admins table" ON admins;
DROP POLICY IF EXISTS "Service role can manage admins" ON admins;

DROP TABLE IF EXISTS admin_requests CASCADE;
DROP TABLE IF EXISTS admins CASCADE;

-- Create admins table
-- This table stores approved admins (more robust than relying solely on profiles.role)
CREATE TABLE admins (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  created_by UUID REFERENCES auth.users(id),
  notes TEXT
);

-- Create admin_requests table
CREATE TABLE admin_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES auth.users(id),
  token_hash TEXT,
  token_expires_at TIMESTAMPTZ,
  UNIQUE (user_id, status) -- Prevent multiple pending requests per user
);

-- Create indexes for performance
CREATE INDEX idx_admin_requests_user_id ON admin_requests(user_id);
CREATE INDEX idx_admin_requests_status ON admin_requests(status);
CREATE INDEX idx_admin_requests_token_hash ON admin_requests(token_hash);

-- Enable RLS
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_requests ENABLE ROW LEVEL SECURITY;

-- RLS Policies for admins table
-- Users can read the admins table to check if they or others are admins
CREATE POLICY "Users can view admins table"
  ON admins FOR SELECT
  TO authenticated
  USING (true);

-- Only service role can insert/update/delete admins (no client-side writes)
CREATE POLICY "Service role can manage admins"
  ON admins FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- RLS Policies for admin_requests table
-- Users can only insert their own requests with status='pending' and user_id=auth.uid()
CREATE POLICY "Users can insert their own admin requests"
  ON admin_requests FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id = auth.uid() 
    AND status = 'pending'
  );

-- Users can only view their own requests
CREATE POLICY "Users can view their own admin requests"
  ON admin_requests FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Service role can update requests (for approval/rejection workflow)
CREATE POLICY "Service role can update admin requests"
  ON admin_requests FOR UPDATE
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Prevent users from updating their own requests
-- (No update policy for regular users - only service role can update)

-- Prevent users from updating role field in profiles table
-- Update existing RLS policy to lock down role changes
DO $$
BEGIN
  -- Drop existing profile update policy if it exists
  DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
  
  -- Recreate with role protection
  CREATE POLICY "Users can update own profile"
    ON profiles FOR UPDATE
    TO authenticated
    USING (id = auth.uid())
    WITH CHECK (
      id = auth.uid() 
      AND role = (SELECT role FROM profiles WHERE id = auth.uid()) -- Role cannot be changed by user
    );
EXCEPTION
  WHEN undefined_table THEN
    RAISE NOTICE 'profiles table does not exist yet';
END $$;

-- Grant necessary permissions
GRANT SELECT ON admins TO authenticated;
GRANT SELECT ON admin_requests TO authenticated;
GRANT INSERT ON admin_requests TO authenticated;

GRANT ALL ON admins TO service_role;
GRANT ALL ON admin_requests TO service_role;

COMMENT ON TABLE admins IS 'Stores approved admin users - managed by service role only';
COMMENT ON TABLE admin_requests IS 'Stores admin privilege requests that must be approved by super admin';
COMMENT ON COLUMN admin_requests.token_hash IS 'Hashed approval token for secure email links';
COMMENT ON COLUMN admin_requests.token_expires_at IS 'Expiry timestamp for approval token (default 60 minutes)';
