-- Clear existing data first to prevent duplicates
DELETE FROM districts WHERE region = 'Surxondaryo';
DELETE FROM directions;

-- Insert the 14 districts (tuman) of Surxondaryo viloyati
INSERT INTO districts (name, region, description, is_active) VALUES
  -- Using exact district names from user's list
  ('Angor', 'Surxondaryo', 'Angor tumani', true),
  ('Boysun', 'Surxondaryo', 'Boysun tumani', true),
  ('Denov', 'Surxondaryo', 'Denov tumani', true),
  ('Jarqorgon', 'Surxondaryo', 'Jarqorgon tumani', true),
  ('Muzrabot', 'Surxondaryo', 'Muzrabot tumani', true),
  ('Kumqorgon', 'Surxondaryo', 'Kumqorgon tumani', true),
  ('Sariosiyo', 'Surxondaryo', 'Sariosiyo tumani', true),
  ('Sherobod', 'Surxondaryo', 'Sherobod tumani', true),
  ('Shurchi', 'Surxondaryo', 'Shurchi tumani', true),
  ('Termiz', 'Surxondaryo', 'Termiz shahri', true),
  ('Uzun', 'Surxondaryo', 'Uzun tumani', true),
  ('Altinsoy', 'Surxondaryo', 'Altinsoy tumani', true),
  ('Bandixon', 'Surxondaryo', 'Bandixon tumani', true),
  ('Altynkul', 'Surxondaryo', 'Altynkul tumani', true);

-- Insert the 9 predefined leadership roles (yo'nalish sardorlari)
INSERT INTO directions (name, description, is_active) VALUES
  ('Bosh sardori', 'Umumiy rahbariyat va muvofiqlashtirish', true),
  ('Jasorat yo''nalishi sardori', 'Jasorat va g''ayrat bo''yicha ishlar', true),
  ('Ibrat farzandlari yo''nalishi sardori', 'Ibrat farzandlari dasturi bo''yicha ishlar', true),
  ('Ustoz AI yo''nalishi sardori', 'Sun''iy intellekt va ta''lim texnologiyalari', true),
  ('Yashil makon yo''nalishi sardori', 'Ekologiya va atrof-muhitni muhofaza qilish', true),
  ('Mutolaa yo''nalishi sardori', 'Kitob o''qish va ma''rifiy faoliyat', true),
  ('Qizlar akademiyasi yo''nalishi sardori', 'Qizlarni rivojlantirish dasturlari', true),
  ('Iqtidor yo''nalishi sardori', 'Iste''dodli bolalarni qo''llab-quvvatlash', true),
  ('Matbuot va media yo''nalishi sardori', 'Axborot va media faoliyati', true);
