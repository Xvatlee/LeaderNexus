-- Projects table for leader initiatives
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  leader_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  category VARCHAR(100),
  status VARCHAR(50) DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'completed', 'cancelled')),
  visibility VARCHAR(50) DEFAULT 'public' CHECK (visibility IN ('public', 'private', 'members_only')),
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  target_region VARCHAR(100),
  budget DECIMAL(10, 2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Project collaborators (leaders who join/support projects)
CREATE TABLE IF NOT EXISTS project_collaborators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  role VARCHAR(50) DEFAULT 'supporter' CHECK (role IN ('owner', 'collaborator', 'supporter')),
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(project_id, user_id)
);

-- Project updates/milestones for tracking progress
CREATE TABLE IF NOT EXISTS project_updates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  update_type VARCHAR(50) DEFAULT 'progress' CHECK (update_type IN ('progress', 'milestone', 'announcement', 'challenge')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Project comments for discussion
CREATE TABLE IF NOT EXISTS project_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  parent_id UUID REFERENCES project_comments(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_projects_leader_id ON projects(leader_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_project_collaborators_project_id ON project_collaborators(project_id);
CREATE INDEX IF NOT EXISTS idx_project_collaborators_user_id ON project_collaborators(user_id);
CREATE INDEX IF NOT EXISTS idx_project_updates_project_id ON project_updates(project_id);
CREATE INDEX IF NOT EXISTS idx_project_comments_project_id ON project_comments(project_id);

-- Enable Row Level Security
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_collaborators ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_comments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for projects
CREATE POLICY "Public projects are viewable by everyone"
  ON projects FOR SELECT
  USING (visibility = 'public' OR visibility = 'members_only');

CREATE POLICY "Leaders can insert their own projects"
  ON projects FOR INSERT
  WITH CHECK (auth.uid() = leader_id);

CREATE POLICY "Leaders can update their own projects"
  ON projects FOR UPDATE
  USING (auth.uid() = leader_id);

CREATE POLICY "Leaders can delete their own projects"
  ON projects FOR DELETE
  USING (auth.uid() = leader_id);

-- RLS Policies for project_collaborators
CREATE POLICY "Anyone can view project collaborators"
  ON project_collaborators FOR SELECT
  USING (true);

CREATE POLICY "Users can join projects as collaborators"
  ON project_collaborators FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can leave projects they've joined"
  ON project_collaborators FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for project_updates
CREATE POLICY "Anyone can view project updates"
  ON project_updates FOR SELECT
  USING (true);

CREATE POLICY "Project leaders and collaborators can create updates"
  ON project_updates FOR INSERT
  WITH CHECK (
    auth.uid() = author_id AND (
      EXISTS (SELECT 1 FROM projects WHERE id = project_id AND leader_id = auth.uid()) OR
      EXISTS (SELECT 1 FROM project_collaborators WHERE project_id = project_updates.project_id AND user_id = auth.uid())
    )
  );

-- RLS Policies for project_comments
CREATE POLICY "Anyone can view project comments"
  ON project_comments FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create project comments"
  ON project_comments FOR INSERT
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own project comments"
  ON project_comments FOR UPDATE
  USING (auth.uid() = author_id);

CREATE POLICY "Users can delete their own project comments"
  ON project_comments FOR DELETE
  USING (auth.uid() = author_id);
