-- Function to create profile on user signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, username, full_name, avatar_url, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    coalesce(new.raw_user_meta_data->>'avatar_url', ''),
    coalesce(new.raw_user_meta_data->>'role', 'leader')
  )
  on conflict (id) do nothing;
  
  return new;
end;
$$;

-- Trigger to auto-create profile
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();

-- Function to update comment count on posts
create or replace function public.update_post_comment_count()
returns trigger
language plpgsql
as $$
begin
  if TG_OP = 'INSERT' then
    update public.posts
    set comments_count = comments_count + 1
    where id = new.post_id;
  elsif TG_OP = 'DELETE' then
    update public.posts
    set comments_count = comments_count - 1
    where id = old.post_id;
  end if;
  
  return null;
end;
$$;

-- Trigger for comment count
drop trigger if exists update_comment_count on public.comments;
create trigger update_comment_count
  after insert or delete on public.comments
  for each row
  execute function public.update_post_comment_count();

-- Function to update like count on posts
create or replace function public.update_post_like_count()
returns trigger
language plpgsql
as $$
begin
  if TG_OP = 'INSERT' then
    update public.posts
    set likes = likes + 1
    where id = new.post_id;
  elsif TG_OP = 'DELETE' then
    update public.posts
    set likes = likes - 1
    where id = old.post_id;
  end if;
  
  return null;
end;
$$;

-- Trigger for like count
drop trigger if exists update_like_count on public.post_likes;
create trigger update_like_count
  after insert or delete on public.post_likes
  for each row
  execute function public.update_post_like_count();
