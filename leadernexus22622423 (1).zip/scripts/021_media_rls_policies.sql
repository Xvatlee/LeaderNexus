-- Check if media_files table exists before enabling RLS
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'media_files') THEN
    ALTER TABLE media_files ENABLE ROW LEVEL SECURITY;
  END IF;
  
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'media_likes') THEN
    ALTER TABLE media_likes ENABLE ROW LEVEL SECURITY;
  END IF;
  
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'media_comments') THEN
    ALTER TABLE media_comments ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Drop existing policies before creating to avoid conflicts
DROP POLICY IF EXISTS "Public can view approved media" ON media_files;
DROP POLICY IF EXISTS "Users can view their own media" ON media_files;
DROP POLICY IF EXISTS "Authenticated users can upload media" ON media_files;
DROP POLICY IF EXISTS "Users can update own pending media" ON media_files;
DROP POLICY IF EXISTS "Users can delete own media" ON media_files;
DROP POLICY IF EXISTS "Anyone can view likes" ON media_likes;
DROP POLICY IF EXISTS "Authenticated users can like" ON media_likes;
DROP POLICY IF EXISTS "Users can remove their likes" ON media_likes;
DROP POLICY IF EXISTS "Anyone can view comments" ON media_comments;
DROP POLICY IF EXISTS "Authenticated users can comment" ON media_comments;
DROP POLICY IF EXISTS "Users can update own comments" ON media_comments;
DROP POLICY IF EXISTS "Users can delete own comments" ON media_comments;

-- Policies for media_files (only create if table exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'media_files') THEN
    -- Anyone can view approved public media
    EXECUTE 'CREATE POLICY "Public can view approved media" ON media_files FOR SELECT TO public USING (status = ''approved'')';
    
    -- Authenticated users can view their own media regardless of status
    EXECUTE 'CREATE POLICY "Users can view their own media" ON media_files FOR SELECT TO authenticated USING (uploaded_by = auth.uid())';
    
    -- Authenticated users can upload media
    EXECUTE 'CREATE POLICY "Authenticated users can upload media" ON media_files FOR INSERT TO authenticated WITH CHECK (uploaded_by = auth.uid())';
    
    -- Users can update their own pending media
    EXECUTE 'CREATE POLICY "Users can update own pending media" ON media_files FOR UPDATE TO authenticated USING (uploaded_by = auth.uid() AND status = ''pending'') WITH CHECK (uploaded_by = auth.uid() AND status = ''pending'')';
    
    -- Users can delete their own media
    EXECUTE 'CREATE POLICY "Users can delete own media" ON media_files FOR DELETE TO authenticated USING (uploaded_by = auth.uid())';
  END IF;
END $$;

-- Policies for media_likes
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'media_likes') THEN
    EXECUTE 'CREATE POLICY "Anyone can view likes" ON media_likes FOR SELECT TO public USING (true)';
    EXECUTE 'CREATE POLICY "Authenticated users can like" ON media_likes FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid())';
    EXECUTE 'CREATE POLICY "Users can remove their likes" ON media_likes FOR DELETE TO authenticated USING (user_id = auth.uid())';
  END IF;
END $$;

-- Policies for media_comments
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'media_comments') THEN
    EXECUTE 'CREATE POLICY "Anyone can view comments" ON media_comments FOR SELECT TO public USING (true)';
    EXECUTE 'CREATE POLICY "Authenticated users can comment" ON media_comments FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid())';
    EXECUTE 'CREATE POLICY "Users can update own comments" ON media_comments FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid())';
    EXECUTE 'CREATE POLICY "Users can delete own comments" ON media_comments FOR DELETE TO authenticated USING (user_id = auth.uid())';
  END IF;
END $$;
