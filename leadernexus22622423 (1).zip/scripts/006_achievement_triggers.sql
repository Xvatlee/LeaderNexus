-- Function to check and award achievements based on points
create or replace function check_and_award_achievements()
returns trigger
language plpgsql
security definer
as $$
declare
  achievement_record record;
begin
  -- Check all achievements that the user qualifies for but hasn't earned yet
  for achievement_record in
    select a.id, a.name, a.points_required
    from achievements a
    where a.points_required <= new.points
    and not exists (
      select 1
      from user_achievements ua
      where ua.user_id = new.id
      and ua.achievement_id = a.id
    )
  loop
    -- Award the achievement
    insert into user_achievements (user_id, achievement_id)
    values (new.id, achievement_record.id)
    on conflict do nothing;
    
    -- Create notification for earned achievement
    insert into notifications (user_id, type, title, message, action_url)
    values (
      new.id,
      'achievement',
      'Achievement Unlocked!',
      'You earned the "' || achievement_record.name || '" badge!',
      '/achievements'
    );
  end loop;
  
  return new;
end;
$$;

-- Trigger to check achievements when points are updated
drop trigger if exists check_achievements_on_points_update on profiles;
create trigger check_achievements_on_points_update
  after update of points on profiles
  for each row
  when (new.points > old.points)
  execute function check_and_award_achievements();

-- Award like points to post author
create or replace function award_like_points()
returns trigger
language plpgsql
security definer
as $$
declare
  post_author_id uuid;
begin
  if TG_OP = 'INSERT' then
    -- Get the post author
    select author_id into post_author_id
    from posts
    where id = new.post_id;
    
    -- Award points to the author
    update profiles
    set points = points + 2
    where id = post_author_id;
    
    -- Log transaction
    insert into point_transactions (user_id, amount, reason)
    values (post_author_id, 2, 'Received a like');
    
  elsif TG_OP = 'DELETE' then
    -- Get the post author
    select author_id into post_author_id
    from posts
    where id = old.post_id;
    
    -- Remove points from the author
    update profiles
    set points = greatest(0, points - 2)
    where id = post_author_id;
  end if;
  
  return null;
end;
$$;

-- Trigger for like points
drop trigger if exists award_like_points_trigger on post_likes;
create trigger award_like_points_trigger
  after insert or delete on post_likes
  for each row
  execute function award_like_points();
