-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create improved handle_new_user function with better error handling
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role TEXT;
  user_district TEXT;
  user_direction TEXT;
BEGIN
  -- Extract metadata with defaults
  user_role := COALESCE((NEW.raw_user_meta_data->>'role')::TEXT, 'viewer');
  user_district := NULLIF(TRIM(COALESCE((NEW.raw_user_meta_data->>'district')::TEXT, '')), '');
  user_direction := NULLIF(TRIM(COALESCE((NEW.raw_user_meta_data->>'direction')::TEXT, '')), '');

  -- Insert into profiles with proper null handling
  INSERT INTO public.profiles (
    id,
    email,
    username,
    full_name,
    role,
    district,
    direction,
    avatar_url,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE((NEW.raw_user_meta_data->>'username')::TEXT, split_part(NEW.email, '@', 1)),
    COALESCE((NEW.raw_user_meta_data->>'full_name')::TEXT, split_part(NEW.email, '@', 1)),
    user_role,
    user_district,
    user_direction,
    COALESCE((NEW.raw_user_meta_data->>'avatar_url')::TEXT, NULL),
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    username = EXCLUDED.username,
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    district = EXCLUDED.district,
    direction = EXCLUDED.direction,
    updated_at = NOW();

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log the error (will appear in Postgres logs)
    RAISE LOG 'Error in handle_new_user for user %: % %', NEW.id, SQLERRM, SQLSTATE;
    -- Re-raise to prevent user creation if profile fails
    RAISE;
END;
$$;

-- Recreate the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO authenticated;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;
