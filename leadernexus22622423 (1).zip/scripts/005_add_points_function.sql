-- Function to increment user points
create or replace function increment_user_points(user_id uuid, points integer)
returns void
language plpgsql
security definer
as $$
begin
  update profiles
  set points = points + increment_user_points.points
  where id = increment_user_points.user_id;
  
  insert into point_transactions (user_id, amount, reason)
  values (increment_user_points.user_id, increment_user_points.points, 'Activity reward');
end;
$$;
