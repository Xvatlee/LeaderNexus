-- Add district_id column to leader_directions if it doesn't exist
ALTER TABLE leader_directions 
ADD COLUMN IF NOT EXISTS district_id UUID REFERENCES districts(id) ON DELETE CASCADE;

-- Add user_id column (for compatibility with profiles table)
ALTER TABLE leader_directions 
ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- Sync user_id from leader_id if needed
UPDATE leader_directions SET user_id = leader_id WHERE user_id IS NULL;

-- Create index on district_id and user_id
CREATE INDEX IF NOT EXISTS idx_leader_directions_district ON leader_directions(district_id);
CREATE INDEX IF NOT EXISTS idx_leader_directions_user ON leader_directions(user_id);

-- Update the unique constraint to include district
ALTER TABLE leader_directions DROP CONSTRAINT IF EXISTS leader_directions_leader_id_direction_id_key;
ALTER TABLE leader_directions DROP CONSTRAINT IF EXISTS leader_directions_unique_assignment;
ALTER TABLE leader_directions 
ADD CONSTRAINT leader_directions_unique_assignment 
UNIQUE(district_id, direction_id);

-- Add RLS policies for leader_directions
ALTER TABLE leader_directions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Anyone can view leader_directions" ON leader_directions;
DROP POLICY IF EXISTS "Only admins can modify leader_directions" ON leader_directions;

-- Policy: Anyone can read leader_directions
CREATE POLICY "Anyone can view leader_directions" 
ON leader_directions FOR SELECT 
TO authenticated 
USING (true);

-- Policy: Users can insert their own leader_directions
CREATE POLICY "Users can insert own leader_directions" 
ON leader_directions FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() = user_id OR auth.uid() = leader_id);

-- Policy: Only admins can update/delete leader_directions
CREATE POLICY "Only admins can modify leader_directions" 
ON leader_directions FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  )
);
