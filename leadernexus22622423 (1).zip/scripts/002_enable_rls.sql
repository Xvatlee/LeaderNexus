-- Enable Row Level Security on all tables
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.notifications enable row level security;
alter table public.achievements enable row level security;
alter table public.user_achievements enable row level security;
alter table public.point_transactions enable row level security;
alter table public.post_likes enable row level security;

-- Profiles policies
create policy "profiles_select_all" on public.profiles for select using (true);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

-- Posts policies
create policy "posts_select_all" on public.posts for select using (true);
create policy "posts_insert_authenticated" on public.posts for insert with check (auth.uid() = author_id);
create policy "posts_update_own" on public.posts for update using (auth.uid() = author_id);
create policy "posts_delete_own" on public.posts for delete using (auth.uid() = author_id);

-- Comments policies
create policy "comments_select_all" on public.comments for select using (true);
create policy "comments_insert_authenticated" on public.comments for insert with check (auth.uid() = author_id);
create policy "comments_update_own" on public.comments for update using (auth.uid() = author_id);
create policy "comments_delete_own" on public.comments for delete using (auth.uid() = author_id);

-- Notifications policies
create policy "notifications_select_own" on public.notifications for select using (auth.uid() = user_id);
create policy "notifications_update_own" on public.notifications for update using (auth.uid() = user_id);

-- Achievements policies (public read, admin write)
create policy "achievements_select_all" on public.achievements for select using (true);

-- User achievements policies
create policy "user_achievements_select_all" on public.user_achievements for select using (true);

-- Point transactions policies
create policy "point_transactions_select_own" on public.point_transactions for select using (auth.uid() = user_id);

-- Post likes policies
create policy "post_likes_select_all" on public.post_likes for select using (true);
create policy "post_likes_insert_own" on public.post_likes for insert with check (auth.uid() = user_id);
create policy "post_likes_delete_own" on public.post_likes for delete using (auth.uid() = user_id);
