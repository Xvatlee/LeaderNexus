import { redirect, notFound } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { ReportDetailView } from "@/components/reports/report-detail-view"

export default async function ViloyatReportDetailPage({ params }: { params: { id: string } }) {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is Bosh sardori
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, leader_directions(direction_id, directions(name))")
    .eq("id", user.id)
    .single()

  const isBoshSardori = profile?.leader_directions?.some((ld: any) => ld.directions?.name === "Bosh sardori")

  if (!isBoshSardori) {
    redirect("/dashboard")
  }

  // Get report details
  const { data: report } = await supabase
    .from("reports")
    .select(`
      *,
      profiles(username, full_name, avatar_url),
      districts(name)
    `)
    .eq("id", params.id)
    .single()

  if (!report) {
    notFound()
  }

  // Get feedback for this report
  const { data: feedback } = await supabase
    .from("report_feedback")
    .select(`
      *,
      profiles(username, full_name, avatar_url)
    `)
    .eq("report_id", params.id)
    .order("created_at", { ascending: false })

  // Get comments
  const { data: comments } = await supabase
    .from("report_comments")
    .select(`
      *,
      profiles(username, full_name, avatar_url)
    `)
    .eq("report_id", params.id)
    .order("created_at", { ascending: true })

  return (
    <div className="container max-w-6xl py-8">
      <ReportDetailView
        report={report}
        feedback={feedback || []}
        comments={comments || []}
        userRole="viloyat"
        currentUserId={user.id}
      />
    </div>
  )
}
