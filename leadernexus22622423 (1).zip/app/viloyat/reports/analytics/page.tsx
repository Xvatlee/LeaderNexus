import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { ReportsAnalytics } from "@/components/reports/reports-analytics"

export default async function ViloyatReportsAnalyticsPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is Bosh sardori
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, leader_directions(direction_id, directions(name))")
    .eq("id", user.id)
    .single()

  const isBoshSardori = profile?.leader_directions?.some((ld: any) => ld.directions?.name === "Bosh sardori")

  if (!isBoshSardori) {
    redirect("/dashboard")
  }

  // Get all reports for analysis
  const { data: reports } = await supabase
    .from("reports")
    .select(`
      *,
      districts(id, name)
    `)
    .order("report_period", { ascending: false })

  // Get districts
  const { data: districts } = await supabase.from("districts").select("*").eq("region", "Surxondaryo")

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Hisobotlar tahlili</h1>
        <p className="text-muted-foreground">Tumanlar samaradorligini taqqoslash va tahlil qilish</p>
      </div>

      {reports && districts && <ReportsAnalytics reports={reports} districts={districts} />}
    </div>
  )
}
