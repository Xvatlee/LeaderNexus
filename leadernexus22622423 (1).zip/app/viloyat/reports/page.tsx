import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, AlertTriangle, CheckCircle, Clock } from "lucide-react"
import { ViloyatReportsOverview } from "@/components/reports/viloyat-reports-overview"
import { ReportAlerts } from "@/components/reports/report-alerts"

export default async function ViloyatReportsPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is Bosh sardori (Viloyat sardori)
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, leader_directions(direction_id, directions(name))")
    .eq("id", user.id)
    .single()

  const isBoshSardori = profile?.leader_directions?.some((ld: any) => ld.directions?.name === "Bosh sardori")

  if (!isBoshSardori) {
    redirect("/dashboard")
  }

  // Get all reports from Surxondaryo region
  const { data: allReports } = await supabase
    .from("reports")
    .select(`
      *,
      profiles(username, full_name),
      districts(name)
    `)
    .order("created_at", { ascending: false })

  // Get report statistics
  const totalReports = allReports?.length || 0
  const submittedReports = allReports?.filter((r) => r.status === "submitted").length || 0
  const approvedReports = allReports?.filter((r) => r.status === "approved").length || 0
  const draftReports = allReports?.filter((r) => r.status === "draft").length || 0

  // Get alerts for missing/overdue reports
  const { data: alerts } = await supabase
    .from("report_alerts")
    .select("*, districts(name)")
    .eq("is_resolved", false)
    .order("created_at", { ascending: false })

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Hisobotlarni monitoring qilish</h1>
        <p className="text-muted-foreground">Surxondaryo viloyati tumanlaridan kelgan hisobotlar</p>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami hisobotlar</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalReports}</div>
            <p className="text-xs text-muted-foreground">Barcha tumanlardan</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Yuborilgan</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{submittedReports}</div>
            <p className="text-xs text-muted-foreground">Ko'rib chiqilishi kerak</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasdiqlangan</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{approvedReports}</div>
            <p className="text-xs text-muted-foreground">Tasdiqlanganlar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ogohlantirishlar</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alerts?.length || 0}</div>
            <p className="text-xs text-muted-foreground">Hal qilinishi kerak</p>
          </CardContent>
        </Card>
      </div>

      {/* Alerts Section */}
      {alerts && alerts.length > 0 && (
        <div className="mb-8">
          <ReportAlerts alerts={alerts} />
        </div>
      )}

      {/* Reports Overview */}
      {allReports && <ViloyatReportsOverview reports={allReports} />}
    </div>
  )
}
