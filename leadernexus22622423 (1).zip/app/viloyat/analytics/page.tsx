"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { AnalyticsContent } from "@/components/ratings/analytics-content"
import type { Profile } from "@/lib/types/database.types"

export default function ViloyatAnalyticsPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function checkAccess() {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      if (!userProfile || (userProfile.role !== "viloyat_sardori" && userProfile.role !== "admin")) {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)
      setLoading(false)
    }

    checkAccess()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Yuklanmoqda...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />
      <AnalyticsContent />
    </div>
  )
}
