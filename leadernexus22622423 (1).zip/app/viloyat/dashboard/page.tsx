"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Building2,
  TrendingUp,
  TrendingDown,
  Users,
  Target,
  AlertCircle,
  Award,
  Download,
  MapPin,
  BarChart3,
} from "lucide-react"
import Link from "next/link"
import type { Profile, Tuman, DistrictRating } from "@/lib/types/database.types"
import { ViloyatOverviewCharts } from "@/components/viloyat/overview-charts"
import { DistrictComparisonTable } from "@/components/viloyat/district-comparison-table"
import { ProjectsOverview } from "@/components/viloyat/projects-overview"
import { IssuesTracking } from "@/components/viloyat/issues-tracking"

export default function ViloyatDashboardPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [districts, setDistricts] = useState<Tuman[]>([])
  const [ratings, setRatings] = useState<DistrictRating[]>([])
  const [stats, setStats] = useState({
    totalDistricts: 0,
    averageRating: 0,
    totalProjects: 0,
    completedProjects: 0,
    activeIssues: 0,
    resolvedIssues: 0,
  })
  const [loading, setLoading] = useState(true)
  const [timePeriod, setTimePeriod] = useState("current")

  useEffect(() => {
    loadDashboardData()
  }, [timePeriod])

  async function loadDashboardData() {
    try {
      const supabase = createClient()

      // Get authenticated user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      // Get user profile
      const { data: userProfile, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single()

      if (profileError || !userProfile) {
        console.error("[v0] Profile error:", profileError)
        redirect("/dashboard")
        return
      }

      // Check if user is viloyat sardori
      if (userProfile.role !== "viloyat_sardori" && userProfile.role !== "admin") {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      // Load districts in this viloyat
      const { data: districtsData, error: districtsError } = await supabase
        .from("tuman")
        .select("*")
        .eq("viloyat_id", userProfile.viloyat_id)
        .order("name")

      if (!districtsError && districtsData) {
        setDistricts(districtsData)
        setStats((prev) => ({ ...prev, totalDistricts: districtsData.length }))
      }

      // Load current ratings for all districts
      const currentDate = new Date().toISOString().split("T")[0]
      const { data: ratingsData, error: ratingsError } = await supabase
        .from("district_ratings")
        .select("*, tuman:tuman_id(*)")
        .in("tuman_id", districtsData?.map((d) => d.id) || [])
        .eq("rating_period", currentDate)
        .order("overall_score", { ascending: false })

      if (!ratingsError && ratingsData) {
        setRatings(ratingsData)
        const avgRating = ratingsData.reduce((sum, r) => sum + (r.overall_score || 0), 0) / (ratingsData.length || 1)
        setStats((prev) => ({ ...prev, averageRating: avgRating }))
      }

      // Load projects statistics
      const { data: projectsData } = await supabase
        .from("projects")
        .select("status, tuman:tuman_id!inner(viloyat_id)")
        .eq("tuman.viloyat_id", userProfile.viloyat_id)

      if (projectsData) {
        const completed = projectsData.filter((p) => p.status === "completed").length
        setStats((prev) => ({
          ...prev,
          totalProjects: projectsData.length,
          completedProjects: completed,
        }))
      }

      // Load issues statistics
      const { data: issuesData } = await supabase
        .from("issues")
        .select("status, tuman:tuman_id!inner(viloyat_id)")
        .eq("tuman.viloyat_id", userProfile.viloyat_id)

      if (issuesData) {
        const resolved = issuesData.filter((i) => i.status === "resolved" || i.status === "closed").length
        const active = issuesData.filter((i) => i.status === "open" || i.status === "in_progress").length
        setStats((prev) => ({
          ...prev,
          activeIssues: active,
          resolvedIssues: resolved,
        }))
      }

      setLoading(false)
    } catch (error) {
      console.error("[v0] Dashboard error:", error)
      setLoading(false)
    }
  }

  function exportData() {
    const csv = [
      ["Tuman", "Umumiy ball", "Loyihalar", "Jamoatchilik", "Yetakchilik", "Innovatsiya", "O'rin"],
      ...ratings.map((r) => [
        r.tuman?.name,
        r.overall_score?.toFixed(1),
        r.project_completion_score?.toFixed(1),
        r.community_engagement_score?.toFixed(1),
        r.leadership_score?.toFixed(1),
        r.innovation_score?.toFixed(1),
        r.rank,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `viloyat-reyting-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Yuklanmoqda...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8 px-4 max-w-7xl mx-auto">
        <div className="space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold tracking-tight flex items-center gap-3">
                <Building2 className="h-8 w-8" />
                Viloyat boshqaruv paneli
              </h1>
              <p className="text-muted-foreground mt-2">Barcha tumanlar va loyihalarni kuzatib boring va boshqaring</p>
            </div>
            <div className="flex items-center gap-2">
              <Select value={timePeriod} onValueChange={setTimePeriod}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current">Joriy davr</SelectItem>
                  <SelectItem value="last_month">O'tgan oy</SelectItem>
                  <SelectItem value="last_quarter">O'tgan chorak</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={exportData} variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Eksport
              </Button>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tumanlar soni</CardTitle>
                <MapPin className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalDistricts}</div>
                <p className="text-xs text-muted-foreground mt-1">Jami tumanlar</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">O'rtacha reyting</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.averageRating.toFixed(1)}</div>
                <p className="text-xs text-muted-foreground mt-1">100 balldan</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Loyihalar</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalProjects}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stats.completedProjects} tugallangan (
                  {stats.totalProjects > 0 ? ((stats.completedProjects / stats.totalProjects) * 100).toFixed(0) : 0}%)
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Muammolar</CardTitle>
                <AlertCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.activeIssues}</div>
                <p className="text-xs text-muted-foreground mt-1">{stats.resolvedIssues} hal qilingan</p>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full max-w-2xl grid-cols-4">
              <TabsTrigger value="overview">Umumiy ko'rinish</TabsTrigger>
              <TabsTrigger value="districts">Tumanlar reytingi</TabsTrigger>
              <TabsTrigger value="projects">Loyihalar</TabsTrigger>
              <TabsTrigger value="issues">Muammolar</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <ViloyatOverviewCharts viloyatId={profile?.viloyat_id || ""} ratings={ratings} />

              {/* Top & Bottom Performers */}
              <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                      Eng yaxshi tumanlar
                    </CardTitle>
                    <CardDescription>Yuqori ko'rsatkichga ega tumanlar</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {ratings.slice(0, 5).map((rating, index) => (
                        <div key={rating.id} className="flex items-center gap-3 p-3 rounded-lg border">
                          <div
                            className={`flex items-center justify-center w-8 h-8 rounded-full font-bold ${
                              index === 0
                                ? "bg-yellow-100 text-yellow-700"
                                : index === 1
                                  ? "bg-gray-100 text-gray-700"
                                  : index === 2
                                    ? "bg-orange-100 text-orange-700"
                                    : "bg-accent text-foreground"
                            }`}
                          >
                            {rating.rank || index + 1}
                          </div>
                          <div className="flex-1">
                            <p className="font-semibold">{rating.tuman?.name}</p>
                            <div className="flex gap-2 mt-1">
                              <Badge variant="secondary" className="text-xs">
                                Loyihalar: {rating.project_completion_score?.toFixed(0)}
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                Jamoa: {rating.community_engagement_score?.toFixed(0)}
                              </Badge>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-xl font-bold text-green-600">{rating.overall_score?.toFixed(1)}</p>
                            <p className="text-xs text-muted-foreground">ball</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingDown className="h-5 w-5 text-orange-600" />
                      E'tibor talab qiladi
                    </CardTitle>
                    <CardDescription>Yaxshilanishi kerak bo'lgan tumanlar</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {ratings
                        .slice()
                        .reverse()
                        .slice(0, 5)
                        .map((rating) => (
                          <div key={rating.id} className="flex items-center gap-3 p-3 rounded-lg border">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-orange-100 text-orange-700 font-bold">
                              {rating.rank}
                            </div>
                            <div className="flex-1">
                              <p className="font-semibold">{rating.tuman?.name}</p>
                              <div className="flex gap-2 mt-1">
                                <Badge variant="secondary" className="text-xs">
                                  Loyihalar: {rating.project_completion_score?.toFixed(0)}
                                </Badge>
                                <Badge variant="secondary" className="text-xs">
                                  Jamoa: {rating.community_engagement_score?.toFixed(0)}
                                </Badge>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-xl font-bold text-orange-600">{rating.overall_score?.toFixed(1)}</p>
                              <p className="text-xs text-muted-foreground">ball</p>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Districts Tab */}
            <TabsContent value="districts" className="space-y-6">
              <DistrictComparisonTable ratings={ratings} districts={districts} />
            </TabsContent>

            {/* Projects Tab */}
            <TabsContent value="projects" className="space-y-6">
              <ProjectsOverview viloyatId={profile?.viloyat_id || ""} districts={districts} />
            </TabsContent>

            {/* Issues Tab */}
            <TabsContent value="issues" className="space-y-6">
              <IssuesTracking viloyatId={profile?.viloyat_id || ""} districts={districts} />
            </TabsContent>
          </Tabs>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Tezkor harakatlar</CardTitle>
              <CardDescription>Tez-tez ishlatiladigan funksiyalar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Button asChild variant="outline" className="h-24 flex-col gap-2 bg-transparent">
                  <Link href="/viloyat/districts">
                    <MapPin className="h-6 w-6" />
                    <span className="text-sm font-semibold">Tumanlarni boshqarish</span>
                  </Link>
                </Button>

                <Button asChild variant="outline" className="h-24 flex-col gap-2 bg-transparent">
                  <Link href="/viloyat/projects">
                    <Target className="h-6 w-6" />
                    <span className="text-sm font-semibold">Barcha loyihalar</span>
                  </Link>
                </Button>

                <Button asChild variant="outline" className="h-24 flex-col gap-2 bg-transparent">
                  <Link href="/viloyat/analytics">
                    <BarChart3 className="h-6 w-6" />
                    <span className="text-sm font-semibold">Tahlil va hisobotlar</span>
                  </Link>
                </Button>

                <Button asChild variant="outline" className="h-24 flex-col gap-2 bg-transparent">
                  <Link href="/viloyat/sardors">
                    <Users className="h-6 w-6" />
                    <span className="text-sm font-semibold">Sardorlar ro'yxati</span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
