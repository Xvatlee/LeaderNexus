import { Suspense } from "react"
import { createClient } from "@/lib/supabase/server"
import { MediaGallery } from "@/components/media/media-gallery"
import { Button } from "@/components/ui/button"
import { Upload } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Media galereyasi | LeaderNexus",
  description: "Rasmlar, videolar va hujjatlar galereyasi",
}

export default async function MediaPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Fetch districts and directions for filters
  const { data: districts } = await supabase.from("districts").select("id, name").eq("is_active", true).order("name")

  const { data: directions } = await supabase.from("directions").select("id, name").eq("is_active", true).order("name")

  return (
    <div className="container mx-auto max-w-7xl py-6 sm:py-8 px-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 sm:mb-8 gap-4">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl sm:text-3xl font-bold">Media galereyasi</h1>
          <p className="text-muted-foreground mt-2 text-sm sm:text-base">
            Barcha tumanlardagi faoliyat rasmlari va videolari
          </p>
        </div>
        {user && (
          <Button asChild className="w-full sm:w-auto">
            <Link href="/media/upload">
              <Upload className="mr-2 h-4 w-4" />
              Yuklash
            </Link>
          </Button>
        )}
      </div>

      <Suspense fallback={<div className="text-center py-12">Yuklanmoqda...</div>}>
        <MediaGallery
          searchParams={searchParams}
          districts={districts || []}
          directions={directions || []}
          userId={user?.id}
        />
      </Suspense>
    </div>
  )
}
