import { Suspense } from "react"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { MediaUploadForm } from "@/components/media/media-upload-form"
import { MediaSetupCheck } from "@/components/media/media-setup-check"

export const metadata = {
  title: "Fayl yuklash | LeaderNexus",
  description: "Rasm, video yoki hujjat yuklang",
}

export default async function MediaUploadPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Fetch user profile for district and direction info
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, districts(name), directions(name)")
    .eq("id", user.id)
    .single()

  // Fetch districts and directions for selection
  const { data: districts } = await supabase.from("districts").select("id, name").eq("is_active", true).order("name")

  const { data: directions } = await supabase.from("directions").select("id, name").eq("is_active", true).order("name")

  return (
    <div className="container max-w-4xl py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Media yuklash</h1>
        <p className="text-muted-foreground mt-2">Rasm, video yoki hujjat yuklab, jamoangiz faoliyatini ulashing</p>
      </div>

      <div className="mb-6">
        <MediaSetupCheck />
      </div>

      <Suspense fallback={<div>Yuklanmoqda...</div>}>
        <MediaUploadForm profile={profile} districts={districts || []} directions={directions || []} />
      </Suspense>
    </div>
  )
}
