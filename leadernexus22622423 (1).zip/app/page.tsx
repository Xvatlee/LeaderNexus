"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Users, MessageSquare, Trophy, TrendingUp, Zap, Shield, Lightbulb, Vote, Menu, X } from "lucide-react"
import { useTranslations } from "@/lib/i18n/use-translations"
import { LanguageSwitcher } from "@/components/language-switcher"
import { useState } from "react"

export default function LandingPage() {
  const { t } = useTranslations()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 animate-fade-in-up">
        <div className="container mx-auto flex h-14 sm:h-16 items-center justify-between gap-2 sm:gap-4">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 sm:h-6 sm:w-6 icon-hover" />
            <span className="text-lg sm:text-xl font-bold">LeaderNexus</span>
          </div>

          <nav className="hidden md:flex items-center gap-2 lg:gap-4 flex-wrap">
            <Link href="#features" className="text-sm font-medium link-hover whitespace-nowrap">
              {t("landing.hero.learnMore")}
            </Link>
            <Link href="#community" className="text-sm font-medium link-hover whitespace-nowrap">
              {t("nav.community")}
            </Link>
            <LanguageSwitcher />
            <Button asChild variant="ghost" size="sm" className="btn-hover">
              <Link href="/auth/login">{t("nav.signIn")}</Link>
            </Button>
            <Button asChild size="sm" className="btn-hover">
              <Link href="/auth/register">{t("nav.getStarted")}</Link>
            </Button>
          </nav>

          <div className="flex md:hidden items-center gap-2">
            <LanguageSwitcher />
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden border-t bg-background/95 backdrop-blur animate-fade-in-up">
            <nav className="container mx-auto py-4 flex flex-col gap-3">
              <Link
                href="#features"
                className="text-sm font-medium py-2 px-3 rounded-md hover:bg-muted transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                {t("landing.hero.learnMore")}
              </Link>
              <Link
                href="#community"
                className="text-sm font-medium py-2 px-3 rounded-md hover:bg-muted transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                {t("nav.community")}
              </Link>
              <div className="flex gap-2 pt-2 border-t">
                <Button asChild variant="outline" size="sm" className="flex-1 bg-transparent">
                  <Link href="/auth/login">{t("nav.signIn")}</Link>
                </Button>
                <Button asChild size="sm" className="flex-1">
                  <Link href="/auth/register">{t("nav.getStarted")}</Link>
                </Button>
              </div>
            </nav>
          </div>
        )}
      </header>

      <section className="container mx-auto flex flex-col items-center justify-center gap-6 sm:gap-8 py-12 sm:py-16 lg:py-24 xl:py-32 px-4">
        <div className="flex max-w-4xl flex-col items-center gap-4 sm:gap-6 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold tracking-tight text-balance animate-heading">
            {t("landing.hero.title")}
          </h1>
          <p className="text-base sm:text-lg lg:text-xl text-muted-foreground max-w-2xl animate-fade-in-up animate-stagger-1">
            {t("landing.hero.subtitle")}
          </p>
          <div className="flex gap-3 sm:gap-4 flex-wrap justify-center animate-fade-in-up animate-stagger-2 w-full sm:w-auto">
            <Button asChild size="lg" className="btn-hover flex-1 sm:flex-none min-w-[140px]">
              <Link href="/auth/register">{t("landing.hero.cta")}</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="btn-hover bg-transparent flex-1 sm:flex-none min-w-[140px]"
            >
              <Link href="#features">{t("landing.hero.learnMore")}</Link>
            </Button>
          </div>
        </div>

        <div className="mt-8 sm:mt-12 grid w-full max-w-5xl grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
          <div className="rounded-lg border bg-card p-4 sm:p-6 text-center card-hover animate-scale-in animate-stagger-1">
            <div className="text-2xl sm:text-3xl font-bold text-gradient-animate">10K+</div>
            <div className="text-xs sm:text-sm text-muted-foreground mt-1">{t("landing.stats.activeLeaders")}</div>
          </div>
          <div className="rounded-lg border bg-card p-4 sm:p-6 text-center card-hover animate-scale-in animate-stagger-2">
            <div className="text-2xl sm:text-3xl font-bold text-gradient-animate">50K+</div>
            <div className="text-xs sm:text-sm text-muted-foreground mt-1">{t("landing.stats.forumPosts")}</div>
          </div>
          <div className="rounded-lg border bg-card p-4 sm:p-6 text-center card-hover animate-scale-in animate-stagger-3">
            <div className="text-2xl sm:text-3xl font-bold text-gradient-animate">1M+</div>
            <div className="text-xs sm:text-sm text-muted-foreground mt-1">{t("landing.stats.pointsEarned")}</div>
          </div>
        </div>
      </section>

      <section id="features" className="border-t bg-muted/50 py-12 sm:py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-2xl text-center mb-8 sm:mb-12 lg:mb-16 animate-fade-in-up">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">{t("landing.features.title")}</h2>
            <p className="mt-3 sm:mt-4 text-sm sm:text-base text-muted-foreground">{t("landing.features.subtitle")}</p>
          </div>

          <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 max-w-7xl mx-auto">
            <div className="flex flex-col gap-3 rounded-lg border bg-card p-5 sm:p-6 card-hover animate-fade-in-up animate-stagger-1">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground transition-transform duration-300 hover:scale-110 hover:rotate-6">
                <MessageSquare className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold">{t("landing.features.forum.title")}</h3>
              <p className="text-sm sm:text-base text-muted-foreground">{t("landing.features.forum.description")}</p>
            </div>

            <div className="flex flex-col gap-3 rounded-lg border bg-card p-5 sm:p-6 card-hover animate-fade-in-up animate-stagger-2">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground transition-transform duration-300 hover:scale-110 hover:rotate-6">
                <Lightbulb className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold">Projects & Initiatives</h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                Propose and collaborate on projects with other leaders to drive community impact.
              </p>
            </div>

            <div className="flex flex-col gap-3 rounded-lg border bg-card p-5 sm:p-6 card-hover animate-fade-in-up animate-stagger-3">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground transition-transform duration-300 hover:scale-110 hover:rotate-6">
                <Vote className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold">Democratic Voting</h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                Participate in transparent decision-making through polls and community votes.
              </p>
            </div>

            <div className="flex flex-col gap-3 rounded-lg border bg-card p-5 sm:p-6 card-hover animate-fade-in-up animate-stagger-4">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground transition-transform duration-300 hover:scale-110 hover:rotate-6">
                <Trophy className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold">{t("landing.features.badges.title")}</h3>
              <p className="text-sm sm:text-base text-muted-foreground">{t("landing.features.badges.description")}</p>
            </div>

            <div className="flex flex-col gap-3 rounded-lg border bg-card p-5 sm:p-6 card-hover animate-fade-in-up animate-stagger-1">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground transition-transform duration-300 hover:scale-110 hover:rotate-6">
                <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold">{t("landing.features.rankings.title")}</h3>
              <p className="text-sm sm:text-base text-muted-foreground">{t("landing.features.rankings.description")}</p>
            </div>

            <div className="flex flex-col gap-3 rounded-lg border bg-card p-5 sm:p-6 card-hover animate-fade-in-up animate-stagger-2">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground transition-transform duration-300 hover:scale-110 hover:rotate-6">
                <Zap className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold">{t("landing.features.points.title")}</h3>
              <p className="text-sm sm:text-base text-muted-foreground">{t("landing.features.points.description")}</p>
            </div>

            <div className="flex flex-col gap-3 rounded-lg border bg-card p-5 sm:p-6 card-hover animate-fade-in-up animate-stagger-3">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground transition-transform duration-300 hover:scale-110 hover:rotate-6">
                <Shield className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold">{t("landing.features.secure.title")}</h3>
              <p className="text-sm sm:text-base text-muted-foreground">{t("landing.features.secure.description")}</p>
            </div>

            <div className="flex flex-col gap-3 rounded-lg border bg-card p-5 sm:p-6 card-hover animate-fade-in-up animate-stagger-4">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground transition-transform duration-300 hover:scale-110 hover:rotate-6">
                <Users className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold">{t("landing.features.customize.title")}</h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                {t("landing.features.customize.description")}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="community" className="border-t py-12 sm:py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center space-y-4 sm:space-y-6 animate-fade-in-up">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">{t("landing.cta.title")}</h2>
            <p className="text-base sm:text-lg text-muted-foreground">{t("landing.cta.subtitle")}</p>
            <div className="flex gap-3 sm:gap-4 justify-center flex-wrap pt-2 sm:pt-4">
              <Button asChild size="lg" className="btn-hover flex-1 sm:flex-none min-w-[140px]">
                <Link href="/auth/register">{t("landing.cta.createAccount")}</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="btn-hover bg-transparent flex-1 sm:flex-none min-w-[140px]"
              >
                <Link href="/auth/login">{t("nav.signIn")}</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t mt-auto">
        <div className="container mx-auto py-6 sm:py-8 px-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4 text-center sm:text-left">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              <span className="font-bold">LeaderNexus</span>
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground">{t("landing.footer.copyright")}</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
