"use client"

import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { MessageSquare, ThumbsUp, Plus, Filter } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useTranslations } from "@/lib/i18n/use-translations"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import type { Profile } from "@/lib/types"

interface Post {
  id: string
  title: string
  content: string
  category: string
  created_at: string
  comments_count: number
  likes: number
  author?: {
    id: string
    username: string
    avatar_url?: string
  }
}

export default function ForumPage() {
  const { t } = useTranslations()
  const router = useRouter()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      setProfile(userProfile)

      const { data: forumPosts } = await supabase
        .from("posts")
        .select("*, author:profiles(id, username, avatar_url)")
        .order("created_at", { ascending: false })

      setPosts(forumPosts || [])
      setLoading(false)
    }

    loadData()
  }, [router])

  const categories = ["general", "leadership", "technology", "discussion", "help", "announcements"]

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">{t("common.loading")}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-forum-bg">
      <DashboardNav user={profile} />

      <main className="container py-6 sm:py-8 px-4">
        <div className="space-y-4 sm:space-y-6">
          <div className="rounded-xl p-6 sm:p-8 bg-forum-card border-2 border-forum-border">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-xl bg-forum-accent">
                <MessageSquare className="h-6 w-6 sm:h-7 sm:w-7 text-white" />
              </div>
              <div className="flex-1">
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{t("forum.title")}</h1>
                <p className="text-sm sm:text-base text-muted-foreground mt-1">{t("forum.subtitle")}</p>
              </div>
            </div>
            <Button
              asChild
              className="w-full sm:w-auto min-h-[44px] bg-forum-accent text-forum-accent-foreground hover:bg-forum-accent/90"
            >
              <Link href="/forum/new">
                <Plus className="mr-2 h-4 w-4" />
                {t("forum.newPost")}
              </Link>
            </Button>
          </div>

          <Card className="bg-forum-card border-forum-border">
            <CardContent className="pt-4 sm:pt-6">
              <div className="flex items-start gap-2 flex-wrap">
                <Filter className="h-4 w-4 text-muted-foreground mt-1.5" />
                <span className="text-sm text-muted-foreground mt-1">{t("forum.categories")}</span>
                <div className="flex gap-2 flex-wrap">
                  <Badge
                    variant="secondary"
                    className="cursor-pointer min-h-[32px] bg-forum-accent text-forum-accent-foreground"
                  >
                    {t("forum.allCategories")}
                  </Badge>
                  {categories.map((cat) => (
                    <Badge key={cat} variant="outline" className="cursor-pointer min-h-[32px] border-forum-border">
                      {cat}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3 sm:space-y-4">
            {posts && posts.length > 0 ? (
              posts.map((post) => (
                <Card key={post.id} className="hover:shadow-lg transition-all bg-forum-card border-forum-border">
                  <CardContent className="pt-4 sm:pt-6">
                    <div className="flex gap-3 sm:gap-4">
                      <Avatar className="h-8 w-8 sm:h-10 sm:w-10 flex-shrink-0">
                        <AvatarImage src={post.author?.avatar_url || ""} />
                        <AvatarFallback>{post.author?.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                      </Avatar>

                      <div className="flex-1 space-y-2 sm:space-y-3 min-w-0">
                        <div className="space-y-1">
                          <Link href={`/forum/post/${post.id}`} className="group">
                            <h3 className="text-base sm:text-lg font-semibold group-hover:text-forum-accent transition-colors break-words">
                              {post.title}
                            </h3>
                          </Link>
                          <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground flex-wrap">
                            <span className="truncate max-w-[120px] sm:max-w-none">{post.author?.username}</span>
                            <span>•</span>
                            <span className="whitespace-nowrap">{new Date(post.created_at).toLocaleDateString()}</span>
                            <span>•</span>
                            <Badge variant="secondary" className="text-xs bg-forum-accent/10 text-forum-accent">
                              {post.category}
                            </Badge>
                          </div>
                        </div>

                        <p className="text-sm sm:text-base text-muted-foreground line-clamp-2 break-words">
                          {post.content}
                        </p>

                        <div className="flex items-center gap-4 sm:gap-6 text-xs sm:text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <MessageSquare className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                            <span>{post.comments_count || 0}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <ThumbsUp className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                            <span>{post.likes || 0}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="bg-forum-card border-forum-border">
                <CardContent className="py-12 text-center">
                  <MessageSquare className="h-10 w-10 sm:h-12 sm:w-12 mx-auto mb-3 sm:mb-4 text-muted-foreground opacity-50" />
                  <h3 className="text-base sm:text-lg font-semibold mb-2">{t("forum.noPosts")}</h3>
                  <p className="text-sm sm:text-base text-muted-foreground mb-4">{t("forum.firstPost")}</p>
                  <Button
                    asChild
                    className="min-h-[44px] bg-forum-accent text-forum-accent-foreground hover:bg-forum-accent/90"
                  >
                    <Link href="/forum/new">{t("forum.newPost")}</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
