import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import PostActions from "@/components/forum/post-actions"
import CommentSection from "@/components/forum/comment-section"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

interface PostPageProps {
  params: Promise<{ id: string }>
}

export default async function PostPage({ params }: PostPageProps) {
  const { id } = await params

  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: post, error } = await supabase
    .from("posts")
    .select("*, author:profiles!posts_author_id_fkey(id, username, full_name, avatar_url)")
    .eq("id", id)
    .single()

  if (error || !post) {
    return (
      <div className="min-h-screen bg-background">
        <DashboardNav user={profile} />
        <main className="container py-8">
          <div className="max-w-4xl mx-auto">
            <Card>
              <CardContent className="py-12 text-center">
                <h2 className="text-2xl font-bold mb-2">Post topilmadi</h2>
                <p className="text-muted-foreground mb-6">Bu post mavjud emas yoki o'chirilgan bo'lishi mumkin.</p>
                <Button asChild>
                  <Link href="/forum">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Forumga qaytish
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  // Check if user liked this post
  const { data: userLike } = await supabase
    .from("post_likes")
    .select("*")
    .eq("post_id", post.id)
    .eq("user_id", user.id)
    .maybeSingle()

  // Fetch comments
  const { data: comments } = await supabase
    .from("comments")
    .select("*, author:profiles!comments_author_id_fkey(id, username, full_name, avatar_url)")
    .eq("post_id", post.id)
    .is("parent_id", null)
    .order("created_at", { ascending: true })

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <Button asChild variant="ghost" className="mb-4">
            <Link href="/forum">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Forumga qaytish
            </Link>
          </Button>

          {/* Post Card */}
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-6">
                {/* Post Header */}
                <div className="flex items-start gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={post.author?.avatar_url || ""} />
                    <AvatarFallback>{post.author?.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{post.author?.full_name || post.author?.username}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {post.category}
                      </Badge>
                      {post.is_solved && (
                        <Badge variant="default" className="bg-accent text-accent-foreground text-xs">
                          Solved
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{new Date(post.created_at).toLocaleString()}</p>
                  </div>
                </div>

                {/* Post Content */}
                <div className="space-y-3">
                  <h1 className="text-2xl font-bold">{post.title}</h1>
                  <div className="prose prose-sm max-w-none">
                    <p className="whitespace-pre-wrap text-foreground">{post.content}</p>
                  </div>
                </div>

                {/* Post Actions */}
                <PostActions post={post} userId={user.id} hasLiked={!!userLike} />
              </div>
            </CardContent>
          </Card>

          {/* Comments Section */}
          <CommentSection postId={post.id} userId={user.id} comments={comments || []} />
        </div>
      </main>
    </div>
  )
}
