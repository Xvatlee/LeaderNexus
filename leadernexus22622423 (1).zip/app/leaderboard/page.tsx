"use client"

import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Trophy, Crown, Medal, Award } from "lucide-react"
import { useTranslations } from "@/lib/i18n/use-translations"
import { useEffect, useState } from "react"
import type { Profile } from "@/lib/types"

interface LeaderboardEntry extends Profile {
  rank: number
  achievement_count: number
}

export default function LeaderboardPage() {
  const { t } = useTranslations()
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        redirect("/auth/login")
        return
      }

      setUser(authUser)

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", authUser.id).maybeSingle()

      setProfile(userProfile)

      const { data: leaderboardData } = await supabase
        .from("profiles")
        .select("id, username, avatar_url, points, created_at, role")
        .order("points", { ascending: false })
        .limit(50)

      // Get achievement counts for each user
      const leaderboardWithAchievements = await Promise.all(
        (leaderboardData || []).map(async (user, index) => {
          const { count } = await supabase
            .from("user_achievements")
            .select("*", { count: "exact", head: true })
            .eq("user_id", user.id)

          return {
            ...user,
            rank: index + 1,
            achievement_count: count || 0,
          }
        }),
      )

      setLeaderboard(leaderboardWithAchievements)
      setLoading(false)
    }

    loadData()
  }, [])

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="h-5 w-5 text-yellow-500" />
    if (rank === 2) return <Medal className="h-5 w-5 text-gray-400" />
    if (rank === 3) return <Medal className="h-5 w-5 text-amber-600" />
    return <span className="text-muted-foreground font-semibold">#{rank}</span>
  }

  const currentUserRank = leaderboard.findIndex((u) => u.id === user?.id) + 1

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">{t("common.loading")}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          {/* Header */}
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold tracking-tight">{t("leaderboard.title")}</h1>
            <p className="text-muted-foreground">{t("leaderboard.subtitle")}</p>
          </div>

          {/* Current User Rank */}
          {currentUserRank > 0 && (
            <Card className="border-accent">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-accent/10">
                    {getRankIcon(currentUserRank)}
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold">{t("leaderboard.yourRank")}</div>
                    <div className="text-sm text-muted-foreground">
                      {t("leaderboard.yourRankDesc", { rank: currentUserRank, points: profile?.points || 0 })}
                    </div>
                  </div>
                  <Trophy className="h-8 w-8 text-accent" />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle>{t("leaderboard.topLeaders")}</CardTitle>
              <CardDescription>{t("leaderboard.basedOnPoints")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leaderboard.map((leader) => (
                  <div
                    key={leader.id}
                    className={`flex items-center gap-4 p-4 rounded-lg border ${
                      leader.id === user?.id ? "bg-accent/5 border-accent" : ""
                    }`}
                  >
                    <div className="flex items-center justify-center w-12 h-12">{getRankIcon(leader.rank)}</div>

                    <Avatar className="h-12 w-12">
                      <AvatarImage src={leader.avatar_url || ""} />
                      <AvatarFallback>{leader.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="font-semibold">{leader.username}</div>
                      <div className="text-sm text-muted-foreground">@{leader.username}</div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <div className="flex items-center gap-1 font-semibold">
                          <Trophy className="h-4 w-4 text-accent" />
                          <span>{leader.points}</span>
                        </div>
                        <div className="text-xs text-muted-foreground">{t("leaderboard.points")}</div>
                      </div>

                      <div className="text-right">
                        <div className="flex items-center gap-1 font-semibold">
                          <Award className="h-4 w-4 text-accent" />
                          <span>{leader.achievement_count}</span>
                        </div>
                        <div className="text-xs text-muted-foreground">{t("leaderboard.badges")}</div>
                      </div>
                    </div>

                    {leader.id === user?.id && (
                      <Badge variant="default" className="bg-accent">
                        {t("leaderboard.you")}
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Point System Info */}
          <Card>
            <CardHeader>
              <CardTitle>{t("leaderboard.howToEarn")}</CardTitle>
              <CardDescription>{t("leaderboard.howToEarnDesc")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                    <Trophy className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <div className="font-medium">{t("leaderboard.createPost")}</div>
                    <div className="text-sm text-muted-foreground">{t("leaderboard.createPostDesc")}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                    <Trophy className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <div className="font-medium">{t("leaderboard.addComment")}</div>
                    <div className="text-sm text-muted-foreground">{t("leaderboard.addCommentDesc")}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                    <Trophy className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <div className="font-medium">{t("leaderboard.receiveUpvote")}</div>
                    <div className="text-sm text-muted-foreground">{t("leaderboard.receiveUpvoteDesc")}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                    <Trophy className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <div className="font-medium">{t("leaderboard.markSolved")}</div>
                    <div className="text-sm text-muted-foreground">{t("leaderboard.markSolvedDesc")}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
