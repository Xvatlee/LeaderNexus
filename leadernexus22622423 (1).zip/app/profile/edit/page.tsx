import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import ProfileEditForm from "@/components/profile/profile-edit-form"

export default async function EditProfilePage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container mx-auto max-w-4xl py-6 sm:py-8 px-4">
        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Edit Profile</h1>
          <p className="text-muted-foreground mt-2 text-sm sm:text-base">
            Update your personal information and preferences
          </p>
        </div>

        <ProfileEditForm profile={profile} />
      </main>
    </div>
  )
}
