"use client"

import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { Trophy, Calendar, Edit, Award, TrendingUp } from "lucide-react"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { useEffect, useState } from "react"
import type { Profile } from "@/lib/types"
import { AnimatedCounter } from "@/components/stats/animated-counter"
import { CircularProgress } from "@/components/stats/circular-progress"
import { ActivityHeatmap } from "@/components/stats/activity-heatmap"

interface UserAchievement {
  id: string
  unlocked_at: string
  achievement?: {
    name: string
    description: string
  }
}

interface Post {
  id: string
  title: string
  created_at: string
  comments_count: number
  likes_count: number
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([])
  const [userPosts, setUserPosts] = useState<Post[]>([])
  const [userRank, setUserRank] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()
      setProfile(userProfile)

      const { data: achievements } = await supabase
        .from("user_achievements")
        .select("*, achievement:achievements(*)")
        .eq("user_id", user.id)
        .order("unlocked_at", { ascending: false })
      setUserAchievements(achievements || [])

      const { data: posts } = await supabase
        .from("posts")
        .select("*")
        .eq("author_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10)
      setUserPosts(posts || [])

      try {
        const { data: allProfiles } = await supabase
          .from("profiles")
          .select("points")
          .order("points", { ascending: false })
        const rank = allProfiles ? allProfiles.findIndex((p) => p.points === userProfile?.points) + 1 : 0
        setUserRank(rank)
      } catch (error) {
        console.log("[v0] Error fetching rank:", error)
        setUserRank(0)
      }

      setLoading(false)
    }

    loadData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Profile Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col items-center text-center space-y-4">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={profile?.avatar_url || ""} />
                    <AvatarFallback className="text-2xl">
                      {profile?.username?.charAt(0).toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="space-y-1">
                    <CardTitle>{profile?.full_name || profile?.username}</CardTitle>
                    <CardDescription>@{profile?.username}</CardDescription>
                  </div>
                  <Badge variant="secondary">{profile?.role === "admin" ? "Admin" : "Leader"}</Badge>
                  <Button asChild className="w-full bg-transparent" variant="outline">
                    <Link href="/profile/edit">
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Profile
                    </Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      Joined {new Date(profile?.created_at || "").toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up">
              <CardHeader>
                <CardTitle>Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total Points</span>
                  <div className="flex items-center gap-1 font-semibold">
                    <Trophy className="h-4 w-4 text-accent" />
                    <AnimatedCounter value={profile?.points || 0} />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Rank</span>
                  <div className="flex items-center gap-1 font-semibold">
                    <TrendingUp className="h-4 w-4 text-accent" />
                    <span>#{userRank}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Posts</span>
                  <AnimatedCounter value={userPosts?.length || 0} className="font-semibold" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Achievements</span>
                  <AnimatedCounter value={userAchievements?.length || 0} className="font-semibold" />
                </div>
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up animate-stagger-2">
              <CardHeader>
                <CardTitle>Achievement Progress</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                <CircularProgress value={userAchievements?.length || 0} max={50} size={140} />
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <ActivityHeatmap
              data={Array.from({ length: 84 }).map((_, i) => ({
                date: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toLocaleDateString(),
                count: Math.floor(Math.random() * 10),
              }))}
              title="Activity History"
              description="Your contributions over the last 12 weeks"
            />

            <Card>
              <CardHeader>
                <CardTitle>Achievements</CardTitle>
                <CardDescription>Your earned badges and milestones</CardDescription>
              </CardHeader>
              <CardContent>
                {userAchievements && userAchievements.length > 0 ? (
                  <div className="grid gap-4 md:grid-cols-2">
                    {userAchievements.map((ua) => (
                      <div key={ua.id} className="flex items-start gap-3 rounded-lg border p-4">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-accent/10">
                          <Award className="h-6 w-6 text-accent" />
                        </div>
                        <div className="space-y-1">
                          <div className="font-semibold">{ua.achievement?.name}</div>
                          <div className="text-sm text-muted-foreground">{ua.achievement?.description}</div>
                          <div className="text-xs text-muted-foreground">
                            Earned {new Date(ua.unlocked_at).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <Award className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No achievements yet. Keep contributing to earn badges!</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Your Recent Posts</CardTitle>
                <CardDescription>Posts you've created</CardDescription>
              </CardHeader>
              <CardContent>
                {userPosts && userPosts.length > 0 ? (
                  <div className="space-y-4">
                    {userPosts.map((post) => (
                      <div key={post.id} className="border-b pb-4 last:border-0">
                        <Link href={`/forum/post/${post.id}`} className="group space-y-2 block">
                          <div className="font-medium group-hover:underline">{post.title}</div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>{new Date(post.created_at).toLocaleDateString()}</span>
                            <span>•</span>
                            <span>{post.comments_count} comments</span>
                            <span>•</span>
                            <span>{post.likes_count} likes</span>
                          </div>
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <p className="mb-4">You haven't created any posts yet.</p>
                    <Button asChild>
                      <Link href="/forum/new">Create Your First Post</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
