import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { Plus, Users, Calendar, MapPin, TrendingUp, Lightbulb } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default async function ProjectsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Fetch all active projects
  const { data: allProjects } = await supabase
    .from("projects")
    .select(
      `
      *,
      leader:profiles!projects_leader_id_fkey(id, username, full_name, avatar_url),
      collaborators:project_collaborators(count)
    `,
    )
    .eq("status", "active")
    .order("created_at", { ascending: false })

  // Fetch user's own projects
  const { data: myProjects } = await supabase
    .from("projects")
    .select(
      `
      *,
      collaborators:project_collaborators(count)
    `,
    )
    .eq("leader_id", user.id)
    .order("created_at", { ascending: false })

  // Fetch projects user is collaborating on
  const { data: collaboratingProjects } = await supabase
    .from("project_collaborators")
    .select(
      `
      *,
      project:projects(
        *,
        leader:profiles!projects_leader_id_fkey(id, username, full_name, avatar_url)
      )
    `,
    )
    .eq("user_id", user.id)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/10 text-green-500"
      case "draft":
        return "bg-gray-500/10 text-gray-500"
      case "completed":
        return "bg-blue-500/10 text-blue-500"
      case "cancelled":
        return "bg-red-500/10 text-red-500"
      default:
        return "bg-gray-500/10 text-gray-500"
    }
  }

  const ProjectCard = ({ project, showLeader = true }: any) => (
    <Card className="flex flex-col bg-projects-card border-projects-border card-hover">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <CardTitle className="text-xl">{project.title}</CardTitle>
            {project.category && (
              <Badge variant="outline" className="text-xs">
                {project.category}
              </Badge>
            )}
          </div>
          <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
        </div>
        <CardDescription className="line-clamp-2">{project.description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="space-y-3">
          {showLeader && project.leader && (
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={project.leader.avatar_url || ""} />
                <AvatarFallback>{project.leader.username?.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <span className="text-sm text-muted-foreground">
                Led by {project.leader.full_name || project.leader.username}
              </span>
            </div>
          )}
          <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
            {project.target_region && (
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4 icon-hover" />
                <span>{project.target_region}</span>
              </div>
            )}
            {project.start_date && (
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4 icon-hover" />
                <span>{new Date(project.start_date).toLocaleDateString()}</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4 icon-hover" />
              <span>{project.collaborators?.[0]?.count || 0} collaborators</span>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full btn-hover bg-projects-accent hover:bg-projects-accent/90 focus-visible-ring">
          <Link href={`/projects/${project.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  )

  return (
    <div className="min-h-screen bg-projects-bg">
      <DashboardNav user={profile} />

      <main className="container py-8 px-4">
        <div className="space-y-8">
          <div className="rounded-xl p-6 sm:p-8 bg-projects-card border-2 border-projects-border animate-fade-in-up">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-xl bg-projects-accent transition-transform duration-300 hover:scale-110 hover:rotate-6">
                  <Lightbulb className="h-6 w-6 sm:h-7 sm:w-7 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Projects & Initiatives</h1>
                  <p className="text-sm sm:text-base text-muted-foreground mt-1">
                    Collaborate with leaders on projects and propose new initiatives
                  </p>
                </div>
              </div>
              <Button
                asChild
                className="w-full sm:w-auto bg-projects-accent text-projects-accent-foreground hover:bg-projects-accent/90 btn-hover focus-visible-ring"
              >
                <Link href="/projects/new">
                  <Plus className="mr-2 h-4 w-4" />
                  New Project
                </Link>
              </Button>
            </div>
          </div>

          <Tabs defaultValue="all" className="space-y-6 animate-fade-in-up animate-stagger-2">
            <TabsList>
              <TabsTrigger value="all">All Projects</TabsTrigger>
              <TabsTrigger value="my-projects">My Projects ({myProjects?.length || 0})</TabsTrigger>
              <TabsTrigger value="collaborating">Collaborating ({collaboratingProjects?.length || 0})</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6">
              {!allProjects || allProjects.length === 0 ? (
                <Card className="bg-projects-card border-projects-border">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No projects yet</h3>
                    <p className="text-sm text-muted-foreground mb-4">Be the first to create a project!</p>
                    <Button
                      asChild
                      className="bg-projects-accent text-projects-accent-foreground hover:bg-projects-accent/90"
                    >
                      <Link href="/projects/new">Create Project</Link>
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {allProjects.map((project) => (
                    <ProjectCard key={project.id} project={project} />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="my-projects" className="space-y-6">
              {!myProjects || myProjects.length === 0 ? (
                <Card className="bg-projects-card border-projects-border">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No projects created yet</h3>
                    <p className="text-sm text-muted-foreground mb-4">Start your first initiative!</p>
                    <Button
                      asChild
                      className="bg-projects-accent text-projects-accent-foreground hover:bg-projects-accent/90"
                    >
                      <Link href="/projects/new">Create Project</Link>
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {myProjects.map((project) => (
                    <ProjectCard key={project.id} project={project} showLeader={false} />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="collaborating" className="space-y-6">
              {!collaboratingProjects || collaboratingProjects.length === 0 ? (
                <Card className="bg-projects-card border-projects-border">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <Users className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Not collaborating on any projects</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Join a project to collaborate with other leaders
                    </p>
                    <Button asChild variant="outline" className="border-projects-border bg-transparent">
                      <Link href="/projects?tab=all">Browse Projects</Link>
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {collaboratingProjects.map((collab: any) => (
                    <ProjectCard key={collab.project.id} project={collab.project} />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
