import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import ProjectDetail from "@/components/projects/project-detail"
import { notFound } from "next/navigation"

export default async function ProjectDetailPage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Fetch project with leader info
  const { data: project, error } = await supabase
    .from("projects")
    .select(
      `
      *,
      leader:profiles!projects_leader_id_fkey(id, username, full_name, avatar_url, role)
    `,
    )
    .eq("id", params.id)
    .single()

  if (error || !project) {
    notFound()
  }

  // Fetch collaborators
  const { data: collaborators } = await supabase
    .from("project_collaborators")
    .select(
      `
      *,
      user:profiles(id, username, full_name, avatar_url)
    `,
    )
    .eq("project_id", params.id)

  // Fetch project updates
  const { data: updates } = await supabase
    .from("project_updates")
    .select(
      `
      *,
      author:profiles(id, username, full_name, avatar_url)
    `,
    )
    .eq("project_id", params.id)
    .order("created_at", { ascending: false })

  // Fetch project comments
  const { data: comments } = await supabase
    .from("project_comments")
    .select(
      `
      *,
      author:profiles(id, username, full_name, avatar_url)
    `,
    )
    .eq("project_id", params.id)
    .is("parent_id", null)
    .order("created_at", { ascending: false })

  // Check if user is collaborator
  const isCollaborator = collaborators?.some((c: any) => c.user_id === user.id)
  const isOwner = project.leader_id === user.id

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <ProjectDetail
          project={project}
          collaborators={collaborators || []}
          updates={updates || []}
          comments={comments || []}
          currentUserId={user.id}
          isCollaborator={isCollaborator || false}
          isOwner={isOwner}
        />
      </main>
    </div>
  )
}
