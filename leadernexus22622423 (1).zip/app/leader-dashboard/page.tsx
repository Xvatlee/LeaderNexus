"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart3, TrendingUp, Users, Target, Calendar, CheckCircle2, Clock, Activity, Award } from "lucide-react"
import Link from "next/link"
import type { Profile } from "@/lib/types"
import { AdminRequestCard } from "@/components/admin/admin-request-card"
import { useTranslations } from "@/lib/i18n/use-translations"

interface LeaderKPI {
  period_type: string
  period_start: string
  period_end: string
  projects_count: number
  tasks_completed: number
  active_members: number
  engagement_score: number
  impact_score: number
  performance_rating: string
}

export default function LeaderDashboardPage() {
  const { t } = useTranslations()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [weeklyKPI, setWeeklyKPI] = useState<LeaderKPI | null>(null)
  const [monthlyKPI, setMonthlyKPI] = useState<LeaderKPI | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      if (!userProfile || (userProfile.role !== "leader" && userProfile.role !== "admin")) {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      // Get latest weekly KPI
      const { data: weeklyData } = await supabase
        .from("leader_kpis")
        .select("*")
        .eq("leader_id", user.id)
        .eq("period_type", "weekly")
        .order("period_start", { ascending: false })
        .limit(1)
        .maybeSingle()

      setWeeklyKPI(weeklyData)

      // Get latest monthly KPI
      const { data: monthlyData } = await supabase
        .from("leader_kpis")
        .select("*")
        .eq("leader_id", user.id)
        .eq("period_type", "monthly")
        .order("period_start", { ascending: false })
        .limit(1)
        .maybeSingle()

      setMonthlyKPI(monthlyData)

      setLoading(false)
    }

    loadData()
  }, [])

  const getRatingColor = (rating: string) => {
    switch (rating) {
      case "excellent":
        return "bg-green-500"
      case "good":
        return "bg-blue-500"
      case "average":
        return "bg-yellow-500"
      case "needs_improvement":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">{t("common.loading")}</div>
        </div>
      </div>
    )
  }

  const displayKPI = monthlyKPI || weeklyKPI

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          {/* Admin Request Card */}
          <AdminRequestCard />

          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold tracking-tight">{t("leaderDashboard.title")}</h1>
              <p className="text-muted-foreground mt-2">{t("leaderDashboard.subtitle")}</p>
            </div>
            <Button asChild>
              <Link href="/plans">
                <Calendar className="h-4 w-4 mr-2" />
                {t("leaderDashboard.managePlans")}
              </Link>
            </Button>
          </div>

          {/* KPI Overview */}
          {displayKPI && (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t("leaderDashboard.projects")}</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{displayKPI.projects_count}</div>
                  <p className="text-xs text-muted-foreground">{t("leaderDashboard.projectsDesc")}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t("leaderDashboard.tasksCompleted")}</CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{displayKPI.tasks_completed}</div>
                  <p className="text-xs text-muted-foreground">{t("leaderDashboard.tasksCompletedDesc")}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t("leaderDashboard.activeMembers")}</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{displayKPI.active_members}</div>
                  <p className="text-xs text-muted-foreground">{t("leaderDashboard.activeMembersDesc")}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t("leaderDashboard.performance")}</CardTitle>
                  <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <Badge className={getRatingColor(displayKPI.performance_rating)}>
                    {displayKPI.performance_rating?.replace("_", " ")}
                  </Badge>
                  <p className="text-xs text-muted-foreground mt-2">{t("leaderDashboard.performanceDesc")}</p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Detailed Metrics */}
          <Tabs defaultValue="weekly" className="space-y-4">
            <TabsList>
              <TabsTrigger value="weekly">{t("leaderDashboard.weekly")}</TabsTrigger>
              <TabsTrigger value="monthly">{t("leaderDashboard.monthly")}</TabsTrigger>
            </TabsList>

            <TabsContent value="weekly">
              {weeklyKPI ? (
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("leaderDashboard.engagementScore")}</CardTitle>
                      <CardDescription>{t("leaderDashboard.weekOf")} {new Date(weeklyKPI.period_start).toLocaleDateString()}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-3xl font-bold">{weeklyKPI.engagement_score.toFixed(1)}</span>
                          <TrendingUp className="h-6 w-6 text-accent" />
                        </div>
                        <div className="text-sm text-muted-foreground">{t("leaderDashboard.outOf100")}</div>
                        <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full bg-accent transition-all"
                            style={{ width: `${weeklyKPI.engagement_score}%` }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>{t("leaderDashboard.impactScore")}</CardTitle>
                      <CardDescription>{t("leaderDashboard.weekOf")} {new Date(weeklyKPI.period_start).toLocaleDateString()}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-3xl font-bold">{weeklyKPI.impact_score.toFixed(1)}</span>
                          <Award className="h-6 w-6 text-accent" />
                        </div>
                        <div className="text-sm text-muted-foreground">{t("leaderDashboard.outOf100")}</div>
                        <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full bg-accent transition-all"
                            style={{ width: `${weeklyKPI.impact_score}%` }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card>
                  <CardContent className="py-12 text-center text-muted-foreground">
                    <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>{t("leaderDashboard.noWeeklyKPI")}</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="monthly">
              {monthlyKPI ? (
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("leaderDashboard.engagementScore")}</CardTitle>
                      <CardDescription>
                        {t("leaderDashboard.monthOf")} {new Date(monthlyKPI.period_start).toLocaleDateString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-3xl font-bold">{monthlyKPI.engagement_score.toFixed(1)}</span>
                          <TrendingUp className="h-6 w-6 text-accent" />
                        </div>
                        <div className="text-sm text-muted-foreground">{t("leaderDashboard.outOf100")}</div>
                        <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full bg-accent transition-all"
                            style={{ width: `${monthlyKPI.engagement_score}%` }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>{t("leaderDashboard.impactScore")}</CardTitle>
                      <CardDescription>
                        {t("leaderDashboard.monthOf")} {new Date(monthlyKPI.period_start).toLocaleDateString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-3xl font-bold">{monthlyKPI.impact_score.toFixed(1)}</span>
                          <Award className="h-6 w-6 text-accent" />
                        </div>
                        <div className="text-sm text-muted-foreground">{t("leaderDashboard.outOf100")}</div>
                        <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full bg-accent transition-all"
                            style={{ width: `${monthlyKPI.impact_score}%` }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card>
                  <CardContent className="py-12 text-center text-muted-foreground">
                    <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>{t("leaderDashboard.noMonthlyKPI")}</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>

          {/* Quick Links */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>{t("leaderDashboard.trainingHub")}</CardTitle>
                <CardDescription>{t("leaderDashboard.trainingHubDesc")}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild className="w-full">
                  <Link href="/leader-hub">
                    <BarChart3 className="h-4 w-4 mr-2" />
                    {t("leaderDashboard.viewResources")}
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t("leaderDashboard.performanceTitle")}</CardTitle>
                <CardDescription>{t("leaderDashboard.performanceDescShort")}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild className="w-full">
                  <Link href="/leader-performance">
                    <Award className="h-4 w-4 mr-2" />
                    {t("leaderDashboard.seeRankings")}
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t("leaderDashboard.plansTitle")}</CardTitle>
                <CardDescription>{t("leaderDashboard.plansDesc")}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild className="w-full">
                  <Link href="/plans">
                    <Target className="h-4 w-4 mr-2" />
                    {t("leaderDashboard.viewPlans")}
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
