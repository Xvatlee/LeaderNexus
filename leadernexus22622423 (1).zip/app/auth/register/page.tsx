"use client"

import type React from "react"
import "@/lib/unicode-polyfill"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { Users, AlertCircle, CheckCircle2, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface District {
  id: string
  name: string
  region: string
}

interface Direction {
  id: string
  name: string
  description: string
}

export default function RegisterPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [username, setUsername] = useState("")
  const [fullName, setFullName] = useState("")
  const [role, setRole] = useState<"leader">("leader")
  const [district, setDistrict] = useState("")
  const [districtId, setDistrictId] = useState("")
  const [direction, setDirection] = useState("")
  const [directionId, setDirectionId] = useState("")
  const [districts, setDistricts] = useState<District[]>([])
  const [directions, setDirections] = useState<Direction[]>([])
  const [dataLoadError, setDataLoadError] = useState<string | null>(null)
  const [directionAvailability, setDirectionAvailability] = useState<{
    available: boolean
    message?: string
  } | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isCheckingAvailability, setIsCheckingAvailability] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
        const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

        if (!supabaseUrl || !supabaseAnonKey) {
          setDataLoadError(
            "Supabase is not configured. Please add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY environment variables.",
          )
          return
        }

        const supabase = createClient()

        const [districtsResult, directionsResult] = await Promise.all([
          supabase
            .from("districts")
            .select("id, name, region")
            .eq("is_active", true)
            .eq("region", "Surxondaryo")
            .order("name"),
          supabase.from("directions").select("id, name, description").eq("is_active", true).order("name"),
        ])

        if (districtsResult.error) {
          setDataLoadError("Could not load districts. Please check database connection.")
          return
        }

        if (directionsResult.error) {
          setDataLoadError("Could not load directions. Please check database connection.")
          return
        }

        if (districtsResult.data) {
          setDistricts(districtsResult.data)
        }
        if (directionsResult.data) {
          setDirections(directionsResult.data)
        }

        if (districtsResult.data?.length === 0 || directionsResult.data?.length === 0) {
          setDataLoadError("No districts or directions found. Please run the database seed scripts first.")
        }
      } catch (err) {
        setDataLoadError("An unexpected error occurred while loading data.")
      }
    }

    fetchOptions()
  }, [])

  const handleDistrictChange = (value: string) => {
    const selectedDistrict = districts.find((d) => d.id === value)
    if (selectedDistrict) {
      setDistrictId(selectedDistrict.id)
      setDistrict(selectedDistrict.name)
    }
  }

  const handleDirectionChange = (value: string) => {
    const selectedDirection = directions.find((d) => d.id === value)
    if (selectedDirection) {
      setDirectionId(selectedDirection.id)
      setDirection(selectedDirection.name)
    }
  }

  useEffect(() => {
    const checkAvailability = async () => {
      if (!district || !direction) {
        setDirectionAvailability(null)
        return
      }

      setIsCheckingAvailability(true)
      try {
        const response = await fetch("/api/check-direction-availability", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ district, direction }),
        })

        const data = await response.json()
        setDirectionAvailability(data)
      } catch (error) {
        console.error("Error checking availability:", error)
      } finally {
        setIsCheckingAvailability(false)
      }
    }

    checkAvailability()
  }, [district, direction])

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    if (password !== confirmPassword) {
      setError("Parollar mos kelmadi")
      setIsLoading(false)
      return
    }

    if (password.length < 6) {
      setError("Parol kamida 6 ta belgidan iborat bo'lishi kerak")
      setIsLoading(false)
      return
    }

    if (!district || !direction) {
      setError("Tuman va yo'nalishni tanlang")
      setIsLoading(false)
      return
    }

    if (directionAvailability && !directionAvailability.available) {
      setError(directionAvailability.message || "Bu yo'nalish allaqachon band qilingan")
      setIsLoading(false)
      return
    }

    try {
      // Store ASCII-safe IDs in user metadata, names will be stored in profiles table
      const metadata: Record<string, string | null> = {
        username: username || null,
        full_name: fullName || null,
        role: role || null,
        district_id: districtId || null,
        direction_id: directionId || null,
        // Store transliterated versions for display (ASCII-safe)
        district_name: district ? encodeURIComponent(district) : null,
        direction_name: direction ? encodeURIComponent(direction) : null,
      }

      const { data: signupData, error: signupError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/dashboard`,
          data: metadata,
        },
      })

      if (signupError) {
        throw signupError
      }

      if (signupData.user) {
        const { error: profileError } = await supabase
          .from("profiles")
          .update({
            district: district,
            direction: direction,
            district_id: districtId,
            direction_id: directionId,
          })
          .eq("id", signupData.user.id)

        if (profileError) {
          console.error("Profile update error:", profileError)
          // Don't throw - signup was successful, profile will be updated on first login
        }
      }

      router.push("/auth/check-email")
    } catch (error: unknown) {
      console.error("Registration error:", error)
      setError(error instanceof Error ? error.message : "Xatolik yuz berdi")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full">
      <div className="hidden lg:flex lg:w-1/2 bg-primary text-primary-foreground p-12 flex-col justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-8 w-8" />
          <span className="text-2xl font-bold">LeaderNexus</span>
        </div>

        <div className="space-y-6">
          <h1 className="text-5xl font-bold leading-tight text-balance">
            Surxondaryo Bolalar harakatiga xush kelibsiz
          </h1>
          <p className="text-lg text-primary-foreground/80 leading-relaxed">
            14 ta tuman bo'yicha tashkil etilgan 9 ta yo'nalish sardorlarini birlashtiruvchi platforma. Ro'yxatdan
            o'ting va o'z tumaningiz hamda yo'nalishingizni tanlang.
          </p>

          <div className="space-y-4 pt-8">
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                1
              </div>
              <div>
                <div className="font-semibold">Tuman va yo'nalishni tanlang</div>
                <div className="text-sm text-primary-foreground/70">14 ta tumanlar va 9 ta yo'nalishlar mavjud</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                2
              </div>
              <div>
                <div className="font-semibold">Faoliyat olib boring</div>
                <div className="text-sm text-primary-foreground/70">Loyihalar, tadbirlar va muhokamalar</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                3
              </div>
              <div>
                <div className="font-semibold">Hamkorlikda ishlang</div>
                <div className="text-sm text-primary-foreground/70">Boshqa sardorlar bilan bog'laning</div>
              </div>
            </div>
          </div>
        </div>

        <p className="text-sm text-primary-foreground/60">
          © 2025 Surxondaryo Bolalar harakati. Kelajak yetakchilarini tarbiyalaymiz.
        </p>
      </div>

      <div className="flex w-full lg:w-1/2 items-center justify-center p-4 sm:p-6 md:p-10">
        <div className="w-full max-w-md mx-auto">
          <div className="lg:hidden mb-6 sm:mb-8 flex items-center gap-2 justify-center">
            <Users className="h-6 w-6" />
            <span className="text-xl font-bold">LeaderNexus</span>
          </div>

          <Card className="shadow-lg">
            <CardHeader className="space-y-1 pb-4 px-4 sm:px-6">
              <CardTitle className="text-xl sm:text-2xl font-bold">Ro'yxatdan o'tish</CardTitle>
              <CardDescription className="text-sm">Ma'lumotlaringizni kiriting va boshlang</CardDescription>
            </CardHeader>
            <CardContent className="px-4 sm:px-6">
              {dataLoadError && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    <strong>Ma'lumotlar bazasi sozlanmagan:</strong> {dataLoadError}
                    <div className="mt-3 p-3 bg-background/50 rounded-md">
                      <p className="text-xs font-medium mb-2">Muammoni hal qilish uchun:</p>
                      <ol className="text-xs ml-4 list-decimal space-y-1">
                        <li>v0 loyihangizdagi Scripts bo'limiga o'ting</li>
                        <li>Barcha 6 ta SQL skriptlarini ishga tushiring</li>
                        <li>Sahifani yangilang</li>
                      </ol>
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleRegister} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="username" className="text-sm font-medium">
                      Foydalanuvchi nomi
                    </Label>
                    <Input
                      id="username"
                      placeholder="johndoe"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      disabled={isLoading}
                      className="h-11 sm:h-11 focus-visible-ring"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fullName" className="text-sm font-medium">
                      To'liq ism
                    </Label>
                    <Input
                      id="fullName"
                      placeholder="Ism Familiya"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      disabled={isLoading}
                      className="h-11 sm:h-11 focus-visible-ring"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">
                    Elektron pochta
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="sardor@example.com"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={isLoading}
                    className="h-11 sm:h-11 focus-visible-ring"
                  />
                </div>

                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground mb-4">Joylashuv ma'lumotlari</p>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="district" className="text-sm font-medium">
                        Tuman <span className="text-destructive">*</span>
                      </Label>
                      <Select
                        value={districtId}
                        onValueChange={handleDistrictChange}
                        disabled={isLoading || districts.length === 0}
                        required
                      >
                        <SelectTrigger id="district" className="h-11 sm:h-11 focus-visible-ring">
                          <SelectValue
                            placeholder={districts.length === 0 ? "Tumanlar yuklanmadi" : "Tumanni tanlang"}
                          />
                        </SelectTrigger>
                        <SelectContent>
                          {districts.map((d) => (
                            <SelectItem key={d.id} value={d.id}>
                              {d.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        {districts.length > 0
                          ? `Surxondaryo viloyati - ${districts.length} ta tuman`
                          : "Ma'lumotlar bazasini tekshiring"}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="direction" className="text-sm font-medium">
                        Yo'nalish <span className="text-destructive">*</span>
                      </Label>
                      <Select
                        value={directionId}
                        onValueChange={handleDirectionChange}
                        disabled={isLoading || !districtId || directions.length === 0}
                        required
                      >
                        <SelectTrigger id="direction" className="h-11 sm:h-11 focus-visible-ring">
                          <SelectValue placeholder={!districtId ? "Avval tumanni tanlang" : "Yo'nalishni tanlang"} />
                        </SelectTrigger>
                        <SelectContent>
                          {directions.map((d) => (
                            <SelectItem key={d.id} value={d.id}>
                              {d.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {districtId && directions.length > 0 && (
                        <p className="text-xs text-muted-foreground">
                          Har bir yo'nalishdan faqat bitta sardor tanlanadi
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {isCheckingAvailability && districtId && directionId && (
                  <Alert className="border-muted">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <AlertDescription className="text-sm">Mavjudlik tekshirilmoqda...</AlertDescription>
                  </Alert>
                )}

                {directionAvailability && !directionAvailability.available && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="text-sm font-medium">{directionAvailability.message}</AlertDescription>
                  </Alert>
                )}

                {directionAvailability && directionAvailability.available && (
                  <Alert className="border-green-500/50 bg-green-50 dark:bg-green-950/30">
                    <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                    <AlertDescription className="text-sm font-medium text-green-700 dark:text-green-300">
                      Bu yo'nalish {district} tumanida mavjud
                    </AlertDescription>
                  </Alert>
                )}

                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground mb-4">Xavfsizlik</p>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-sm font-medium">
                        Parol
                      </Label>
                      <Input
                        id="password"
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        disabled={isLoading}
                        className="h-11 sm:h-11 focus-visible-ring"
                        placeholder="Kamida 6 ta belgi"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="text-sm font-medium">
                        Parolni tasdiqlash
                      </Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        disabled={isLoading}
                        className="h-11 sm:h-11 focus-visible-ring"
                        placeholder="Parolni qayta kiriting"
                      />
                    </div>
                  </div>
                </div>

                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="text-sm">{error}</AlertDescription>
                  </Alert>
                )}

                <Button
                  type="submit"
                  className="w-full h-12 text-base font-medium btn-hover"
                  disabled={
                    isLoading ||
                    !directionAvailability ||
                    !directionAvailability.available ||
                    districts.length === 0 ||
                    directions.length === 0
                  }
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Ro'yxatdan o'tkazilmoqda...
                    </>
                  ) : (
                    "Ro'yxatdan o'tish"
                  )}
                </Button>
              </form>

              <div className="mt-6 text-center text-sm">
                <span className="text-muted-foreground">Hisobingiz bormi?</span>{" "}
                <Link href="/auth/login" className="font-medium text-accent hover:underline underline-offset-4">
                  Kirish
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
