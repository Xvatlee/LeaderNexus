"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { Users } from "lucide-react"
import { useTranslations } from "@/lib/i18n/use-translations"

export default function LoginPage() {
  const { t } = useTranslations()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })
      if (error) throw error
      router.push("/dashboard")
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : t("common.error"))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-primary text-primary-foreground p-8 md:p-12 flex-col justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-8 w-8" />
          <span className="text-2xl font-bold">LeaderNexus</span>
        </div>

        <div className="space-y-6 max-w-lg">
          <h1 className="text-4xl md:text-5xl font-bold leading-tight text-balance">{t("auth.login.heroTitle")}</h1>
          <p className="text-base md:text-lg text-primary-foreground/80 leading-relaxed">
            {t("auth.login.heroSubtitle")}
          </p>

          <div className="grid grid-cols-3 gap-4 pt-8">
            <div className="space-y-1">
              <div className="text-2xl md:text-3xl font-bold">10K+</div>
              <div className="text-xs md:text-sm text-primary-foreground/70">Active Leaders</div>
            </div>
            <div className="space-y-1">
              <div className="text-2xl md:text-3xl font-bold">50K+</div>
              <div className="text-xs md:text-sm text-primary-foreground/70">Forum Posts</div>
            </div>
            <div className="space-y-1">
              <div className="text-2xl md:text-3xl font-bold">1M+</div>
              <div className="text-xs md:text-sm text-primary-foreground/70">Points Earned</div>
            </div>
          </div>
        </div>

        <p className="text-sm text-primary-foreground/60">© 2025 LeaderNexus. Empowering leaders worldwide.</p>
      </div>

      {/* Right side - Login form */}
      <div className="flex w-full lg:w-1/2 items-center justify-center p-4 sm:p-6 md:p-10">
        <div className="w-full max-w-md mx-auto">
          <div className="lg:hidden mb-6 sm:mb-8 flex items-center gap-2 justify-center">
            <Users className="h-6 w-6" />
            <span className="text-xl font-bold">LeaderNexus</span>
          </div>

          <Card>
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold">{t("auth.login.title")}</CardTitle>
              <CardDescription>{t("auth.login.subtitle")}</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">{t("auth.login.email")}</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder={t("auth.login.emailPlaceholder")}
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={isLoading}
                    className="min-h-[44px]"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">{t("auth.login.password")}</Label>
                    <Link
                      href="/auth/forgot-password"
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {t("auth.login.forgotPassword")}
                    </Link>
                  </div>
                  <Input
                    id="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={isLoading}
                    className="min-h-[44px]"
                  />
                </div>
                {error && (
                  <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md p-3 break-words">
                    {error}
                  </div>
                )}
                <Button type="submit" className="w-full min-h-[44px]" disabled={isLoading}>
                  {isLoading ? t("auth.login.signingIn") : t("auth.login.signIn")}
                </Button>
              </form>

              <div className="mt-6 text-center text-sm">
                {t("auth.login.noAccount")}{" "}
                <Link
                  href="/auth/register"
                  className="font-medium underline underline-offset-4 hover:text-primary transition-colors"
                >
                  {t("auth.login.createAccount")}
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
