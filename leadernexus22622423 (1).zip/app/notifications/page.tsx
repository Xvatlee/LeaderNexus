import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { NotificationsListClient } from "@/components/notifications/notifications-list-client"

export default async function NotificationsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: notifications } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  const unreadCount = notifications?.filter((n) => !n.read).length || 0

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8 px-4">
        <div className="max-w-3xl mx-auto space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Bildirishnomalar</h1>
            <p className="text-muted-foreground mt-2">
              {unreadCount > 0
                ? `${unreadCount} ta o'qilmagan bildirishnoma`
                : "Barcha bildirishnomalarni o'qib bo'ldingiz!"}
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Barcha bildirishnomalar</CardTitle>
            </CardHeader>
            <CardContent>
              <NotificationsListClient notifications={notifications || []} userId={user.id} />
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
