"use client"

import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Trophy, MessageSquare, TrendingUp, Award, Users, MapPin, Target, ShieldCheck, UserCheck } from "lucide-react"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { useTranslations } from "@/lib/i18n/use-translations"
import { useEffect, useState } from "react"
import type { Profile } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { AnimatedCounter } from "@/components/stats/animated-counter"
import { StatsChart } from "@/components/stats/stats-chart"

interface Post {
  id: string
  title: string
  created_at: string
  comments_count: number
  likes: number
  author?: {
    id: string
    username: string
    avatar_url?: string
  }
}

export default function DashboardPage() {
  const { t } = useTranslations()
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [stats, setStats] = useState({
    postsCount: 0,
    commentsCount: 0,
    achievementsCount: 0,
  })
  const [recentPosts, setRecentPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        redirect("/auth/login")
        return
      }

      setUser(authUser)

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", authUser.id).maybeSingle()

      if (!userProfile) {
        const username = authUser.email?.split("@")[0] || `user_${authUser.id.substring(0, 8)}`
        const { data: newProfile } = await supabase
          .from("profiles")
          .insert({
            id: authUser.id,
            email: authUser.email,
            username,
            full_name: authUser.email,
          })
          .select()
          .single()

        if (newProfile) {
          setProfile(newProfile)
        }
      } else {
        setProfile(userProfile)

        if (userProfile.role === "district_head_leader" && userProfile.district) {
          redirect(`/district-dashboard/${userProfile.district}`)
          return
        }
      }

      // Fetch stats
      const { count: postsCount } = await supabase
        .from("posts")
        .select("*", { count: "exact", head: true })
        .eq("author_id", authUser.id)

      const { count: commentsCount } = await supabase
        .from("comments")
        .select("*", { count: "exact", head: true })
        .eq("author_id", authUser.id)

      const { count: achievementsCount } = await supabase
        .from("user_achievements")
        .select("*", { count: "exact", head: true })
        .eq("user_id", authUser.id)

      setStats({
        postsCount: postsCount || 0,
        commentsCount: commentsCount || 0,
        achievementsCount: achievementsCount || 0,
      })

      const { data: posts } = await supabase
        .from("posts")
        .select("*, author:profiles(id, username, avatar_url)")
        .order("created_at", { ascending: false })
        .limit(5)

      setRecentPosts(posts || [])
      setLoading(false)
    }

    loadData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="sticky top-0 z-50 w-full border-b bg-background/95 h-16" />
        <div className="container mx-auto py-8 max-w-7xl">
          <div className="space-y-8">
            <div className="space-y-2">
              <div className="h-9 w-64 bg-muted animate-pulse rounded-md" />
              <div className="h-5 w-48 bg-muted animate-pulse rounded-md" />
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-32 bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container mx-auto py-8 max-w-7xl">
        <div className="space-y-8">
          {/* Welcome Section */}
          <div className="animate-fade-in-up">
            <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">
              {t("dashboard.welcome", { name: profile?.full_name || profile?.username })}
            </h1>
            <p className="text-muted-foreground mt-2">{t("dashboard.subtitle")}</p>

            {profile?.role === "leader" && (profile?.district || profile?.direction) && (
              <div className="flex gap-2 mt-4 flex-wrap">
                {profile.district && (
                  <Badge variant="secondary" className="flex items-center gap-1 badge-pulse">
                    <MapPin className="h-3 w-3" />
                    {profile.district} tumani
                  </Badge>
                )}
                {profile.direction && (
                  <Badge variant="default" className="flex items-center gap-1 badge-pulse">
                    <Target className="h-3 w-3" />
                    {profile.direction}
                  </Badge>
                )}
              </div>
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="stat-card-hover animate-scale-in animate-stagger-1">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{t("dashboard.totalPoints")}</CardTitle>
                <Trophy className="h-4 w-4 text-muted-foreground icon-hover" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  <AnimatedCounter value={profile?.points || 0} />
                </div>
                <p className="text-xs text-muted-foreground">{t("dashboard.totalPointsDesc")}</p>
              </CardContent>
            </Card>

            <Card className="stat-card-hover animate-scale-in animate-stagger-2">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{t("dashboard.yourPosts")}</CardTitle>
                <MessageSquare className="h-4 w-4 text-muted-foreground icon-hover" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  <AnimatedCounter value={stats.postsCount} />
                </div>
                <p className="text-xs text-muted-foreground">{t("dashboard.yourPostsDesc")}</p>
              </CardContent>
            </Card>

            <Card className="stat-card-hover animate-scale-in animate-stagger-3">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{t("dashboard.comments")}</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground icon-hover" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  <AnimatedCounter value={stats.commentsCount} />
                </div>
                <p className="text-xs text-muted-foreground">{t("dashboard.commentsDesc")}</p>
              </CardContent>
            </Card>

            <Card className="stat-card-hover animate-scale-in animate-stagger-4">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{t("dashboard.achievements")}</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground icon-hover" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  <AnimatedCounter value={stats.achievementsCount} />
                </div>
                <p className="text-xs text-muted-foreground">{t("dashboard.achievementsDesc")}</p>
              </CardContent>
            </Card>
          </div>

          <StatsChart
            title="Your Activity This Week"
            description="Track your contributions and engagement"
            data={[
              { label: "Monday", value: 5 },
              { label: "Tuesday", value: 8 },
              { label: "Wednesday", value: 12 },
              { label: "Thursday", value: 7 },
              { label: "Friday", value: 15 },
              { label: "Saturday", value: 9 },
              { label: "Sunday", value: 6 },
            ]}
          />

          {profile?.role === "leader" && profile?.district && profile?.direction && (
            <Card className="border-primary/20 bg-primary/5 animate-fade-in-up animate-stagger-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Rahbarlik vazifalari
                </CardTitle>
                <CardDescription>
                  Siz {profile.district} tumanida {profile.direction} lavozimini egallaysiz
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Sizning hududingiz</h4>
                      <p className="text-sm text-muted-foreground">{profile.district} tumani, Surxondaryo viloyati</p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Mas'uliyat sohasi</h4>
                      <p className="text-sm text-muted-foreground">{profile.direction}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 pt-4 border-t">
                    <Button asChild variant="outline" size="sm">
                      <Link href="/projects">Loyihalarni boshqarish</Link>
                    </Button>
                    <Button asChild variant="outline" size="sm">
                      <Link href="/voting">Ovoz berish tizimi</Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* District Head Leader Dashboard Card */}
          {profile?.role === "district_head_leader" && profile?.district && (
            <Card className="border-primary/20 bg-gradient-to-br from-primary/10 to-accent/10 animate-fade-in-up animate-stagger-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5" />
                  Bosh Sardor Dashboard
                </CardTitle>
                <CardDescription>
                  Siz {profile.district} tumanining Bosh sardori sifatida faoliyat yuritasiz
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Sizning hududingiz</h4>
                      <p className="text-sm text-muted-foreground">{profile.district} tumani, Surxondaryo viloyati</p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Sardorlar soni</h4>
                      <p className="text-sm text-muted-foreground">9 ta yo'nalish sardori</p>
                    </div>
                  </div>
                  <div className="flex gap-2 pt-4 border-t">
                    <Button asChild className="btn-hover">
                      <Link href={`/district-dashboard/${profile.district}`}>
                        <Target className="mr-2 h-4 w-4" />
                        Dashboardga o'tish
                      </Link>
                    </Button>
                    <Button asChild variant="outline">
                      <Link href={`/district-dashboard/${profile.district}?tab=sardors`}>
                        <UserCheck className="mr-2 h-4 w-4" />
                        Sardorlarni boshqarish
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Quick Actions */}
          <Card className="animate-fade-in-up animate-stagger-3">
            <CardHeader>
              <CardTitle>{t("dashboard.quickActions")}</CardTitle>
              <CardDescription>{t("dashboard.quickActionsDesc")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Button
                  asChild
                  className="h-24 flex-col items-start justify-start gap-2 p-4 text-left btn-hover focus-visible-ring"
                >
                  <Link href="/forum/new">
                    <MessageSquare className="h-6 w-6" />
                    <div className="space-y-1">
                      <div className="font-semibold text-sm">{t("dashboard.createPost")}</div>
                      <div className="text-xs opacity-80 leading-tight">{t("dashboard.createPostDesc")}</div>
                    </div>
                  </Link>
                </Button>

                <Button
                  asChild
                  variant="outline"
                  className="h-24 flex-col items-start justify-start gap-2 p-4 bg-transparent text-left card-hover focus-visible-ring"
                >
                  <Link href="/leaderboard">
                    <TrendingUp className="h-6 w-6" />
                    <div className="space-y-1">
                      <div className="font-semibold text-sm">{t("dashboard.viewLeaderboard")}</div>
                      <div className="text-xs opacity-80 leading-tight">{t("dashboard.viewLeaderboardDesc")}</div>
                    </div>
                  </Link>
                </Button>

                <Button
                  asChild
                  variant="outline"
                  className="h-24 flex-col items-start justify-start gap-2 p-4 bg-transparent text-left card-hover focus-visible-ring"
                >
                  <Link href="/achievements">
                    <Award className="h-6 w-6" />
                    <div className="space-y-1">
                      <div className="font-semibold text-sm">{t("dashboard.viewAchievements")}</div>
                      <div className="text-xs opacity-80 leading-tight">{t("dashboard.viewAchievementsDesc")}</div>
                    </div>
                  </Link>
                </Button>

                <Button
                  asChild
                  variant="outline"
                  className="h-24 flex-col items-start justify-start gap-2 p-4 bg-transparent text-left card-hover focus-visible-ring"
                >
                  <Link href="/profile">
                    <Award className="h-6 w-6" />
                    <div className="space-y-1">
                      <div className="font-semibold text-sm">{t("dashboard.viewProfile")}</div>
                      <div className="text-xs opacity-80 leading-tight">{t("dashboard.viewProfileDesc")}</div>
                    </div>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="animate-fade-in-up animate-stagger-4">
            <CardHeader>
              <CardTitle>{t("dashboard.recentActivity")}</CardTitle>
              <CardDescription>{t("dashboard.recentActivityDesc")}</CardDescription>
            </CardHeader>
            <CardContent>
              {recentPosts && recentPosts.length > 0 ? (
                <div className="space-y-4">
                  {recentPosts.map((post) => (
                    <div
                      key={post.id}
                      className="flex items-center justify-between border-b pb-4 last:border-0 card-hover p-2 rounded-lg"
                    >
                      <div className="space-y-1">
                        <Link href={`/forum/post/${post.id}`} className="font-medium hover:underline">
                          {post.title}
                        </Link>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>
                            {t("dashboard.by")} {post.author?.username}
                          </span>
                          <span>{new Date(post.created_at).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <MessageSquare className="h-4 w-4" />
                          <span>{post.comments_count}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Trophy className="h-4 w-4" />
                          <span>{post.likes}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>{t("dashboard.noPosts")}</p>
                  <Button asChild className="mt-4 btn-hover">
                    <Link href="/forum/new">{t("dashboard.createPost")}</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
