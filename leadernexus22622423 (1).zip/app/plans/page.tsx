"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { Calendar, Plus, TrendingUp, Clock, CheckCircle2, AlertCircle } from "lucide-react"
import type { Profile } from "@/lib/types"

interface Plan {
  id: string
  title: string
  description: string
  plan_type: "weekly" | "monthly" | "yearly"
  start_date: string
  end_date: string
  status: "pending" | "in_progress" | "completed" | "cancelled"
  progress: number
  created_at: string
  plan_tasks: { count: number }[]
}

export default function PlansPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [plans, setPlans] = useState<Plan[]>([])
  const [activeTab, setActiveTab] = useState("all")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()
      setProfile(userProfile)

      // Fetch all plans
      const { data: allPlans } = await supabase
        .from("plans")
        .select("*, plan_tasks(count)")
        .eq("leader_id", user.id)
        .order("created_at", { ascending: false })

      setPlans(allPlans || [])
      setLoading(false)
    }

    loadData()
  }, [])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      case "in_progress":
        return <Clock className="h-4 w-4 text-blue-500" />
      case "pending":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500/10 text-green-500 border-green-500/20"
      case "in_progress":
        return "bg-blue-500/10 text-blue-500 border-blue-500/20"
      case "pending":
        return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const filteredPlans = activeTab === "all" ? plans : plans.filter((plan) => plan.plan_type === activeTab)

  const stats = {
    total: plans.length,
    weekly: plans.filter((p) => p.plan_type === "weekly").length,
    monthly: plans.filter((p) => p.plan_type === "monthly").length,
    yearly: plans.filter((p) => p.plan_type === "yearly").length,
    inProgress: plans.filter((p) => p.status === "in_progress").length,
    completed: plans.filter((p) => p.status === "completed").length,
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold tracking-tight">My Plans</h1>
              <p className="text-muted-foreground mt-2">Manage your weekly, monthly, and yearly plans</p>
            </div>
            <Button asChild>
              <Link href="/plans/new">
                <Plus className="mr-2 h-4 w-4" />
                Create New Plan
              </Link>
            </Button>
          </div>

          {/* Stats Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Plans</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
                <p className="text-xs text-muted-foreground">All your plans</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">In Progress</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.inProgress}</div>
                <p className="text-xs text-muted-foreground">Active plans</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Completed</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.completed}</div>
                <p className="text-xs text-muted-foreground">Finished plans</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Yearly Goals</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.yearly}</div>
                <p className="text-xs text-muted-foreground">Long-term plans</p>
              </CardContent>
            </Card>
          </div>

          {/* Plans List with Tabs */}
          <Card>
            <CardHeader>
              <CardTitle>Your Plans</CardTitle>
              <CardDescription>View and manage all your plans by time period</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                <TabsList>
                  <TabsTrigger value="all">All Plans ({stats.total})</TabsTrigger>
                  <TabsTrigger value="weekly">Weekly ({stats.weekly})</TabsTrigger>
                  <TabsTrigger value="monthly">Monthly ({stats.monthly})</TabsTrigger>
                  <TabsTrigger value="yearly">Yearly ({stats.yearly})</TabsTrigger>
                </TabsList>

                <TabsContent value={activeTab} className="space-y-4">
                  {filteredPlans.length > 0 ? (
                    filteredPlans.map((plan) => (
                      <Card key={plan.id} className="hover:border-accent/50 transition-colors">
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            <div className="flex items-start justify-between">
                              <div className="space-y-1 flex-1">
                                <Link href={`/plans/${plan.id}`} className="group">
                                  <h3 className="text-lg font-semibold group-hover:text-accent transition-colors">
                                    {plan.title}
                                  </h3>
                                </Link>
                                {plan.description && (
                                  <p className="text-sm text-muted-foreground line-clamp-2">{plan.description}</p>
                                )}
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="capitalize">
                                  {plan.plan_type}
                                </Badge>
                                <Badge variant="outline" className={getStatusColor(plan.status)}>
                                  <div className="flex items-center gap-1">
                                    {getStatusIcon(plan.status)}
                                    <span className="capitalize">{plan.status.replace("_", " ")}</span>
                                  </div>
                                </Badge>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground">Progress</span>
                                <span className="font-medium">{plan.progress}%</span>
                              </div>
                              <Progress value={plan.progress} className="h-2" />
                            </div>

                            <div className="flex items-center justify-between text-sm text-muted-foreground">
                              <div className="flex items-center gap-4">
                                <div className="flex items-center gap-1">
                                  <Calendar className="h-4 w-4" />
                                  <span>
                                    {new Date(plan.start_date).toLocaleDateString()} -{" "}
                                    {new Date(plan.end_date).toLocaleDateString()}
                                  </span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <CheckCircle2 className="h-4 w-4" />
                                  <span>{plan.plan_tasks[0]?.count || 0} tasks</span>
                                </div>
                              </div>
                              <Button asChild variant="outline" size="sm">
                                <Link href={`/plans/${plan.id}`}>View Details</Link>
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <h3 className="text-lg font-semibold mb-2">No plans yet</h3>
                      <p className="mb-4">Create your first plan to get started</p>
                      <Button asChild>
                        <Link href="/plans/new">
                          <Plus className="mr-2 h-4 w-4" />
                          Create New Plan
                        </Link>
                      </Button>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
