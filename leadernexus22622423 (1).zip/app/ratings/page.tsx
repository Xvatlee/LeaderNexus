import { Suspense } from "react"
import { RatingsContent } from "@/components/ratings/ratings-content"

export const metadata = {
  title: "Sardorlar reytingi | Bolalar harakati",
  description: "Tuman sardorlari reytingi va baholash tizimi",
}

export default function RatingsPage() {
  return (
    <Suspense fallback={null}>
      <RatingsContent />
    </Suspense>
  )
}
