import { Suspense } from "react"
import { FeedbackContent } from "@/components/ratings/feedback-content"

export const metadata = {
  title: "Jamoatchilik fikri | Bolalar harakati",
  description: "Sardorlarga fikr va taklif bildirish",
}

export default function FeedbackPage() {
  return (
    <Suspense fallback={null}>
      <FeedbackContent />
    </Suspense>
  )
}
