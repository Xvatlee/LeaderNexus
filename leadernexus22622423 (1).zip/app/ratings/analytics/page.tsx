import { Suspense } from "react"
import { AnalyticsContent } from "@/components/ratings/analytics-content"

export const metadata = {
  title: "Reyting statistikasi | Bolalar harakati",
  description: "Sardorlar faoliyati tahlili va statistika",
}

export default function AnalyticsPage() {
  return (
    <Suspense fallback={null}>
      <AnalyticsContent />
    </Suspense>
  )
}
