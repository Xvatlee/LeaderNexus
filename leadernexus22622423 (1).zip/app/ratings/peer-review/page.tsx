import { Suspense } from "react"
import { PeerReviewContent } from "@/components/ratings/peer-review-content"

export const metadata = {
  title: "Hamkasblarni baholash | Bolalar harakati",
  description: "Boshqa sardorlarni baholash va fikr bildirish",
}

export default function PeerReviewPage() {
  return (
    <Suspense fallback={null}>
      <PeerReviewContent />
    </Suspense>
  )
}
