"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MessageSquare, Eye, MessageCircle, Search } from "lucide-react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { Profile } from "@/lib/types"

interface Discussion {
  id: string
  title: string
  content: string
  views_count: number
  replies_count: number
  created_at: string
  author: {
    username: string
    full_name: string | null
    avatar_url: string | null
  }
}

export default function LeaderDiscussionsPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [discussions, setDiscussions] = useState<Discussion[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      if (!userProfile || (userProfile.role !== "leader" && userProfile.role !== "admin")) {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      // Get discussions
      const { data: discussionsData } = await supabase
        .from("leader_discussions")
        .select(
          `
          *,
          author:profiles!author_id(username, full_name, avatar_url)
        `,
        )
        .order("created_at", { ascending: false })

      setDiscussions(discussionsData || [])
      setLoading(false)
    }

    loadData()
  }, [])

  const filteredDiscussions = discussions.filter(
    (discussion) =>
      discussion.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      discussion.content.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold tracking-tight">Leader Discussions</h1>
              <p className="text-muted-foreground mt-2">Share experiences and learn from fellow leaders</p>
            </div>
            <Button asChild>
              <Link href="/leader-hub/discussions/new">
                <MessageSquare className="h-4 w-4 mr-2" />
                New Discussion
              </Link>
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search discussions..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Discussions List */}
          <Card>
            <CardHeader>
              <CardTitle>All Discussions</CardTitle>
              <CardDescription>Connect with other leaders and share insights</CardDescription>
            </CardHeader>
            <CardContent>
              {filteredDiscussions.length > 0 ? (
                <div className="space-y-4">
                  {filteredDiscussions.map((discussion) => (
                    <Link
                      key={discussion.id}
                      href={`/leader-hub/discussions/${discussion.id}`}
                      className="flex items-start gap-4 p-4 rounded-lg border hover:bg-accent/5 transition-colors"
                    >
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={discussion.author.avatar_url || ""} />
                        <AvatarFallback>{discussion.author.username?.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 space-y-2">
                        <div>
                          <h3 className="font-semibold hover:underline">{discussion.title}</h3>
                          <p className="text-sm text-muted-foreground line-clamp-2">{discussion.content}</p>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{discussion.author.full_name || discussion.author.username}</span>
                          <span>•</span>
                          <span>{new Date(discussion.created_at).toLocaleDateString()}</span>
                          <div className="flex items-center gap-4 ml-auto">
                            <div className="flex items-center gap-1">
                              <Eye className="h-4 w-4" />
                              <span>{discussion.views_count}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MessageCircle className="h-4 w-4" />
                              <span>{discussion.replies_count}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No discussions found</p>
                  <Button asChild className="mt-4">
                    <Link href="/leader-hub/discussions/new">Start a Discussion</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
