"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Users, UserPlus, Award, Calendar } from "lucide-react"
import type { Profile } from "@/lib/types"

interface MentorshipRelationship {
  id: string
  status: string
  start_date: string | null
  end_date: string | null
  focus_areas: string[] | null
  mentor: {
    username: string
    full_name: string | null
    avatar_url: string | null
    points: number
  }
  mentee: {
    username: string
    full_name: string | null
    avatar_url: string | null
    points: number
  }
}

export default function MentorshipPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [asMentor, setAsMentor] = useState<MentorshipRelationship[]>([])
  const [asMentee, setAsMentee] = useState<MentorshipRelationship[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      if (!userProfile || (userProfile.role !== "leader" && userProfile.role !== "admin")) {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      // Fetch mentorship relationships where user is mentor
      const { data: mentorData } = await supabase
        .from("mentorship_relationships")
        .select(
          `
          *,
          mentor:profiles!mentor_id(username, full_name, avatar_url, points),
          mentee:profiles!mentee_id(username, full_name, avatar_url, points)
        `,
        )
        .eq("mentor_id", user.id)

      setAsMentor(mentorData || [])

      // Fetch mentorship relationships where user is mentee
      const { data: menteeData } = await supabase
        .from("mentorship_relationships")
        .select(
          `
          *,
          mentor:profiles!mentor_id(username, full_name, avatar_url, points),
          mentee:profiles!mentee_id(username, full_name, avatar_url, points)
        `,
        )
        .eq("mentee_id", user.id)

      setAsMentee(menteeData || [])

      setLoading(false)
    }

    loadData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold tracking-tight">Mentorship Program</h1>
              <p className="text-muted-foreground mt-2">Connect with experienced leaders and grow together</p>
            </div>
            <Button>
              <UserPlus className="h-4 w-4 mr-2" />
              Find a Mentor
            </Button>
          </div>

          {/* Stats */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">As Mentor</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{asMentor.length}</div>
                <p className="text-xs text-muted-foreground">Mentees you're guiding</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Your Mentors</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{asMentee.length}</div>
                <p className="text-xs text-muted-foreground">Leaders guiding you</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Sessions</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {[...asMentor, ...asMentee].filter((r) => r.status === "active").length}
                </div>
                <p className="text-xs text-muted-foreground">Currently ongoing</p>
              </CardContent>
            </Card>
          </div>

          {/* Your Mentees */}
          {asMentor.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Your Mentees</CardTitle>
                <CardDescription>Leaders you are mentoring</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {asMentor.map((relationship) => (
                    <div key={relationship.id} className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center gap-4">
                        <Avatar>
                          <AvatarImage src={relationship.mentee.avatar_url || ""} />
                          <AvatarFallback>{relationship.mentee.username?.charAt(0).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-semibold">
                            {relationship.mentee.full_name || relationship.mentee.username}
                          </div>
                          <div className="text-sm text-muted-foreground">@{relationship.mentee.username}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-sm font-medium">{relationship.mentee.points} pts</div>
                          {relationship.focus_areas && relationship.focus_areas.length > 0 && (
                            <div className="flex gap-1 mt-1">
                              {relationship.focus_areas.slice(0, 2).map((area, i) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {area}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                        <Badge
                          variant={
                            relationship.status === "active"
                              ? "default"
                              : relationship.status === "pending"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {relationship.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Your Mentors */}
          {asMentee.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Your Mentors</CardTitle>
                <CardDescription>Leaders guiding you</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {asMentee.map((relationship) => (
                    <div key={relationship.id} className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center gap-4">
                        <Avatar>
                          <AvatarImage src={relationship.mentor.avatar_url || ""} />
                          <AvatarFallback>{relationship.mentor.username?.charAt(0).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-semibold">
                            {relationship.mentor.full_name || relationship.mentor.username}
                          </div>
                          <div className="text-sm text-muted-foreground">@{relationship.mentor.username}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-sm font-medium">{relationship.mentor.points} pts</div>
                          {relationship.focus_areas && relationship.focus_areas.length > 0 && (
                            <div className="flex gap-1 mt-1">
                              {relationship.focus_areas.slice(0, 2).map((area, i) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {area}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                        <Badge
                          variant={
                            relationship.status === "active"
                              ? "default"
                              : relationship.status === "pending"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {relationship.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Empty State */}
          {asMentor.length === 0 && asMentee.length === 0 && (
            <Card>
              <CardContent className="py-12">
                <div className="text-center space-y-4">
                  <Users className="h-16 w-16 mx-auto text-muted-foreground opacity-50" />
                  <div>
                    <h3 className="font-semibold text-lg">No Mentorship Relationships Yet</h3>
                    <p className="text-muted-foreground mt-2">
                      Connect with experienced leaders or share your knowledge with others
                    </p>
                  </div>
                  <div className="flex gap-4 justify-center">
                    <Button>
                      <UserPlus className="h-4 w-4 mr-2" />
                      Find a Mentor
                    </Button>
                    <Button variant="outline">
                      <Users className="h-4 w-4 mr-2" />
                      Become a Mentor
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
