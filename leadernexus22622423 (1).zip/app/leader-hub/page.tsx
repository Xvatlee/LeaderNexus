"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Video, FileText, Users, Play, Clock, Award, TrendingUp } from "lucide-react"
import Link from "next/link"
import type { Profile } from "@/lib/types"

interface TrainingResource {
  id: string
  title: string
  description: string
  content_type: string
  category: string
  duration_minutes: number
  difficulty_level: string
  thumbnail_url?: string
}

interface TrainingProgress {
  resource_id: string
  status: string
  progress_percentage: number
  completed_at?: string
}

export default function LeaderHubPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [resources, setResources] = useState<TrainingResource[]>([])
  const [progress, setProgress] = useState<Map<string, TrainingProgress>>(new Map())
  const [loading, setLoading] = useState(true)
  const [categoryFilter, setCategoryFilter] = useState("all")

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      if (!userProfile || (userProfile.role !== "leader" && userProfile.role !== "admin")) {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      // Fetch training resources
      const { data: trainingData } = await supabase
        .from("training_resources")
        .select("*")
        .eq("is_published", true)
        .order("created_at", { ascending: false })

      setResources(trainingData || [])

      // Fetch user's progress
      const { data: progressData } = await supabase.from("leader_training").select("*").eq("leader_id", user.id)

      const progressMap = new Map()
      progressData?.forEach((p) => {
        progressMap.set(p.resource_id, p)
      })
      setProgress(progressMap)

      setLoading(false)
    }

    loadData()
  }, [])

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "video":
        return <Video className="h-4 w-4" />
      case "article":
        return <FileText className="h-4 w-4" />
      case "webinar":
        return <Users className="h-4 w-4" />
      case "course":
        return <BookOpen className="h-4 w-4" />
      default:
        return <BookOpen className="h-4 w-4" />
    }
  }

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case "beginner":
        return "bg-green-500"
      case "intermediate":
        return "bg-yellow-500"
      case "advanced":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const filteredResources =
    categoryFilter === "all" ? resources : resources.filter((r) => r.category === categoryFilter)

  const completedCount = Array.from(progress.values()).filter((p) => p.status === "completed").length
  const inProgressCount = Array.from(progress.values()).filter((p) => p.status === "in_progress").length

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-4xl font-bold tracking-tight">Leader Training Hub</h1>
            <p className="text-muted-foreground mt-2">Develop your leadership skills with curated resources</p>
          </div>

          {/* Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Resources</CardTitle>
                <BookOpen className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{resources.length}</div>
                <p className="text-xs text-muted-foreground">Available for you</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Completed</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{completedCount}</div>
                <p className="text-xs text-muted-foreground">Courses finished</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">In Progress</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{inProgressCount}</div>
                <p className="text-xs text-muted-foreground">Currently learning</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Learning Hours</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Math.round(resources.reduce((sum, r) => sum + (r.duration_minutes || 0), 0) / 60)}
                </div>
                <p className="text-xs text-muted-foreground">Total content hours</p>
              </CardContent>
            </Card>
          </div>

          {/* Training Resources */}
          <Card>
            <CardHeader>
              <CardTitle>Training Resources</CardTitle>
              <CardDescription>Browse and access training materials</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={categoryFilter} onValueChange={setCategoryFilter} className="space-y-4">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="leadership">Leadership</TabsTrigger>
                  <TabsTrigger value="communication">Communication</TabsTrigger>
                  <TabsTrigger value="organizational">Organizational</TabsTrigger>
                  <TabsTrigger value="management">Management</TabsTrigger>
                  <TabsTrigger value="technical">Technical</TabsTrigger>
                </TabsList>

                <TabsContent value={categoryFilter} className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {filteredResources.map((resource) => {
                      const userProgress = progress.get(resource.id)
                      return (
                        <Card key={resource.id} className="flex flex-col">
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-2">
                                {getTypeIcon(resource.content_type)}
                                <Badge variant="secondary">{resource.content_type}</Badge>
                              </div>
                              <div
                                className={`h-2 w-2 rounded-full ${getDifficultyColor(resource.difficulty_level)}`}
                              />
                            </div>
                            <CardTitle className="text-lg">{resource.title}</CardTitle>
                            <CardDescription>{resource.description}</CardDescription>
                          </CardHeader>
                          <CardContent className="flex-1">
                            <div className="space-y-3">
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <div className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  <span>{resource.duration_minutes} min</span>
                                </div>
                                <Badge variant="outline" className="text-xs">
                                  {resource.difficulty_level}
                                </Badge>
                              </div>

                              {userProgress && (
                                <div className="space-y-1">
                                  <div className="flex items-center justify-between text-sm">
                                    <span className="text-muted-foreground">Progress</span>
                                    <span className="font-medium">{userProgress.progress_percentage}%</span>
                                  </div>
                                  <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                                    <div
                                      className="h-full bg-accent transition-all"
                                      style={{ width: `${userProgress.progress_percentage}%` }}
                                    />
                                  </div>
                                  {userProgress.status === "completed" && (
                                    <Badge variant="default" className="mt-2">
                                      <Award className="h-3 w-3 mr-1" />
                                      Completed
                                    </Badge>
                                  )}
                                </div>
                              )}

                              <Button asChild className="w-full">
                                <Link href={`/leader-hub/resource/${resource.id}`}>
                                  <Play className="h-4 w-4 mr-2" />
                                  {userProgress?.status === "completed"
                                    ? "Review"
                                    : userProgress
                                      ? "Continue"
                                      : "Start"}
                                </Link>
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    })}
                  </div>

                  {filteredResources.length === 0 && (
                    <div className="text-center py-12 text-muted-foreground">
                      <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No resources found in this category</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Quick Links */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Discussion Forum</CardTitle>
                <CardDescription>Connect with fellow leaders</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild className="w-full">
                  <Link href="/leader-hub/discussions">
                    <Users className="h-4 w-4 mr-2" />
                    Join Discussions
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Mentorship Program</CardTitle>
                <CardDescription>Learn from experienced leaders</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild className="w-full">
                  <Link href="/leader-hub/mentorship">
                    <Award className="h-4 w-4 mr-2" />
                    Find a Mentor
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
