import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import CreateDecisionForm from "@/components/voting/create-decision-form"

export default async function NewDecisionPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="max-w-3xl mx-auto">
          <div className="mb-6">
            <h1 className="text-3xl font-bold tracking-tight">Propose New Decision</h1>
            <p className="text-muted-foreground mt-2">Submit a proposal for community governance</p>
          </div>

          <CreateDecisionForm userId={user.id} />
        </div>
      </main>
    </div>
  )
}
