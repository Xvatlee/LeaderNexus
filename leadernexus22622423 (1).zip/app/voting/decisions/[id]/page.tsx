import { redirect, notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import DecisionVoting from "@/components/voting/decision-voting"

export default async function DecisionDetailPage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Fetch decision with proposer
  const { data: decision, error } = await supabase
    .from("decisions")
    .select(
      `
      *,
      proposer:profiles!decisions_proposer_id_fkey(id, username, full_name, avatar_url)
    `,
    )
    .eq("id", params.id)
    .single()

  if (error || !decision) {
    notFound()
  }

  // Check if user has voted
  const { data: userVote } = await supabase
    .from("decision_votes")
    .select("*")
    .eq("decision_id", params.id)
    .eq("user_id", user.id)
    .maybeSingle()

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <DecisionVoting decision={decision} userVote={userVote} currentUserId={user.id} />
      </main>
    </div>
  )
}
