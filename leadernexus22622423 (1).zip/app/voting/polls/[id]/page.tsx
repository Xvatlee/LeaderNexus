import { redirect, notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import PollVoting from "@/components/voting/poll-voting"

export default async function PollDetailPage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Fetch poll with creator
  const { data: poll, error } = await supabase
    .from("polls")
    .select(
      `
      *,
      creator:profiles!polls_creator_id_fkey(id, username, full_name, avatar_url)
    `,
    )
    .eq("id", params.id)
    .single()

  if (error || !poll) {
    notFound()
  }

  // Fetch poll options with vote counts
  const { data: options } = await supabase
    .from("poll_options")
    .select("*, votes:poll_votes(count)")
    .eq("poll_id", params.id)
    .order("option_order")

  // Check if user has already voted
  const { data: userVote } = await supabase
    .from("poll_votes")
    .select("*, option:poll_options(option_text)")
    .eq("poll_id", params.id)
    .eq("user_id", user.id)
    .maybeSingle()

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <PollVoting poll={poll} options={options || []} userVote={userVote} currentUserId={user.id} />
      </main>
    </div>
  )
}
