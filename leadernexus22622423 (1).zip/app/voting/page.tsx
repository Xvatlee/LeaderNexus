"use client"

import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { Plus, Vote, CheckCircle2, XCircle, Clock } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useTranslations } from "@/lib/i18n/use-translations"
import { useEffect, useState } from "react"

export default function VotingPage() {
  const { t } = useTranslations()
  const [profile, setProfile] = useState<any>(null)
  const [activePolls, setActivePolls] = useState<any[]>([])
  const [decisions, setDecisions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()
      setProfile(userProfile)

      // Fetch active polls
      const { data: pollsData } = await supabase
        .from("polls")
        .select(
          `
          *,
          creator:profiles!polls_creator_id_fkey(id, username, full_name, avatar_url),
          options:poll_options(count)
        `,
        )
        .eq("status", "active")
        .order("created_at", { ascending: false })

      // Fetch decisions
      const { data: decisionsData } = await supabase
        .from("decisions")
        .select(
          `
          *,
          proposer:profiles!decisions_proposer_id_fkey(id, username, full_name, avatar_url)
        `,
        )
        .in("status", ["proposed", "voting", "approved", "rejected"])
        .order("created_at", { ascending: false })

      setActivePolls(pollsData || [])
      setDecisions(decisionsData || [])
      setLoading(false)
    }

    loadData()
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
      case "voting":
        return "bg-blue-500/10 text-blue-500"
      case "approved":
        return "bg-green-500/10 text-green-500"
      case "rejected":
      case "closed":
        return "bg-red-500/10 text-red-500"
      case "proposed":
        return "bg-yellow-500/10 text-yellow-500"
      case "implemented":
        return "bg-purple-500/10 text-purple-500"
      default:
        return "bg-gray-500/10 text-gray-500"
    }
  }

  const PollCard = ({ poll }: any) => (
    <Card className="flex flex-col">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1 flex-1 min-w-0">
            <CardTitle className="text-xl break-words">{poll.title}</CardTitle>
            <Badge className={getStatusColor(poll.status)}>{t(`voting.status.${poll.status}`)}</Badge>
          </div>
          <Vote className="h-5 w-5 text-muted-foreground flex-shrink-0" />
        </div>
        <CardDescription className="line-clamp-2">{poll.description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={poll.creator?.avatar_url || ""} />
              <AvatarFallback>{poll.creator?.username?.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
            <span className="text-sm text-muted-foreground truncate">
              {t("common.createdBy")} {poll.creator?.full_name || poll.creator?.username}
            </span>
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span className="text-xs">
                {poll.end_date
                  ? `${t("common.ends")} ${new Date(poll.end_date).toLocaleDateString()}`
                  : t("common.noEndDate")}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full">
          <Link href={`/voting/polls/${poll.id}`}>{t("voting.viewVote")}</Link>
        </Button>
      </CardFooter>
    </Card>
  )

  const DecisionCard = ({ decision }: any) => {
    const totalVotes = decision.vote_count_yes + decision.vote_count_no + decision.vote_count_abstain
    const yesPercentage = totalVotes > 0 ? Math.round((decision.vote_count_yes / totalVotes) * 100) : 0

    return (
      <Card className="flex flex-col">
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1 flex-1 min-w-0">
              <CardTitle className="text-xl break-words">{decision.title}</CardTitle>
              <div className="flex gap-2 flex-wrap">
                <Badge variant="outline">{decision.decision_type}</Badge>
                <Badge className={getStatusColor(decision.status)}>{t(`voting.status.${decision.status}`)}</Badge>
              </div>
            </div>
          </div>
          <CardDescription className="line-clamp-2">{decision.description}</CardDescription>
        </CardHeader>
        <CardContent className="flex-1">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={decision.proposer?.avatar_url || ""} />
                <AvatarFallback>{decision.proposer?.username?.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <span className="text-sm text-muted-foreground truncate">
                {t("common.proposedBy")} {decision.proposer?.full_name || decision.proposer?.username}
              </span>
            </div>
            {totalVotes > 0 && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{t("voting.votingResults")}</span>
                  <span className="font-semibold">
                    {yesPercentage}% {t("voting.inFavor")}
                  </span>
                </div>
                <div className="flex gap-2 text-xs flex-wrap">
                  <div className="flex items-center gap-1 text-green-600">
                    <CheckCircle2 className="h-3 w-3" />
                    <span>
                      {decision.vote_count_yes} {t("voting.vote.yes")}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-red-600">
                    <XCircle className="h-3 w-3" />
                    <span>
                      {decision.vote_count_no} {t("voting.vote.no")}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-600">
                    <Clock className="h-3 w-3" />
                    <span>
                      {decision.vote_count_abstain} {t("voting.vote.abstain")}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild className="w-full" variant={decision.status === "voting" ? "default" : "outline"}>
            <Link href={`/voting/decisions/${decision.id}`}>
              {decision.status === "voting" ? t("voting.voteNow") : t("common.viewDetails")}
            </Link>
          </Button>
        </CardFooter>
      </Card>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">{t("common.loading")}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container mx-auto max-w-7xl py-6 sm:py-8 px-4">
        <div className="mb-6 sm:mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{t("voting.title")}</h1>
            <p className="text-muted-foreground mt-2 text-sm sm:text-base">{t("voting.subtitle")}</p>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <Button asChild variant="outline" className="flex-1 sm:flex-initial bg-transparent">
              <Link href="/voting/polls/new">
                <Plus className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">{t("voting.newPoll")}</span>
                <span className="sm:hidden">Poll</span>
              </Link>
            </Button>
            <Button asChild className="flex-1 sm:flex-initial">
              <Link href="/voting/decisions/new">
                <Plus className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">{t("voting.proposeDecision")}</span>
                <span className="sm:hidden">Decision</span>
              </Link>
            </Button>
          </div>
        </div>

        <Tabs defaultValue="polls" className="space-y-6">
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="polls" className="flex-1 sm:flex-initial">
              {t("voting.activePolls")} ({activePolls?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="decisions" className="flex-1 sm:flex-initial">
              {t("voting.decisions")} ({decisions?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="polls" className="space-y-6">
            {!activePolls || activePolls.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 px-4">
                  <Vote className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">{t("voting.noPolls")}</h3>
                  <p className="text-sm text-muted-foreground mb-4 text-center">{t("voting.noPollsDesc")}</p>
                  <Button asChild>
                    <Link href="/voting/polls/new">{t("voting.createPoll")}</Link>
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
                {activePolls.map((poll) => (
                  <PollCard key={poll.id} poll={poll} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="decisions" className="space-y-6">
            {!decisions || decisions.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 px-4">
                  <CheckCircle2 className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">{t("voting.noDecisions")}</h3>
                  <p className="text-sm text-muted-foreground mb-4 text-center">{t("voting.noDecisionsDesc")}</p>
                  <Button asChild>
                    <Link href="/voting/decisions/new">{t("voting.proposeDecision")}</Link>
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
                {decisions.map((decision) => (
                  <DecisionCard key={decision.id} decision={decision} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
