import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { vote, comment } = body

    if (!vote || !["yes", "no", "abstain"].includes(vote)) {
      return NextResponse.json({ error: "Invalid vote" }, { status: 400 })
    }

    // Check if already voted
    const { data: existing } = await supabase
      .from("decision_votes")
      .select("*")
      .eq("decision_id", params.id)
      .eq("user_id", user.id)
      .maybeSingle()

    if (existing) {
      return NextResponse.json({ error: "Already voted" }, { status: 400 })
    }

    // Insert vote
    const { error: voteError } = await supabase.from("decision_votes").insert({
      decision_id: params.id,
      user_id: user.id,
      vote,
      comment: comment || null,
    })

    if (voteError) throw voteError

    // Update vote counts
    const { data: decision } = await supabase.from("decisions").select("*").eq("id", params.id).single()

    if (decision) {
      const updateField = vote === "yes" ? "vote_count_yes" : vote === "no" ? "vote_count_no" : "vote_count_abstain"

      await supabase
        .from("decisions")
        .update({ [updateField]: decision[updateField] + 1 })
        .eq("id", params.id)
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
