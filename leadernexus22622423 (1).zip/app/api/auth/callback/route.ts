import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")
  const origin = requestUrl.origin

  if (code) {
    const supabase = await createClient()
    const { data, error } = await supabase.auth.exchangeCodeForSession(code)

    if (error) {
      console.error("[v0] Auth callback error:", error)
      return NextResponse.redirect(`${origin}/auth/login?error=${error.message}`)
    }

    if (data.user) {
      // Check if profile exists, if not create it
      const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("id")
        .eq("id", data.user.id)
        .maybeSingle()

      if (!profile && !profileError) {
        // Create profile from user metadata
        const metadata = data.user.user_metadata
        const { error: insertError } = await supabase.from("profiles").insert({
          id: data.user.id,
          email: data.user.email!,
          username: metadata.username,
          full_name: metadata.full_name,
          role: metadata.role || "leader",
          district: metadata.district || null,
          direction: metadata.direction || null,
          points: 0,
          language: "uz",
        })

        if (insertError) {
          console.error("[v0] Error creating profile:", insertError)
        } else {
          console.log("[v0] Profile created successfully for user:", data.user.id)
        }

        if (metadata.role === "leader" && metadata.district && metadata.direction) {
          try {
            // Get district_id and direction_id
            const [districtResult, directionResult] = await Promise.all([
              supabase.from("districts").select("id").eq("name", metadata.district).single(),
              supabase.from("directions").select("id").eq("name", metadata.direction).single(),
            ])

            if (districtResult.data && directionResult.data) {
              const { error: ldError } = await supabase.from("leader_directions").insert({
                user_id: data.user.id,
                leader_id: data.user.id,
                district_id: districtResult.data.id,
                direction_id: directionResult.data.id,
              })

              if (ldError) {
                console.error("[v0] Error creating leader_directions entry:", ldError)
              } else {
                console.log("[v0] Leader direction assignment created for:", metadata.district, metadata.direction)
              }
            }
          } catch (ldError) {
            console.error("[v0] Error in leader_directions creation:", ldError)
          }
        }
      }
    }

    return NextResponse.redirect(`${origin}/dashboard`)
  }

  return NextResponse.redirect(`${origin}/auth/login`)
}
