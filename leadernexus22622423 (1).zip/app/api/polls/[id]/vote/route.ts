import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { option_ids } = body

    if (!option_ids || !Array.isArray(option_ids) || option_ids.length === 0) {
      return NextResponse.json({ error: "Invalid options" }, { status: 400 })
    }

    // Check if already voted
    const { data: existing } = await supabase
      .from("poll_votes")
      .select("*")
      .eq("poll_id", params.id)
      .eq("user_id", user.id)
      .maybeSingle()

    if (existing) {
      return NextResponse.json({ error: "Already voted" }, { status: 400 })
    }

    // Insert votes
    const votes = option_ids.map((optionId: string) => ({
      poll_id: params.id,
      option_id: optionId,
      user_id: user.id,
    }))

    const { error } = await supabase.from("poll_votes").insert(votes)

    if (error) throw error

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
