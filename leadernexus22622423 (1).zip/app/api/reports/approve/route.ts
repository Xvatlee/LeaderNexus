import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const { reportId, approverId } = await request.json()

    if (!reportId || !approverId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const supabase = await createServerClient()

    // Update report status
    const { error: updateError } = await supabase
      .from("reports")
      .update({
        status: "approved",
        reviewed_at: new Date().toISOString(),
        reviewed_by: approverId,
      })
      .eq("id", reportId)

    if (updateError) throw updateError

    // Get report details for notification
    const { data: report } = await supabase
      .from("reports")
      .select("user_id, title, districts(name)")
      .eq("id", reportId)
      .single()

    // Create notification
    if (report) {
      await supabase.from("notifications").insert({
        user_id: report.user_id,
        title: "Hisobotingiz tasdiqlandi",
        message: `"${report.title}" hisobotingiz viloyat sardori tomonidan tasdiqlandi.`,
        type: "report_approved",
        link: `/tuman/reports/${reportId}`,
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Error approving report:", error)
    return NextResponse.json({ error: "Failed to approve report" }, { status: 500 })
  }
}
