import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// POST /api/plans/[id]/tasks - Add a task to a plan
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id: plan_id } = params
    const body = await request.json()
    const { title, description, priority, due_date } = body

    if (!title) {
      return NextResponse.json({ error: "Task title is required" }, { status: 400 })
    }

    // Check if user can add tasks to this plan
    const { data: plan } = await supabase.from("plans").select("leader_id").eq("id", plan_id).single()

    if (!plan) {
      return NextResponse.json({ error: "Plan not found" }, { status: 404 })
    }

    const isOwner = plan.leader_id === user.id
    const { data: collaborator } = await supabase
      .from("plan_collaborators")
      .select("can_edit")
      .eq("plan_id", plan_id)
      .eq("collaborator_id", user.id)
      .single()

    if (!isOwner && (!collaborator || !collaborator.can_edit)) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const { data: task, error: taskError } = await supabase
      .from("plan_tasks")
      .insert({
        plan_id,
        title,
        description,
        priority: priority || "medium",
        due_date,
      })
      .select()
      .single()

    if (taskError) {
      console.error("[v0] Error creating task:", taskError)
      return NextResponse.json({ error: "Failed to create task" }, { status: 500 })
    }

    return NextResponse.json({ task }, { status: 201 })
  } catch (error) {
    console.error("[v0] Error in POST /api/plans/[id]/tasks:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
