import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// GET /api/plans/[id] - Get a specific plan with its tasks
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = params

    // Fetch plan with leader info and tasks
    const { data: plan, error: planError } = await supabase
      .from("plans")
      .select(
        `
        *,
        leader:profiles!leader_id(id, username, full_name, avatar_url),
        plan_tasks(*),
        plan_collaborators(*, collaborator:profiles!collaborator_id(id, username, full_name, avatar_url))
      `,
      )
      .eq("id", id)
      .single()

    if (planError) {
      console.error("[v0] Error fetching plan:", planError)
      return NextResponse.json({ error: "Plan not found" }, { status: 404 })
    }

    // Check if user has access (owner or collaborator)
    const hasAccess =
      plan.leader_id === user.id || plan.plan_collaborators?.some((c: any) => c.collaborator_id === user.id)

    if (!hasAccess) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    return NextResponse.json({ plan })
  } catch (error) {
    console.error("[v0] Error in GET /api/plans/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// PUT /api/plans/[id] - Update a plan
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = params
    const body = await request.json()
    const { title, description, start_date, end_date, status, notes } = body

    // Check if user can edit this plan
    const { data: plan } = await supabase.from("plans").select("leader_id").eq("id", id).single()

    if (!plan) {
      return NextResponse.json({ error: "Plan not found" }, { status: 404 })
    }

    // Check if user is owner or has edit permission
    const isOwner = plan.leader_id === user.id
    const { data: collaborator } = await supabase
      .from("plan_collaborators")
      .select("can_edit")
      .eq("plan_id", id)
      .eq("collaborator_id", user.id)
      .single()

    if (!isOwner && (!collaborator || !collaborator.can_edit)) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const updates: any = {}
    if (title !== undefined) updates.title = title
    if (description !== undefined) updates.description = description
    if (start_date !== undefined) updates.start_date = start_date
    if (end_date !== undefined) updates.end_date = end_date
    if (status !== undefined) updates.status = status
    if (notes !== undefined) updates.notes = notes

    const { data: updatedPlan, error: updateError } = await supabase
      .from("plans")
      .update(updates)
      .eq("id", id)
      .select()
      .single()

    if (updateError) {
      console.error("[v0] Error updating plan:", updateError)
      return NextResponse.json({ error: "Failed to update plan" }, { status: 500 })
    }

    return NextResponse.json({ plan: updatedPlan })
  } catch (error) {
    console.error("[v0] Error in PUT /api/plans/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// DELETE /api/plans/[id] - Delete a plan
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = params

    // Only plan owner can delete
    const { data: plan } = await supabase.from("plans").select("leader_id").eq("id", id).single()

    if (!plan) {
      return NextResponse.json({ error: "Plan not found" }, { status: 404 })
    }

    if (plan.leader_id !== user.id) {
      return NextResponse.json({ error: "Only plan owner can delete" }, { status: 403 })
    }

    const { error: deleteError } = await supabase.from("plans").delete().eq("id", id)

    if (deleteError) {
      console.error("[v0] Error deleting plan:", deleteError)
      return NextResponse.json({ error: "Failed to delete plan" }, { status: 500 })
    }

    return NextResponse.json({ message: "Plan deleted successfully" })
  } catch (error) {
    console.error("[v0] Error in DELETE /api/plans/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
