import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// GET /api/plans - List all plans for the authenticated user
export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const type = searchParams.get("type") // weekly, monthly, yearly
    const status = searchParams.get("status") // pending, in_progress, completed

    let query = supabase
      .from("plans")
      .select("*, plan_tasks(count)")
      .or(`leader_id.eq.${user.id},plan_collaborators.collaborator_id.eq.${user.id}`)
      .order("created_at", { ascending: false })

    if (type) {
      query = query.eq("plan_type", type)
    }

    if (status) {
      query = query.eq("status", status)
    }

    const { data: plans, error } = await query

    if (error) {
      console.error("[v0] Error fetching plans:", error)
      return NextResponse.json({ error: "Failed to fetch plans" }, { status: 500 })
    }

    return NextResponse.json({ plans: plans || [] })
  } catch (error) {
    console.error("[v0] Error in GET /api/plans:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// POST /api/plans - Create a new plan
export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user is a leader or admin
    const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

    if (!profile || !["leader", "admin"].includes(profile.role)) {
      return NextResponse.json({ error: "Only leaders can create plans" }, { status: 403 })
    }

    const body = await request.json()
    const { title, description, plan_type, start_date, end_date, tasks } = body

    if (!title || !plan_type || !start_date || !end_date) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create the plan
    const { data: plan, error: planError } = await supabase
      .from("plans")
      .insert({
        leader_id: user.id,
        title,
        description,
        plan_type,
        start_date,
        end_date,
        status: "pending",
      })
      .select()
      .single()

    if (planError) {
      console.error("[v0] Error creating plan:", planError)
      return NextResponse.json({ error: "Failed to create plan" }, { status: 500 })
    }

    // Create plan tasks if provided
    if (tasks && Array.isArray(tasks) && tasks.length > 0) {
      const planTasks = tasks.map((task: any) => ({
        plan_id: plan.id,
        title: task.title,
        description: task.description,
        priority: task.priority || "medium",
        due_date: task.due_date,
      }))

      const { error: tasksError } = await supabase.from("plan_tasks").insert(planTasks)

      if (tasksError) {
        console.error("[v0] Error creating plan tasks:", tasksError)
      }
    }

    return NextResponse.json({ plan }, { status: 201 })
  } catch (error) {
    console.error("[v0] Error in POST /api/plans:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
