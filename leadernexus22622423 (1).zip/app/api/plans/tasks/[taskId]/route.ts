import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// PUT /api/plans/tasks/[taskId] - Update a task
export async function PUT(request: NextRequest, { params }: { params: { taskId: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { taskId } = params
    const body = await request.json()
    const { title, description, status, priority, due_date } = body

    // Get task and verify access through plan
    const { data: task } = await supabase
      .from("plan_tasks")
      .select("*, plan:plans(leader_id)")
      .eq("id", taskId)
      .single()

    if (!task) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 })
    }

    const isOwner = task.plan.leader_id === user.id
    const { data: collaborator } = await supabase
      .from("plan_collaborators")
      .select("can_edit")
      .eq("plan_id", task.plan_id)
      .eq("collaborator_id", user.id)
      .single()

    if (!isOwner && (!collaborator || !collaborator.can_edit)) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const updates: any = {}
    if (title !== undefined) updates.title = title
    if (description !== undefined) updates.description = description
    if (status !== undefined) {
      updates.status = status
      if (status === "completed") {
        updates.completed_at = new Date().toISOString()
      }
    }
    if (priority !== undefined) updates.priority = priority
    if (due_date !== undefined) updates.due_date = due_date

    const { data: updatedTask, error: updateError } = await supabase
      .from("plan_tasks")
      .update(updates)
      .eq("id", taskId)
      .select()
      .single()

    if (updateError) {
      console.error("[v0] Error updating task:", updateError)
      return NextResponse.json({ error: "Failed to update task" }, { status: 500 })
    }

    return NextResponse.json({ task: updatedTask })
  } catch (error) {
    console.error("[v0] Error in PUT /api/plans/tasks/[taskId]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// DELETE /api/plans/tasks/[taskId] - Delete a task
export async function DELETE(request: NextRequest, { params }: { params: { taskId: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { taskId } = params

    // Get task and verify ownership
    const { data: task } = await supabase
      .from("plan_tasks")
      .select("*, plan:plans(leader_id)")
      .eq("id", taskId)
      .single()

    if (!task) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 })
    }

    if (task.plan.leader_id !== user.id) {
      return NextResponse.json({ error: "Only plan owner can delete tasks" }, { status: 403 })
    }

    const { error: deleteError } = await supabase.from("plan_tasks").delete().eq("id", taskId)

    if (deleteError) {
      console.error("[v0] Error deleting task:", deleteError)
      return NextResponse.json({ error: "Failed to delete task" }, { status: 500 })
    }

    return NextResponse.json({ message: "Task deleted successfully" })
  } catch (error) {
    console.error("[v0] Error in DELETE /api/plans/tasks/[taskId]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
