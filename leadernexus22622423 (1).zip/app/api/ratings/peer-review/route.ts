import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    // Check if user is a leader
    const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

    if (!profile || profile.role !== "leader") {
      return NextResponse.json({ error: "Only leaders can submit peer reviews" }, { status: 403 })
    }

    const body = await request.json()
    const {
      reviewee_id,
      period_id,
      leadership_rating,
      collaboration_rating,
      communication_rating,
      innovation_rating,
      overall_rating,
      positive_feedback,
      constructive_feedback,
      suggestions,
      is_anonymous,
    } = body

    // Validate required fields
    if (!reviewee_id || !period_id || !overall_rating) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Can't review yourself
    if (reviewee_id === user.id) {
      return NextResponse.json({ error: "You cannot review yourself" }, { status: 400 })
    }

    // Insert peer review
    const { data: review, error } = await supabase
      .from("peer_reviews")
      .upsert(
        {
          reviewer_id: user.id,
          reviewee_id,
          period_id,
          leadership_rating,
          collaboration_rating,
          communication_rating,
          innovation_rating,
          overall_rating,
          positive_feedback,
          constructive_feedback,
          suggestions,
          is_anonymous: is_anonymous || false,
          updated_at: new Date().toISOString(),
        },
        {
          onConflict: "reviewer_id,reviewee_id,period_id",
        },
      )
      .select()
      .single()

    if (error) {
      console.error("[v0] Error submitting peer review:", error)
      return NextResponse.json({ error: "Failed to submit review" }, { status: 500 })
    }

    return NextResponse.json({ success: true, review })
  } catch (error) {
    console.error("[v0] Error in POST /api/ratings/peer-review:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
