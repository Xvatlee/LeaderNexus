import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()

    const body = await request.json()
    const { sardor_id, rating, category, feedback_text, submitter_name, is_anonymous } = body

    // Validate required fields
    if (!sardor_id || !rating || !category || !feedback_text) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Insert community feedback
    const { data: feedback, error } = await supabase
      .from("community_feedback")
      .insert({
        sardor_id,
        rating,
        category,
        feedback_text,
        submitter_id: user?.id || null,
        submitter_name: is_anonymous ? "Anonim" : submitter_name,
        is_anonymous: is_anonymous || false,
        is_approved: true,
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Error submitting feedback:", error)
      return NextResponse.json({ error: "Failed to submit feedback" }, { status: 500 })
    }

    return NextResponse.json({ success: true, feedback })
  } catch (error) {
    console.error("[v0] Error in POST /api/ratings/community-feedback:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const supabase = await createClient()

    const { data: feedbacks, error } = await supabase
      .from("community_feedback")
      .select(`
        *,
        sardor:profiles!sardor_id(id, full_name, avatar_url, direction, district)
      `)
      .eq("is_approved", true)
      .order("created_at", { ascending: false })
      .limit(50)

    if (error) {
      console.error("[v0] Error fetching feedbacks:", error)
      return NextResponse.json({ error: "Failed to fetch feedbacks" }, { status: 500 })
    }

    return NextResponse.json({ feedbacks })
  } catch (error) {
    console.error("[v0] Error in GET /api/ratings/community-feedback:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
