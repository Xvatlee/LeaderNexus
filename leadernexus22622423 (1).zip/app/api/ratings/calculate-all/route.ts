import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const supabase = await createClient()

    // Verify user is admin
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

    if (!profile || profile.role !== "admin") {
      return NextResponse.json({ error: "Forbidden - Admin only" }, { status: 403 })
    }

    const body = await request.json()
    const { viloyatId, ratingPeriod } = body

    // Get all districts in the viloyat
    const { data: districts } = await supabase.from("tuman").select("id").eq("viloyat_id", viloyatId)

    if (!districts) {
      return NextResponse.json({ error: "No districts found" }, { status: 404 })
    }

    const results = []

    // Calculate rating for each district
    for (const district of districts) {
      try {
        const response = await fetch(`${request.url.replace("/calculate-all", "/calculate")}`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            tumanId: district.id,
            ratingPeriod,
          }),
        })

        if (response.ok) {
          const result = await response.json()
          results.push({ districtId: district.id, success: true, rating: result.rating })
        } else {
          results.push({ districtId: district.id, success: false, error: "Calculation failed" })
        }
      } catch (error) {
        results.push({ districtId: district.id, success: false, error: "Request failed" })
      }
    }

    return NextResponse.json({
      success: true,
      message: `Calculated ratings for ${results.filter((r) => r.success).length} districts`,
      results,
    })
  } catch (error) {
    console.error("[v0] Batch calculation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
