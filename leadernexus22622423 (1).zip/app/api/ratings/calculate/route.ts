import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { checkAdminAccess } from "@/lib/auth-utils"

// Calculate ratings for all sardors in a given period
export async function POST(request: NextRequest) {
  try {
    const { isAdmin, error: authError } = await checkAdminAccess()

    if (!isAdmin) {
      return NextResponse.json({ error: authError || "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { period_id } = body

    if (!period_id) {
      return NextResponse.json({ error: "period_id is required" }, { status: 400 })
    }

    const supabase = await createClient()

    // Get all leaders (sardors)
    const { data: sardors, error: sardorsError } = await supabase
      .from("profiles")
      .select("id, district, direction")
      .eq("role", "leader")
      .not("district", "is", null)
      .not("direction", "is", null)

    if (sardorsError) {
      console.error("[v0] Error fetching sardors:", sardorsError)
      return NextResponse.json({ error: "Failed to fetch sardors" }, { status: 500 })
    }

    // Get rating criteria with weights
    const { data: criteria, error: criteriaError } = await supabase
      .from("rating_criteria")
      .select("*")
      .eq("is_active", true)

    if (criteriaError) {
      console.error("[v0] Error fetching criteria:", criteriaError)
      return NextResponse.json({ error: "Failed to fetch criteria" }, { status: 500 })
    }

    const results = []

    for (const sardor of sardors) {
      // Calculate project score
      const { count: totalProjects } = await supabase
        .from("projects")
        .select("*", { count: "exact", head: true })
        .eq("creator_id", sardor.id)

      const { count: completedProjects } = await supabase
        .from("projects")
        .select("*", { count: "exact", head: true })
        .eq("creator_id", sardor.id)
        .eq("status", "completed")

      const projectScore = totalProjects ? (completedProjects / totalProjects) * 100 : 0

      // Calculate engagement score (based on collaborators and updates)
      const { count: totalCollaborators } = await supabase
        .from("project_collaborators")
        .select("*", { count: "exact", head: true })
        .eq("leader_id", sardor.id)

      const engagementScore = Math.min((totalCollaborators || 0) * 10, 100)

      // Calculate events score (based on posts in forum)
      const { count: totalPosts } = await supabase
        .from("posts")
        .select("*", { count: "exact", head: true })
        .eq("author_id", sardor.id)

      const eventsScore = Math.min((totalPosts || 0) * 5, 100)

      // Calculate leadership score from peer reviews
      const { data: peerReviews } = await supabase
        .from("peer_reviews")
        .select("overall_rating")
        .eq("reviewee_id", sardor.id)
        .eq("period_id", period_id)

      const avgPeerRating =
        peerReviews && peerReviews.length > 0
          ? (peerReviews.reduce((sum, r) => sum + r.overall_rating, 0) / peerReviews.length) * 20
          : 50

      // Calculate feedback score from community
      const { data: communityFeedback } = await supabase
        .from("community_feedback")
        .select("rating")
        .eq("sardor_id", sardor.id)
        .eq("is_approved", true)

      const avgCommunityRating =
        communityFeedback && communityFeedback.length > 0
          ? (communityFeedback.reduce((sum, f) => sum + f.rating, 0) / communityFeedback.length) * 20
          : 50

      // Calculate weighted total score
      const scores = {
        project_score: projectScore,
        engagement_score: engagementScore,
        events_score: eventsScore,
        leadership_score: avgPeerRating,
        feedback_score: avgCommunityRating,
      }

      const projectCriteria = criteria.find((c) => c.category === "projects")
      const engagementCriteria = criteria.find((c) => c.category === "engagement")
      const eventsCriteria = criteria.find((c) => c.category === "events")
      const leadershipCriteria = criteria.find((c) => c.category === "leadership")
      const feedbackCriteria = criteria.find((c) => c.category === "feedback")

      const weightedScore =
        (projectScore * (projectCriteria?.weight || 1) +
          engagementScore * (engagementCriteria?.weight || 1) +
          eventsScore * (eventsCriteria?.weight || 1) +
          avgPeerRating * (leadershipCriteria?.weight || 1) +
          avgCommunityRating * (feedbackCriteria?.weight || 1)) /
        ((projectCriteria?.weight || 1) +
          (engagementCriteria?.weight || 1) +
          (eventsCriteria?.weight || 1) +
          (leadershipCriteria?.weight || 1) +
          (feedbackCriteria?.weight || 1))

      // Upsert rating record
      const { data: rating, error: ratingError } = await supabase
        .from("sardor_ratings")
        .upsert(
          {
            sardor_id: sardor.id,
            period_id: period_id,
            district_id: sardor.district,
            direction_id: sardor.direction,
            ...scores,
            total_score: Object.values(scores).reduce((sum, s) => sum + s, 0) / 5,
            weighted_score: weightedScore,
            total_projects: totalProjects || 0,
            completed_projects: completedProjects || 0,
            total_events: totalPosts || 0,
            community_feedback_count: communityFeedback?.length || 0,
            updated_at: new Date().toISOString(),
          },
          {
            onConflict: "sardor_id,period_id",
          },
        )
        .select()
        .single()

      if (ratingError) {
        console.error("[v0] Error upserting rating:", ratingError)
        continue
      }

      results.push(rating)
    }

    // Update ranks
    await updateRanks(period_id)

    return NextResponse.json({
      success: true,
      message: `Calculated ratings for ${results.length} sardors`,
      ratings: results,
    })
  } catch (error) {
    console.error("[v0] Error in POST /api/ratings/calculate:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function updateRanks(period_id: string) {
  const supabase = await createClient()

  // Update overall ranks
  const { data: allRatings } = await supabase
    .from("sardor_ratings")
    .select("id, weighted_score, district_id")
    .eq("period_id", period_id)
    .order("weighted_score", { ascending: false })

  if (allRatings) {
    for (let i = 0; i < allRatings.length; i++) {
      await supabase
        .from("sardor_ratings")
        .update({ rank_overall: i + 1 })
        .eq("id", allRatings[i].id)
    }
  }

  // Update district ranks
  const { data: districts } = await supabase.from("districts").select("id")

  if (districts) {
    for (const district of districts) {
      const { data: districtRatings } = await supabase
        .from("sardor_ratings")
        .select("id, weighted_score")
        .eq("period_id", period_id)
        .eq("district_id", district.id)
        .order("weighted_score", { ascending: false })

      if (districtRatings) {
        for (let i = 0; i < districtRatings.length; i++) {
          await supabase
            .from("sardor_ratings")
            .update({ rank_in_district: i + 1 })
            .eq("id", districtRatings[i].id)
        }
      }
    }
  }
}
