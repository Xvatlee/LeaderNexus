import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    // Get current active monthly period
    const { data: period } = await supabase
      .from("rating_periods")
      .select("id")
      .eq("period_type", "monthly")
      .eq("is_active", true)
      .single()

    if (!period) {
      return NextResponse.json({ error: "No active rating period" }, { status: 404 })
    }

    const { data: rating, error } = await supabase
      .from("sardor_ratings")
      .select(`
        *,
        rating_details(
          *,
          criteria:rating_criteria(*)
        ),
        district:districts!district_id(id, name),
        direction:directions!direction_id(id, name)
      `)
      .eq("sardor_id", user.id)
      .eq("period_id", period.id)
      .single()

    if (error) {
      console.error("[v0] Error fetching rating:", error)
      return NextResponse.json({ error: "Rating not found" }, { status: 404 })
    }

    // Get peer reviews summary
    const { data: peerReviews } = await supabase
      .from("peer_reviews")
      .select("overall_rating")
      .eq("reviewee_id", user.id)
      .eq("period_id", period.id)

    const avgPeerRating =
      peerReviews && peerReviews.length > 0
        ? peerReviews.reduce((sum, r) => sum + r.overall_rating, 0) / peerReviews.length
        : null

    return NextResponse.json({
      rating: {
        ...rating,
        peer_reviews_received: peerReviews?.length || 0,
        average_peer_rating: avgPeerRating,
      },
      period,
    })
  } catch (error) {
    console.error("[v0] Error in GET /api/ratings/my-rating:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
