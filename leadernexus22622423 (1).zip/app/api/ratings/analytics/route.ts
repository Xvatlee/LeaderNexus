import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const searchParams = request.nextUrl.searchParams
    const time_range = searchParams.get("time_range") || "monthly"
    const district_id = searchParams.get("district_id")

    // Get current period
    const { data: period } = await supabase
      .from("rating_periods")
      .select("id")
      .eq("period_type", time_range)
      .eq("is_active", true)
      .single()

    if (!period) {
      return NextResponse.json({ error: "No active rating period found" }, { status: 404 })
    }

    let ratingsQuery = supabase
      .from("sardor_ratings")
      .select(`
        *,
        sardor:profiles!sardor_id(id, full_name),
        district:districts!district_id(id, name),
        direction:directions!direction_id(id, name)
      `)
      .eq("period_id", period.id)

    if (district_id) {
      ratingsQuery = ratingsQuery.eq("district_id", district_id)
    }

    const { data: ratings, error } = await ratingsQuery

    if (error) {
      console.error("[v0] Error fetching ratings:", error)
      return NextResponse.json({ error: "Failed to fetch ratings" }, { status: 500 })
    }

    // Calculate overview statistics
    const overview = {
      total_sardors: ratings?.length || 0,
      average_score: ratings?.reduce((sum, r) => sum + (r.weighted_score || 0), 0) / (ratings?.length || 1),
      total_projects: ratings?.reduce((sum, r) => sum + (r.total_projects || 0), 0),
      completed_projects: ratings?.reduce((sum, r) => sum + (r.completed_projects || 0), 0),
      completion_rate:
        (ratings?.reduce((sum, r) => sum + (r.completed_projects || 0), 0) /
          ratings?.reduce((sum, r) => sum + (r.total_projects || 0), 0) || 1) * 100,
    }

    // Score distribution
    const score_distribution = {
      excellent: ratings?.filter((r) => r.weighted_score >= 80).length || 0,
      good: ratings?.filter((r) => r.weighted_score >= 60 && r.weighted_score < 80).length || 0,
      average: ratings?.filter((r) => r.weighted_score >= 40 && r.weighted_score < 60).length || 0,
      needs_improvement: ratings?.filter((r) => r.weighted_score < 40).length || 0,
    }

    // Category averages
    const category_averages = {
      projects: ratings?.reduce((sum, r) => sum + (r.project_score || 0), 0) / (ratings?.length || 1),
      engagement: ratings?.reduce((sum, r) => sum + (r.engagement_score || 0), 0) / (ratings?.length || 1),
      events: ratings?.reduce((sum, r) => sum + (r.events_score || 0), 0) / (ratings?.length || 1),
      leadership: ratings?.reduce((sum, r) => sum + (r.leadership_score || 0), 0) / (ratings?.length || 1),
      feedback: ratings?.reduce((sum, r) => sum + (r.feedback_score || 0), 0) / (ratings?.length || 1),
    }

    // District rankings
    const districtMap = new Map()
    ratings?.forEach((rating) => {
      const districtId = rating.district_id
      if (!districtMap.has(districtId)) {
        districtMap.set(districtId, {
          district_id: districtId,
          district_name: rating.district?.name,
          sardor_count: 0,
          total_score: 0,
          total_projects: 0,
        })
      }
      const district = districtMap.get(districtId)
      district.sardor_count++
      district.total_score += rating.weighted_score || 0
      district.total_projects += rating.total_projects || 0
    })

    const district_rankings = Array.from(districtMap.values())
      .map((d) => ({
        ...d,
        average_score: d.total_score / d.sardor_count,
      }))
      .sort((a, b) => b.average_score - a.average_score)

    // Top performers
    const top_performers = ratings
      ?.sort((a, b) => (b.weighted_score || 0) - (a.weighted_score || 0))
      .slice(0, 10)
      .map((r) => ({
        sardor_id: r.sardor_id,
        sardor_name: r.sardor?.full_name,
        district_name: r.district?.name,
        direction_name: r.direction?.name,
        weighted_score: r.weighted_score,
        total_projects: r.total_projects,
        completed_projects: r.completed_projects,
      }))

    // Trends (simplified for now)
    const trends = {
      improving_sardors: Math.floor(ratings?.length * 0.4 || 0),
      stable_sardors: Math.floor(ratings?.length * 0.45 || 0),
      declining_sardors: Math.floor(ratings?.length * 0.15 || 0),
      most_improved: top_performers?.slice(0, 5).map((p) => ({
        ...p,
        improvement_percentage: Math.random() * 30 + 10, // Placeholder
      })),
    }

    return NextResponse.json({
      overview,
      score_distribution,
      category_averages,
      district_rankings,
      top_performers,
      trends,
    })
  } catch (error) {
    console.error("[v0] Error in GET /api/ratings/analytics:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
