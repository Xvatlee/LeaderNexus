import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const searchParams = request.nextUrl.searchParams
    const period_type = searchParams.get("period_type") || "monthly"
    const district_id = searchParams.get("district_id")
    const limit = Number.parseInt(searchParams.get("limit") || "20")

    // Get current active period
    const { data: period } = await supabase
      .from("rating_periods")
      .select("id")
      .eq("period_type", period_type)
      .eq("is_active", true)
      .single()

    if (!period) {
      return NextResponse.json({ error: "No active rating period found" }, { status: 404 })
    }

    let query = supabase
      .from("sardor_ratings")
      .select(`
        *,
        sardor:profiles!sardor_id(id, username, full_name, avatar_url, district, direction),
        district:districts!district_id(id, name),
        direction:directions!direction_id(id, name)
      `)
      .eq("period_id", period.id)
      .eq("is_finalized", true)
      .order("weighted_score", { ascending: false })
      .limit(limit)

    if (district_id) {
      query = query.eq("district_id", district_id)
    }

    const { data: leaderboard, error } = await query

    if (error) {
      console.error("[v0] Error fetching leaderboard:", error)
      return NextResponse.json({ error: "Failed to fetch leaderboard" }, { status: 500 })
    }

    return NextResponse.json({ leaderboard, period })
  } catch (error) {
    console.error("[v0] Error in GET /api/ratings/leaderboard:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
