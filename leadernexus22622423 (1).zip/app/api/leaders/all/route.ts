import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = await createClient()

    const { data: leaders, error } = await supabase
      .from("profiles")
      .select(`
        id,
        username,
        full_name,
        avatar_url,
        district,
        direction,
        districts:district(name_uz),
        directions:direction(name_uz)
      `)
      .eq("role", "leader")
      .not("district", "is", null)
      .not("direction", "is", null)
      .order("full_name")

    if (error) {
      console.error("[v0] Error fetching leaders:", error)
      return NextResponse.json({ error: "Failed to fetch leaders" }, { status: 500 })
    }

    return NextResponse.json({ leaders })
  } catch (error) {
    console.error("[v0] Error in GET /api/leaders/all:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
