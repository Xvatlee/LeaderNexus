import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { createClient as createAdminClient } from "@supabase/supabase-js"
import { sendAdminRequestEmail } from "@/lib/email"
import { randomBytes, createHash } from "crypto"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user profile
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single()

    if (profileError || !profile) {
      return NextResponse.json({ error: "Profile not found" }, { status: 404 })
    }

    // Check if user is already an admin
    const { data: existingAdmin } = await supabase.from("admins").select("user_id").eq("user_id", user.id).maybeSingle()

    if (existingAdmin) {
      return NextResponse.json({ error: "You are already an admin" }, { status: 400 })
    }

    // Check for existing pending request
    const { data: pendingRequest } = await supabase
      .from("admin_requests")
      .select("*")
      .eq("user_id", user.id)
      .eq("status", "pending")
      .maybeSingle()

    if (pendingRequest) {
      return NextResponse.json({ error: "You already have a pending admin request" }, { status: 400 })
    }

    const { reason } = await request.json()

    // Generate secure token for approval links
    const token = randomBytes(32).toString("hex")
    const tokenHash = createHash("sha256").update(token).digest("hex")
    const tokenExpiresAt = new Date(Date.now() + 60 * 60 * 1000) // 60 minutes

    // Create admin request using service role (to bypass RLS for token fields)
    const adminClient = createAdminClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    const { data: adminRequest, error: insertError } = await adminClient
      .from("admin_requests")
      .insert({
        user_id: user.id,
        email: user.email!,
        reason: reason || null,
        status: "pending",
        token_hash: tokenHash,
        token_expires_at: tokenExpiresAt.toISOString(),
      })
      .select()
      .single()

    if (insertError) {
      console.error("[v0] Error creating admin request:", insertError)
      return NextResponse.json({ error: "Failed to create admin request" }, { status: 500 })
    }

    // Send email notification to super admin
    await sendAdminRequestEmail({
      requesterEmail: user.email!,
      requesterName: profile.full_name || user.email!,
      reason: reason || "",
      requestId: adminRequest.id,
      approvalToken: token,
    })

    return NextResponse.json({
      success: true,
      message: "Admin request submitted successfully. The super admin will review your request.",
      request: adminRequest,
    })
  } catch (error) {
    console.error("[v0] Error in admin request submission:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user's admin request status
    const { data: request, error } = await supabase
      .from("admin_requests")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle()

    if (error) {
      console.error("[v0] Error fetching admin request:", error)
      return NextResponse.json({ error: "Failed to fetch admin request" }, { status: 500 })
    }

    // Check if user is admin
    const { data: isAdmin } = await supabase.from("admins").select("user_id").eq("user_id", user.id).maybeSingle()

    return NextResponse.json({
      request: request || null,
      isAdmin: !!isAdmin,
    })
  } catch (error) {
    console.error("[v0] Error in admin request fetch:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
