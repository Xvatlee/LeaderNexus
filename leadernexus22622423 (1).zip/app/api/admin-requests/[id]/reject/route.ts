import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { createHash } from "crypto"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const searchParams = request.nextUrl.searchParams
    const token = searchParams.get("token")
    const requestId = params.id

    if (!token) {
      return new NextResponse("Missing approval token", { status: 400 })
    }

    // Use service role client to bypass RLS
    const adminClient = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    // Get the admin request
    const { data: adminRequest, error: fetchError } = await adminClient
      .from("admin_requests")
      .select("*")
      .eq("id", requestId)
      .single()

    if (fetchError || !adminRequest) {
      return new NextResponse("Admin request not found", { status: 404 })
    }

    // Validate token
    const tokenHash = createHash("sha256").update(token).digest("hex")

    if (adminRequest.token_hash !== tokenHash) {
      return new NextResponse("Invalid approval token", { status: 403 })
    }

    // Check token expiry
    if (new Date(adminRequest.token_expires_at) < new Date()) {
      return new NextResponse("Approval token has expired", { status: 403 })
    }

    // Check if already processed
    if (adminRequest.status !== "pending") {
      return new NextResponse(`Request already ${adminRequest.status}`, { status: 400 })
    }

    // Update request status to rejected
    const { error: updateError } = await adminClient
      .from("admin_requests")
      .update({
        status: "rejected",
        reviewed_at: new Date().toISOString(),
        reviewed_by: null, // Token-based rejection
      })
      .eq("id", requestId)

    if (updateError) {
      console.error("[v0] Error updating request status:", updateError)
      return new NextResponse("Failed to reject request", { status: 500 })
    }

    // Return success HTML page
    return new NextResponse(
      `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Admin Request Rejected</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; text-align: center; }
            .rejected { color: #dc2626; font-size: 24px; font-weight: bold; margin-bottom: 20px; }
            .message { color: #374151; margin-bottom: 30px; }
            a { color: #16a34a; text-decoration: none; }
          </style>
        </head>
        <body>
          <div class="rejected">✗ Admin Request Rejected</div>
          <div class="message">
            The admin request has been rejected.<br>
            The user will remain as a regular leader.
          </div>
          <a href="/">Return to Home</a>
        </body>
      </html>
      `,
      {
        status: 200,
        headers: { "Content-Type": "text/html" },
      },
    )
  } catch (error) {
    console.error("[v0] Error rejecting admin request:", error)
    return new NextResponse("Internal server error", { status: 500 })
  }
}
