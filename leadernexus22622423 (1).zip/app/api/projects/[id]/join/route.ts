import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Check if already a collaborator
    const { data: existing } = await supabase
      .from("project_collaborators")
      .select("*")
      .eq("project_id", params.id)
      .eq("user_id", user.id)
      .maybeSingle()

    if (existing) {
      return NextResponse.json({ error: "Already a collaborator" }, { status: 400 })
    }

    // Add as collaborator
    const { error } = await supabase.from("project_collaborators").insert({
      project_id: params.id,
      user_id: user.id,
      role: "supporter",
    })

    if (error) throw error

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
