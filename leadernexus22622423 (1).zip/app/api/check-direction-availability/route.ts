import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { district, direction } = await request.json()

    if (!district || !direction) {
      return NextResponse.json({ error: "District and direction are required" }, { status: 400 })
    }

    const supabase = await createClient()

    // First get the district_id and direction_id
    const [districtResult, directionResult] = await Promise.all([
      supabase.from("districts").select("id").eq("name", district).single(),
      supabase.from("directions").select("id").eq("name", direction).single(),
    ])

    if (districtResult.error || directionResult.error) {
      console.error("[v0] Error fetching IDs:", { districtResult, directionResult })
      return NextResponse.json({ error: "Invalid district or direction" }, { status: 400 })
    }

    const districtId = districtResult.data?.id
    const directionId = directionResult.data?.id

    const { data: existingLeader, error: leaderError } = await supabase
      .from("leader_directions")
      .select("user_id, leader_id")
      .eq("district_id", districtId)
      .eq("direction_id", directionId)
      .maybeSingle()

    if (leaderError) {
      console.error("[v0] Error checking leader_directions:", leaderError)
      // If table doesn't exist or query fails, just allow registration
      console.log("[v0] leader_directions check failed, allowing registration")
      return NextResponse.json({ available: true })
    }

    if (existingLeader) {
      const { data: userData } = await supabase.auth.admin.getUserById(
        existingLeader.user_id || existingLeader.leader_id,
      )

      const leaderName =
        userData?.user?.user_metadata?.full_name || userData?.user?.user_metadata?.username || "Noma'lum foydalanuvchi"

      console.log("[v0] Direction already taken by:", leaderName)
      return NextResponse.json({
        available: false,
        message: `Bu yo'nalish ${district} tumanida allaqachon ${leaderName} tomonidan band qilingan`,
        takenBy: {
          id: existingLeader.user_id || existingLeader.leader_id,
          full_name: leaderName,
        },
      })
    }

    console.log("[v0] Direction is available for:", { district, direction })
    return NextResponse.json({ available: true })
  } catch (error) {
    console.error("[v0] Error in check-direction-availability:", error)
    // On any error, allow registration to proceed
    return NextResponse.json({ available: true })
  }
}
