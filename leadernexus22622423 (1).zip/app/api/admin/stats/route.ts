import { NextResponse } from "next/server"
import { checkAdminAccess } from "@/lib/auth-utils"
import { createClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const { isAdmin, error: authError } = await checkAdminAccess()

    if (!isAdmin) {
      return NextResponse.json({ error: authError || "Unauthorized" }, { status: 403 })
    }

    const supabase = await createClient()

    const { count: totalUsers } = await supabase.from("profiles").select("*", { count: "exact", head: true })

    const { count: activeUsers } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("status", "active")

    const { count: suspendedUsers } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("status", "suspended")

    const { count: adminCount } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("role", "admin")

    return NextResponse.json({
      stats: {
        totalUsers: totalUsers || 0,
        activeUsers: activeUsers || 0,
        suspendedUsers: suspendedUsers || 0,
        adminCount: adminCount || 0,
      },
    })
  } catch (error) {
    console.error("[v0] Error in GET /api/admin/stats:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
