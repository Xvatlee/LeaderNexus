import { type NextRequest, NextResponse } from "next/server"
import { checkAdminAccess } from "@/lib/auth-utils"
import { createClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"

// GET single user
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { isAdmin, error: authError } = await checkAdminAccess()

    if (!isAdmin) {
      return NextResponse.json({ error: authError || "Unauthorized" }, { status: 403 })
    }

    const supabase = await createClient()
    const { data: user, error } = await supabase.from("profiles").select("*").eq("id", id).single()

    if (error) {
      console.error("[v0] Error fetching user:", error)
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error("[v0] Error in GET /api/admin/users/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// PATCH update user
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { isAdmin, error: authError } = await checkAdminAccess()

    if (!isAdmin) {
      return NextResponse.json({ error: authError || "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { role, status, full_name } = body

    const supabase = await createClient()

    // Build update object
    const updates: Record<string, any> = {}
    if (role !== undefined) updates.role = role
    if (status !== undefined) updates.status = status
    if (full_name !== undefined) updates.full_name = full_name

    const { data: user, error } = await supabase.from("profiles").update(updates).eq("id", id).select().single()

    if (error) {
      console.error("[v0] Error updating user:", error)
      return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
    }

    return NextResponse.json({ user, message: "User updated successfully" })
  } catch (error) {
    console.error("[v0] Error in PATCH /api/admin/users/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// DELETE user
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { isAdmin, user, error: authError } = await checkAdminAccess()

    if (!isAdmin) {
      return NextResponse.json({ error: authError || "Unauthorized" }, { status: 403 })
    }

    // Prevent admin from deleting themselves
    if (user?.id === id) {
      return NextResponse.json({ error: "Cannot delete your own account" }, { status: 400 })
    }

    // Use admin client to delete auth user (which cascades to profiles)
    const adminClient = createAdminClient()
    const { error } = await adminClient.auth.admin.deleteUser(id)

    if (error) {
      console.error("[v0] Error deleting user:", error)
      return NextResponse.json({ error: "Failed to delete user" }, { status: 500 })
    }

    return NextResponse.json({ message: "User deleted successfully" })
  } catch (error) {
    console.error("[v0] Error in DELETE /api/admin/users/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
