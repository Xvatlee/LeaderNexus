import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    console.log("[v0] Media upload API called")

    // Verify authentication
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      console.log("[v0] Unauthorized upload attempt")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    console.log("[v0] User authenticated:", user.id)

    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      console.log("[v0] No file provided")
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    console.log("[v0] File received:", file.name, "Size:", file.size, "Type:", file.type)

    // Validate file size (50MB max)
    const MAX_FILE_SIZE = 50 * 1024 * 1024
    if (file.size > MAX_FILE_SIZE) {
      console.log("[v0] File too large:", file.size)
      return NextResponse.json({ error: "File size exceeds 50MB limit" }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/gif",
      "image/webp",
      "video/mp4",
      "video/webm",
      "video/quicktime",
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ]

    if (!allowedTypes.includes(file.type)) {
      console.log("[v0] Unsupported file type:", file.type)
      return NextResponse.json({ error: "File type not supported" }, { status: 400 })
    }

    // Sanitize filename - remove all special characters and non-ASCII
    const timestamp = Date.now()
    const sanitizedName = file.name
      .replace(/[^a-zA-Z0-9.-]/g, "_")
      .replace(/_{2,}/g, "_")
      .substring(0, 100)

    const fileName = `${timestamp}-${sanitizedName}`
    const filePath = `media/${user.id}/${fileName}`

    console.log("[v0] Uploading to path:", filePath)

    const fileBuffer = await file.arrayBuffer()

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("media-files")
      .upload(filePath, fileBuffer, {
        contentType: file.type,
        cacheControl: "3600",
        upsert: false,
      })

    if (uploadError) {
      console.error("[v0] Upload error:", uploadError)
      if (uploadError.message?.includes("not found") || uploadError.message?.includes("Bucket")) {
        return NextResponse.json(
          {
            error: "Storage bucket not configured. Please run database setup scripts first (script 018).",
          },
          { status: 500 },
        )
      }
      return NextResponse.json({ error: uploadError.message || "Failed to upload file" }, { status: 500 })
    }

    console.log("[v0] File uploaded successfully:", uploadData.path)

    // Get public URL
    const {
      data: { publicUrl },
    } = supabase.storage.from("media-files").getPublicUrl(filePath)

    console.log("[v0] Public URL generated:", publicUrl)

    return NextResponse.json({
      url: publicUrl,
      downloadUrl: publicUrl,
      pathname: filePath,
      contentType: file.type,
      size: file.size,
    })
  } catch (error) {
    console.error("[v0] Media upload error:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Failed to upload file",
      },
      { status: 500 },
    )
  }
}
