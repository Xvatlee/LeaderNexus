"use client"

import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Clock, CheckCircle2, XCircle, AlertCircle, Shield } from "lucide-react"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { useEffect, useState } from "react"
import type { Profile } from "@/lib/types"
import { AdminRequestApprovalDialog } from "@/components/admin/admin-request-approval-dialog"

interface AdminRequest {
  id: string
  user_id: string
  reason: string | null
  status: "pending" | "approved" | "rejected"
  rejection_reason: string | null
  created_at: string
  reviewed_at: string | null
  reviewed_by: string | null
  approval_token: string
  profiles: {
    username: string
    full_name: string
    email: string
  }
}

export default function AdminRequestsPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [requests, setRequests] = useState<AdminRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedRequest, setSelectedRequest] = useState<AdminRequest | null>(null)
  const [actionType, setActionType] = useState<"approve" | "reject" | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      if (!userProfile || userProfile.role !== "admin") {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      const { data: adminRequests, error: requestsError } = await supabase
        .from("admin_requests")
        .select(
          `
          *,
          profiles:user_id (
            username,
            full_name,
            email
          )
        `,
        )
        .order("created_at", { ascending: false })

      if (requestsError) throw requestsError

      setRequests(adminRequests || [])
    } catch (err) {
      console.error("Error loading admin requests:", err)
      setError("Failed to load admin requests")
    } finally {
      setLoading(false)
    }
  }

  const handleOpenDialog = (request: AdminRequest, action: "approve" | "reject") => {
    setSelectedRequest(request)
    setActionType(action)
  }

  const handleCloseDialog = () => {
    setSelectedRequest(null)
    setActionType(null)
  }

  const handleSuccess = () => {
    handleCloseDialog()
    loadData()
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Approved
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <XCircle className="h-3 w-3 mr-1" />
            Rejected
          </Badge>
        )
      default:
        return null
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Admin Access Requests</h1>
            <p className="text-muted-foreground mt-2">Review and manage requests for admin privileges</p>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {requests.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No admin access requests found</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {requests.map((request) => (
                <Card key={request.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-lg">
                          {request.profiles.full_name || request.profiles.username}
                        </CardTitle>
                        <CardDescription className="space-y-1">
                          <div>@{request.profiles.username}</div>
                          <div className="text-sm">{request.profiles.email}</div>
                        </CardDescription>
                      </div>
                      {getStatusBadge(request.status)}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {request.reason && (
                      <div>
                        <p className="text-sm font-medium mb-1">Reason:</p>
                        <p className="text-sm text-muted-foreground">{request.reason}</p>
                      </div>
                    )}

                    {request.rejection_reason && (
                      <div>
                        <p className="text-sm font-medium mb-1 text-red-600">Rejection Reason:</p>
                        <p className="text-sm text-red-600">{request.rejection_reason}</p>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div>
                        <span className="font-medium">Submitted:</span> {new Date(request.created_at).toLocaleString()}
                      </div>
                      {request.reviewed_at && (
                        <div>
                          <span className="font-medium">Reviewed:</span>{" "}
                          {new Date(request.reviewed_at).toLocaleString()}
                        </div>
                      )}
                    </div>

                    {request.status === "pending" && (
                      <div className="flex gap-2 pt-2">
                        <Button
                          onClick={() => handleOpenDialog(request, "approve")}
                          variant="default"
                          className="flex-1 bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle2 className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button
                          onClick={() => handleOpenDialog(request, "reject")}
                          variant="destructive"
                          className="flex-1"
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>

      {selectedRequest && actionType && (
        <AdminRequestApprovalDialog
          request={selectedRequest}
          actionType={actionType}
          onClose={handleCloseDialog}
          onSuccess={handleSuccess}
        />
      )}
    </div>
  )
}
