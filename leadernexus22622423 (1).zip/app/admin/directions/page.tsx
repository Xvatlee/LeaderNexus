"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, Compass, Users } from "lucide-react"
import type { Profile } from "@/lib/types"

interface Direction {
  id: string
  name: string
  description: string | null
  is_active: boolean
  created_at: string
  leader_count: number
}

export default function AdminDirectionsPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [directions, setDirections] = useState<Direction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    const supabase = createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      redirect("/auth/login")
      return
    }

    const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

    if (!userProfile || userProfile.role !== "admin") {
      redirect("/dashboard")
      return
    }

    setProfile(userProfile)

    const { data: directionsData } = await supabase.from("directions").select("*").order("name")

    const directionsWithCounts = await Promise.all(
      (directionsData || []).map(async (direction) => {
        const { count } = await supabase
          .from("leader_directions")
          .select("*", { count: "exact", head: true })
          .eq("direction_id", direction.id)

        return {
          ...direction,
          leader_count: count || 0,
        }
      }),
    )

    setDirections(directionsWithCounts)
    setLoading(false)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Directions (9 Yo'nalish)</h1>
            <p className="text-muted-foreground mt-2">View all leadership directions and assigned leaders</p>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Directions</CardTitle>
                <Compass className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{directions.length}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Directions</CardTitle>
                <Compass className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{directions.filter((d) => d.is_active).length}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Assigned Leaders</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{directions.reduce((sum, d) => sum + d.leader_count, 0)}</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {directions.map((direction) => (
              <Card key={direction.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-lg">{direction.name}</CardTitle>
                    <Badge variant={direction.is_active ? "default" : "secondary"}>
                      {direction.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  {direction.description && (
                    <CardDescription className="text-sm">{direction.description}</CardDescription>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>
                      {direction.leader_count} leader{direction.leader_count !== 1 ? "s" : ""}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {directions.length === 0 && (
            <Card>
              <CardContent className="text-center py-12 text-muted-foreground">
                <Compass className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No directions found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
