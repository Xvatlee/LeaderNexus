"use client"

import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, UserCheck, UserX, ShieldCheck, Clock } from "lucide-react"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import UserManagementTable from "@/components/admin/user-management-table"
import { useEffect, useState } from "react"
import type { Profile } from "@/lib/types"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AdminPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    suspendedUsers: 0,
    adminCount: 0,
    pendingRequests: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      if (!userProfile || userProfile.role !== "admin") {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      const { count: totalUsers } = await supabase.from("profiles").select("*", { count: "exact", head: true })

      const { count: activeUsers } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .eq("status", "active")

      const { count: suspendedUsers } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .eq("status", "suspended")

      const { count: adminCount } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .eq("role", "admin")

      const { count: pendingRequests } = await supabase
        .from("admin_requests")
        .select("*", { count: "exact", head: true })
        .eq("status", "pending")

      setStats({
        totalUsers: totalUsers || 0,
        activeUsers: activeUsers || 0,
        suspendedUsers: suspendedUsers || 0,
        adminCount: adminCount || 0,
        pendingRequests: pendingRequests || 0,
      })

      setLoading(false)
    }

    loadData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-6 sm:py-8 px-4">
        <div className="space-y-6 sm:space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">Admin Panel</h1>
              <p className="text-sm sm:text-base text-muted-foreground mt-1 sm:mt-2">
                Manage users and monitor platform activity
              </p>
            </div>
            {stats.pendingRequests > 0 && (
              <Link href="/admin/requests" className="w-full sm:w-auto">
                <Button variant="outline" className="gap-2 bg-transparent w-full sm:w-auto">
                  <Clock className="h-4 w-4" />
                  {stats.pendingRequests} Pending Request{stats.pendingRequests !== 1 ? "s" : ""}
                </Button>
              </Link>
            )}
          </div>

          <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-4 sm:p-6 sm:pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium">Total Users</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent className="p-4 pt-0 sm:p-6 sm:pt-0">
                <div className="text-xl sm:text-2xl font-bold">{stats.totalUsers}</div>
                <p className="text-xs text-muted-foreground hidden sm:block">Registered accounts</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-4 sm:p-6 sm:pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium">Active Users</CardTitle>
                <UserCheck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent className="p-4 pt-0 sm:p-6 sm:pt-0">
                <div className="text-xl sm:text-2xl font-bold">{stats.activeUsers}</div>
                <p className="text-xs text-muted-foreground hidden sm:block">Active accounts</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-4 sm:p-6 sm:pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium">Suspended</CardTitle>
                <UserX className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent className="p-4 pt-0 sm:p-6 sm:pt-0">
                <div className="text-xl sm:text-2xl font-bold">{stats.suspendedUsers}</div>
                <p className="text-xs text-muted-foreground hidden sm:block">Suspended accounts</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-4 sm:p-6 sm:pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium">Admins</CardTitle>
                <ShieldCheck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent className="p-4 pt-0 sm:p-6 sm:pt-0">
                <div className="text-xl sm:text-2xl font-bold">{stats.adminCount}</div>
                <p className="text-xs text-muted-foreground hidden sm:block">Admin accounts</p>
              </CardContent>
            </Card>
          </div>

          {stats.pendingRequests > 0 && (
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-yellow-900">
                  <Clock className="h-5 w-5" />
                  Pending Admin Requests
                </CardTitle>
                <CardDescription className="text-yellow-800">
                  {stats.pendingRequests} user{stats.pendingRequests !== 1 ? "s" : ""} waiting for admin access approval
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/admin/requests">
                  <Button className="w-full sm:w-auto">Review Requests</Button>
                </Link>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader className="px-4 sm:px-6">
              <CardTitle className="text-lg sm:text-xl">User Management</CardTitle>
              <CardDescription className="text-sm">View and manage all registered users</CardDescription>
            </CardHeader>
            <CardContent className="px-0 sm:px-6">
              <div className="table-responsive">
                <UserManagementTable />
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
