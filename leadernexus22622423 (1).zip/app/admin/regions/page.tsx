"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, MapPin, Users } from "lucide-react"
import type { Profile } from "@/lib/types"

interface District {
  id: string
  name: string
  region: string
  description: string | null
  is_active: boolean
  created_at: string
  leader_count: number
}

export default function AdminRegionsPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [districts, setDistricts] = useState<District[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    const supabase = createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      redirect("/auth/login")
      return
    }

    const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

    if (!userProfile || userProfile.role !== "admin") {
      redirect("/dashboard")
      return
    }

    setProfile(userProfile)

    // Fetch districts with leader counts
    const { data: districtsData } = await supabase.from("districts").select("*").order("name")

    // Get leader counts for each district
    const districtsWithCounts = await Promise.all(
      (districtsData || []).map(async (district) => {
        const { count } = await supabase
          .from("profiles")
          .select("*", { count: "exact", head: true })
          .eq("district_id", district.id)

        return {
          ...district,
          leader_count: count || 0,
        }
      }),
    )

    setDistricts(districtsWithCounts)
    setLoading(false)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        </div>
      </div>
    )
  }

  // Group districts by region
  const districtsByRegion = districts.reduce(
    (acc, district) => {
      const region = district.region || "Other"
      if (!acc[region]) acc[region] = []
      acc[region].push(district)
      return acc
    },
    {} as Record<string, District[]>,
  )

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Regions Management</h1>
            <p className="text-muted-foreground mt-2">View regional hierarchy and district information</p>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Districts</CardTitle>
                <MapPin className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{districts.length}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Districts</CardTitle>
                <MapPin className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{districts.filter((d) => d.is_active).length}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Leaders</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{districts.reduce((sum, d) => sum + d.leader_count, 0)}</div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            {Object.entries(districtsByRegion).map(([region, regionDistricts]) => (
              <Card key={region}>
                <CardHeader>
                  <CardTitle className="text-xl">{region}</CardTitle>
                  <CardDescription>{regionDistricts.length} districts</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2">
                    {regionDistricts.map((district) => (
                      <div key={district.id} className="flex items-start justify-between p-4 border rounded-lg">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{district.name}</h3>
                            <Badge variant={district.is_active ? "default" : "secondary"}>
                              {district.is_active ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                          {district.description && (
                            <p className="text-sm text-muted-foreground">{district.description}</p>
                          )}
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <Users className="h-3 w-3" />
                            {district.leader_count} leaders
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {districts.length === 0 && (
            <Card>
              <CardContent className="text-center py-12 text-muted-foreground">
                <p>No districts found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
