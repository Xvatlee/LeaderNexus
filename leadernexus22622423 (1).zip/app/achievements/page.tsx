"use client"

import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, Lock, Check } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { useTranslations } from "@/lib/i18n/use-translations"
import { useEffect, useState } from "react"
import type { Profile } from "@/lib/types"
import { CircularProgress } from "@/components/stats/circular-progress"
import { AnimatedCounter } from "@/components/stats/animated-counter"
import { AchievementUnlockAnimation } from "@/components/stats/achievement-unlock-animation"

interface Achievement {
  id: string
  name: string
  description: string
  points_required: number
  earned?: boolean
  earnedAt?: string
}

export default function AchievementsPage() {
  const { t } = useTranslations()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [loading, setLoading] = useState(true)
  const [showUnlockAnimation, setShowUnlockAnimation] = useState(false)
  const [unlockedAchievement, setUnlockedAchievement] = useState<Achievement | null>(null)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      setProfile(userProfile)

      // Fetch all achievements
      const { data: allAchievements } = await supabase.from("achievements").select("*").order("points_required")

      const { data: userAchievements } = await supabase
        .from("user_achievements")
        .select("achievement_id, unlocked_at")
        .eq("user_id", user.id)

      const earnedAchievementIds = new Set(userAchievements?.map((ua) => ua.achievement_id) || [])

      const achievementsWithStatus = (allAchievements || []).map((achievement) => ({
        ...achievement,
        earned: earnedAchievementIds.has(achievement.id),
        earnedAt: userAchievements?.find((ua) => ua.achievement_id === achievement.id)?.unlocked_at,
      }))

      setAchievements(achievementsWithStatus)
      setLoading(false)
    }

    loadData()
  }, [])

  const earnedCount = achievements.filter((a) => a.earned).length
  const totalCount = achievements.length

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">{t("common.loading")}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      {unlockedAchievement && (
        <AchievementUnlockAnimation
          name={unlockedAchievement.name}
          description={unlockedAchievement.description}
          points={unlockedAchievement.points_required}
          show={showUnlockAnimation}
          onComplete={() => {
            setShowUnlockAnimation(false)
            setUnlockedAchievement(null)
          }}
        />
      )}

      <main className="container py-8">
        <div className="space-y-6">
          {/* Header */}
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold tracking-tight">{t("achievements.title")}</h1>
            <p className="text-muted-foreground">{t("achievements.subtitle")}</p>
          </div>

          {/* Progress Overview */}
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="animate-fade-in-up">
              <CardHeader>
                <CardTitle>{t("achievements.yourProgress")}</CardTitle>
                <CardDescription>
                  <AnimatedCounter value={earnedCount} /> {t("achievements.of")} {totalCount}{" "}
                  {t("achievements.unlocked")}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Progress value={(earnedCount / totalCount) * 100} className="h-2" />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    {t("achievements.totalPoints")}: <AnimatedCounter value={profile?.points || 0} />
                  </span>
                  <span className="font-semibold text-accent">
                    {Math.round((earnedCount / totalCount) * 100)}% {t("achievements.complete")}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up animate-stagger-1">
              <CardHeader>
                <CardTitle>Completion Rate</CardTitle>
                <CardDescription>Track your achievement progress</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center py-4">
                <CircularProgress value={earnedCount} max={totalCount} size={160} />
              </CardContent>
            </Card>
          </div>

          {/* All Achievements */}
          <Card>
            <CardHeader>
              <CardTitle>{t("achievements.allAchievements")}</CardTitle>
              <CardDescription>
                {earnedCount} {t("achievements.of")} {totalCount} {t("achievements.unlocked")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {achievements.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`relative flex items-start gap-4 rounded-lg border p-4 ${
                      achievement.earned ? "bg-accent/5 border-accent" : "opacity-60"
                    }`}
                  >
                    {achievement.earned && (
                      <div className="absolute top-2 right-2">
                        <div className="flex h-6 w-6 items-center justify-center rounded-full bg-accent text-accent-foreground">
                          <Check className="h-4 w-4" />
                        </div>
                      </div>
                    )}

                    <div
                      className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${
                        achievement.earned ? "bg-accent/10" : "bg-muted"
                      }`}
                    >
                      {achievement.earned ? (
                        <Award className="h-6 w-6 text-accent" />
                      ) : (
                        <Lock className="h-6 w-6 text-muted-foreground" />
                      )}
                    </div>

                    <div className="flex-1 space-y-1">
                      <div className="font-semibold">{achievement.name}</div>
                      <div className="text-sm text-muted-foreground">{achievement.description}</div>
                      <div className="flex items-center gap-2 pt-1">
                        <Badge variant="outline" className="text-xs">
                          {achievement.points_required} {t("achievements.pointsRequired")}
                        </Badge>
                        {achievement.earned && achievement.earnedAt && (
                          <span className="text-xs text-muted-foreground">
                            {t("achievements.earned")} {new Date(achievement.earnedAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
