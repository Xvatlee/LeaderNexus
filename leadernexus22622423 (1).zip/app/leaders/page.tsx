"use client"

import { useEffect, useState, Suspense } from "react"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Users, MapPin, Target, Search, Award } from "lucide-react"
import type { Profile, District, Direction } from "@/lib/types"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { DistrictMap } from "@/components/interactive/district-map"
import { useTranslations } from "@/lib/i18n/use-translations"

function LeadersContent() {
  const { t } = useTranslations()
  const [currentUser, setCurrentUser] = useState<Profile | null>(null)
  const [leaders, setLeaders] = useState<Profile[]>([])
  const [filteredLeaders, setFilteredLeaders] = useState<Profile[]>([])
  const [districts, setDistricts] = useState<District[]>([])
  const [directions, setDirections] = useState<Direction[]>([])
  const [selectedDistrict, setSelectedDistrict] = useState<string>("all")
  const [selectedDirection, setSelectedDirection] = useState<string>("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()
      if (profile) setCurrentUser(profile)

      const [leadersResult, districtsResult, directionsResult] = await Promise.all([
        supabase
          .from("profiles")
          .select("*")
          .eq("role", "leader")
          .not("district", "is", null)
          .not("direction", "is", null)
          .order("district")
          .order("direction"),
        supabase.from("districts").select("*").eq("is_active", true).order("name"),
        supabase.from("directions").select("*").eq("is_active", true).order("name"),
      ])

      if (leadersResult.data) {
        setLeaders(leadersResult.data)
        setFilteredLeaders(leadersResult.data)
      }
      if (districtsResult.data) setDistricts(districtsResult.data)
      if (directionsResult.data) setDirections(directionsResult.data)

      setLoading(false)
    }

    loadData()
  }, [])

  useEffect(() => {
    let filtered = leaders

    if (selectedDistrict !== "all") {
      filtered = filtered.filter((leader) => leader.district === selectedDistrict)
    }

    if (selectedDirection !== "all") {
      filtered = filtered.filter((leader) => leader.direction === selectedDirection)
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (leader) =>
          leader.full_name?.toLowerCase().includes(query) ||
          leader.username.toLowerCase().includes(query) ||
          leader.district?.toLowerCase().includes(query) ||
          leader.direction?.toLowerCase().includes(query),
      )
    }

    setFilteredLeaders(filtered)
  }, [selectedDistrict, selectedDirection, searchQuery, leaders])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center shimmer rounded-lg h-8 w-48 mx-auto"></div>
        </div>
      </div>
    )
  }

  const groupedLeaders = filteredLeaders.reduce(
    (acc, leader) => {
      const district = leader.district || "Noma'lum"
      if (!acc[district]) {
        acc[district] = []
      }
      acc[district].push(leader)
      return acc
    },
    {} as Record<string, Profile[]>,
  )

  const districtMapData = Object.entries(groupedLeaders).map(([name, leaders]) => ({
    name,
    leaderCount: leaders.length,
  }))

  const handleDistrictMapClick = (districtName: string) => {
    setSelectedDistrict(districtName)
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={currentUser} />

      <main className="container py-8 px-4 max-w-7xl mx-auto">
        <div className="space-y-6">
          <div className="space-y-2 animate-fade-in-up">
            <div className="flex items-center gap-2">
              <Users className="h-7 w-7 lg:h-8 lg:w-8 text-primary icon-interactive" />
              <h1 className="text-3xl lg:text-4xl font-bold">{t("leaders.title")}</h1>
            </div>
            <p className="text-muted-foreground text-sm lg:text-base">{t("leaders.subtitle")}</p>
          </div>

          <div className="animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            <DistrictMap districts={districtMapData} onDistrictClick={handleDistrictMapClick} />
          </div>

          <Card className="card-interactive animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <CardHeader>
              <CardTitle>{t("leaders.filters")}</CardTitle>
              <CardDescription>{t("leaders.filtersDescription")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <div className="space-y-2">
                  <label className="text-sm font-medium">{t("leaders.district")}</label>
                  <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
                    <SelectTrigger>
                      <SelectValue placeholder={t("leaders.allDistricts")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t("leaders.allDistricts")}</SelectItem>
                      {districts.map((district) => (
                        <SelectItem key={district.id} value={district.name}>
                          {district.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">{t("leaders.direction")}</label>
                  <Select value={selectedDirection} onValueChange={setSelectedDirection}>
                    <SelectTrigger>
                      <SelectValue placeholder={t("leaders.allDirections")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t("leaders.allDirections")}</SelectItem>
                      {directions.map((direction) => (
                        <SelectItem key={direction.id} value={direction.name}>
                          {direction.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">{t("leaders.search")}</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground icon-interactive" />
                    <Input
                      placeholder={t("leaders.searchPlaceholder")}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Card className="stat-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{t("leaders.totalLeaders")}</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground icon-interactive" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{filteredLeaders.length}</div>
                <p className="text-xs text-muted-foreground">
                  {t("leaders.showing")} {filteredLeaders.length} {t("leaders.of")} {leaders.length}
                </p>
              </CardContent>
            </Card>

            <Card className="stat-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{t("leaders.districts")}</CardTitle>
                <MapPin className="h-4 w-4 text-muted-foreground icon-interactive" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Object.keys(groupedLeaders).length}</div>
                <p className="text-xs text-muted-foreground">{t("leaders.activeDistricts")}</p>
              </CardContent>
            </Card>

            <Card className="stat-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{t("leaders.directions")}</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground icon-interactive" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{directions.length}</div>
                <p className="text-xs text-muted-foreground">{t("leaders.availableDirections")}</p>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            {Object.keys(groupedLeaders).length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Users className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
                  <p className="mt-4 text-muted-foreground">{t("leaders.noLeadersFound")}</p>
                </CardContent>
              </Card>
            ) : (
              Object.entries(groupedLeaders).map(([district, districtLeaders]) => (
                <Card key={district} className="card-interactive">
                  <CardHeader>
                    <div className="flex items-center gap-2 flex-wrap">
                      <MapPin className="h-5 w-5 text-primary icon-interactive" />
                      <CardTitle>
                        {district} {t("leaders.districtName")}
                      </CardTitle>
                      <Badge variant="secondary">
                        {districtLeaders.length} {t("leaders.leaders")}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                      {districtLeaders.map((leader) => (
                        <Card key={leader.id} className="overflow-hidden card-interactive">
                          <CardContent className="p-4">
                            <div className="flex items-start gap-3">
                              <Avatar className="h-12 w-12 flex-shrink-0">
                                <AvatarImage src={leader.avatar_url || undefined} />
                                <AvatarFallback>
                                  {leader.full_name?.charAt(0).toUpperCase() || leader.username.charAt(0).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div className="flex-1 space-y-2 min-w-0">
                                <div>
                                  <h4 className="font-semibold text-sm truncate">
                                    {leader.full_name || leader.username}
                                  </h4>
                                  <p className="text-xs text-muted-foreground truncate">@{leader.username}</p>
                                </div>
                                <Badge variant="default" className="text-xs">
                                  <Target className="mr-1 h-3 w-3 flex-shrink-0" />
                                  <span className="truncate">{leader.direction}</span>
                                </Badge>
                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                  <Award className="h-3 w-3 flex-shrink-0 icon-interactive" />
                                  <span>
                                    {leader.points} {t("leaders.points")}
                                  </span>
                                </div>
                                <Button
                                  asChild
                                  variant="outline"
                                  size="sm"
                                  className="w-full bg-transparent btn-interactive"
                                >
                                  <Link href={`/profile/${leader.id}`}>{t("leaders.viewProfile")}</Link>
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

export default function LeadersPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-background">
          <div className="container py-8">
            <div className="text-center shimmer rounded-lg h-8 w-48 mx-auto"></div>
          </div>
        </div>
      }
    >
      <LeadersContent />
    </Suspense>
  )
}
