import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import CreateReportForm from "@/components/reports/create-report-form"

export default async function CreateReportPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile and district
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, leader_directions(district_id, districts(id, name))")
    .eq("id", user.id)
    .single()

  if (!profile?.leader_directions?.[0]?.district_id) {
    redirect("/dashboard")
  }

  const districtId = profile.leader_directions[0].district_id
  const districtName = profile.leader_directions[0].districts?.name

  return (
    <div className="container max-w-4xl py-8">
      <CreateReportForm userId={user.id} districtId={districtId} districtName={districtName || ""} />
    </div>
  )
}
