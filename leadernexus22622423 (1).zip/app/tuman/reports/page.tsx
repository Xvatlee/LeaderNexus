import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { ReportsList } from "@/components/reports/reports-list"
import { Button } from "@/components/ui/button"
import { Plus, FileText } from "lucide-react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default async function TumanReportsPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile and district
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, leader_directions(district_id, districts(id, name))")
    .eq("id", user.id)
    .single()

  if (!profile?.leader_directions?.[0]?.district_id) {
    redirect("/dashboard")
  }

  const districtId = profile.leader_directions[0].district_id
  const districtName = profile.leader_directions[0].districts?.name

  // Get reports for this district
  const { data: reports } = await supabase
    .from("reports")
    .select("*")
    .eq("district_id", districtId)
    .order("created_at", { ascending: false })

  return (
    <div className="container py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Hisobotlar</h1>
            <p className="text-muted-foreground">{districtName} tumani uchun oylik va yillik hisobotlar</p>
          </div>
          <Button asChild>
            <Link href="/tuman/reports/create">
              <Plus className="h-4 w-4 mr-2" />
              Yangi hisobot
            </Link>
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Jami hisobotlar</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{reports?.length || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Yuborilgan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{reports?.filter((r) => r.status === "submitted").length || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Tasdiklangan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{reports?.filter((r) => r.status === "approved").length || 0}</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {reports && reports.length > 0 ? (
        <ReportsList reports={reports} userRole="tuman" />
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">Hozircha hisobotlar yo'q</p>
            <Button asChild>
              <Link href="/tuman/reports/create">
                <Plus className="h-4 w-4 mr-2" />
                Birinchi hisobotni yarating
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
