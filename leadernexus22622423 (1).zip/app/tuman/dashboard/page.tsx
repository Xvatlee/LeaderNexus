"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Target, Users, Award, Calendar, CheckCircle2, AlertCircle, Plus, BarChart3, Activity } from "lucide-react"
import Link from "next/link"
import type { Profile, Tuman, DistrictRating } from "@/lib/types/database.types"
import { TumanPerformanceCharts } from "@/components/tuman/performance-charts"
import { TumanProjectsList } from "@/components/tuman/projects-list"
import { TumanActivitiesList } from "@/components/tuman/activities-list"

export default function TumanDashboardPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [district, setDistrict] = useState<Tuman | null>(null)
  const [currentRating, setCurrentRating] = useState<DistrictRating | null>(null)
  const [rank, setRank] = useState<number | null>(null)
  const [totalDistricts, setTotalDistricts] = useState<number>(0)
  const [stats, setStats] = useState({
    totalProjects: 0,
    completedProjects: 0,
    inProgressProjects: 0,
    totalActivities: 0,
    activeIssues: 0,
    resolvedIssues: 0,
    totalParticipants: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [])

  async function loadDashboardData() {
    try {
      const supabase = createClient()

      // Get authenticated user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      // Get user profile
      const { data: userProfile, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single()

      if (profileError || !userProfile) {
        console.error("[v0] Profile error:", profileError)
        redirect("/dashboard")
        return
      }

      // Check if user is tuman sardori
      if (userProfile.role !== "tuman_sardori" && userProfile.role !== "admin") {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      // Load district information
      const { data: districtData } = await supabase.from("tuman").select("*").eq("id", userProfile.tuman_id).single()

      if (districtData) {
        setDistrict(districtData)
      }

      // Load current rating
      const currentDate = new Date().toISOString().split("T")[0]
      const { data: ratingData } = await supabase
        .from("district_ratings")
        .select("*")
        .eq("tuman_id", userProfile.tuman_id)
        .eq("rating_period", currentDate)
        .single()

      if (ratingData) {
        setCurrentRating(ratingData)
        setRank(ratingData.rank || null)
      }

      // Get total districts in viloyat for ranking context
      const { count: districtCount } = await supabase
        .from("tuman")
        .select("*", { count: "exact", head: true })
        .eq("viloyat_id", userProfile.viloyat_id)

      setTotalDistricts(districtCount || 0)

      // Load projects statistics
      const { data: projectsData } = await supabase.from("projects").select("*").eq("tuman_id", userProfile.tuman_id)

      if (projectsData) {
        const completed = projectsData.filter((p) => p.status === "completed").length
        const inProgress = projectsData.filter((p) => p.status === "in_progress").length
        setStats((prev) => ({
          ...prev,
          totalProjects: projectsData.length,
          completedProjects: completed,
          inProgressProjects: inProgress,
        }))
      }

      // Load activities statistics
      const { data: activitiesData } = await supabase
        .from("activities")
        .select("*")
        .eq("tuman_id", userProfile.tuman_id)

      if (activitiesData) {
        const totalParticipants = activitiesData.reduce((sum, a) => sum + (a.participants_count || 0), 0)
        setStats((prev) => ({
          ...prev,
          totalActivities: activitiesData.length,
          totalParticipants,
        }))
      }

      // Load issues statistics
      const { data: issuesData } = await supabase.from("issues").select("*").eq("tuman_id", userProfile.tuman_id)

      if (issuesData) {
        const resolved = issuesData.filter((i) => i.status === "resolved" || i.status === "closed").length
        const active = issuesData.filter((i) => i.status === "open" || i.status === "in_progress").length
        setStats((prev) => ({
          ...prev,
          activeIssues: active,
          resolvedIssues: resolved,
        }))
      }

      setLoading(false)
    } catch (error) {
      console.error("[v0] Dashboard error:", error)
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Yuklanmoqda...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8 px-4 max-w-7xl mx-auto">
        <div className="space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Tuman boshqaruv paneli</h1>
              <p className="text-muted-foreground mt-2">
                {district?.name} tumani - O'z faoliyatingizni boshqaring va nazorat qiling
              </p>
            </div>
            <Button asChild>
              <Link href="/projects/new">
                <Plus className="h-4 w-4 mr-2" />
                Yangi loyiha
              </Link>
            </Button>
          </div>

          {/* District Info & Current Rating */}
          <div className="grid gap-4 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Tumaning umumiy ma'lumotlari</CardTitle>
                <CardDescription>Asosiy demografik va geografik ko'rsatkichlar</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Tuman nomi</p>
                    <p className="text-lg font-semibold">{district?.name}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Aholi soni</p>
                    <p className="text-lg font-semibold flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      {district?.population?.toLocaleString() || "Ma'lumot yo'q"}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Hudud maydoni</p>
                    <p className="text-lg font-semibold">
                      {district?.area_km2 ? `${district.area_km2} km²` : "Ma'lumot yo'q"}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Tavsif</p>
                    <p className="text-sm">{district?.description || "Ma'lumot yo'q"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className={currentRating ? "border-primary" : ""}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Joriy reyting
                </CardTitle>
                <CardDescription>Sizning hozirgi ko'rsatkichingiz</CardDescription>
              </CardHeader>
              <CardContent>
                {currentRating ? (
                  <div className="space-y-4">
                    <div className="text-center">
                      <p className="text-5xl font-bold text-primary">{currentRating.overall_score?.toFixed(1)}</p>
                      <p className="text-sm text-muted-foreground mt-1">100 balldan</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>O'rningiz</span>
                        <span className="font-semibold">
                          {rank || "N/A"} / {totalDistricts}
                        </span>
                      </div>
                      <Progress
                        value={rank && totalDistricts ? ((totalDistricts - rank + 1) / totalDistricts) * 100 : 0}
                        className="h-2"
                      />
                    </div>
                    <Button asChild className="w-full bg-transparent" variant="outline">
                      <Link href="/tuman/performance">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Batafsil tahlil
                      </Link>
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Award className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground">Hozircha reyting ma'lumotlari yo'q</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Key Metrics */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Jami loyihalar</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalProjects}</div>
                <p className="text-xs text-muted-foreground mt-1">{stats.inProgressProjects} jarayonda</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tugallangan loyihalar</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{stats.completedProjects}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stats.totalProjects > 0 ? ((stats.completedProjects / stats.totalProjects) * 100).toFixed(0) : 0}%
                  bajarildi
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tadbirlar</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalActivities}</div>
                <p className="text-xs text-muted-foreground mt-1">{stats.totalParticipants} ishtirokchi</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Muammolar</CardTitle>
                <AlertCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.activeIssues}</div>
                <p className="text-xs text-muted-foreground mt-1">{stats.resolvedIssues} hal qilindi</p>
              </CardContent>
            </Card>
          </div>

          {/* Performance Breakdown */}
          {currentRating && (
            <Card>
              <CardHeader>
                <CardTitle>Mezonlar bo'yicha ko'rsatkichlar</CardTitle>
                <CardDescription>Har bir baholash mezonidagi natijalaringiz</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">Loyihalar muvaffaqiyati</span>
                      <span className="font-bold">{currentRating.project_completion_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={currentRating.project_completion_score || 0} className="h-3" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">Jamoatchilik ishtiroki</span>
                      <span className="font-bold">{currentRating.community_engagement_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={currentRating.community_engagement_score || 0} className="h-3" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">Yetakchilik qobiliyati</span>
                      <span className="font-bold">{currentRating.leadership_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={currentRating.leadership_score || 0} className="h-3" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">Innovatsiya</span>
                      <span className="font-bold">{currentRating.innovation_score?.toFixed(1)}/100</span>
                    </div>
                    <Progress value={currentRating.innovation_score || 0} className="h-3" />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Main Content Tabs */}
          <Tabs defaultValue="projects" className="space-y-6">
            <TabsList className="grid w-full max-w-2xl grid-cols-4">
              <TabsTrigger value="projects">Loyihalar</TabsTrigger>
              <TabsTrigger value="activities">Tadbirlar</TabsTrigger>
              <TabsTrigger value="performance">Ko'rsatkichlar</TabsTrigger>
              <TabsTrigger value="team">Jamoa</TabsTrigger>
            </TabsList>

            {/* Projects Tab */}
            <TabsContent value="projects" className="space-y-6">
              <TumanProjectsList tumanId={profile?.tuman_id || ""} />
            </TabsContent>

            {/* Activities Tab */}
            <TabsContent value="activities" className="space-y-6">
              <TumanActivitiesList tumanId={profile?.tuman_id || ""} />
            </TabsContent>

            {/* Performance Tab */}
            <TabsContent value="performance" className="space-y-6">
              <TumanPerformanceCharts tumanId={profile?.tuman_id || ""} currentRating={currentRating} />
            </TabsContent>

            {/* Team Tab */}
            <TabsContent value="team" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Jamoa a'zolari
                  </CardTitle>
                  <CardDescription>Tumaningiz sardorlari va faol a'zolar</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground mb-4">Jamoa a'zolari tizimi ishlab chiqilmoqda</p>
                    <Button asChild variant="outline">
                      <Link href="/leaders">Sardorlarni ko'rish</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Tezkor harakatlar</CardTitle>
              <CardDescription>Tez-tez ishlatiladigan funksiyalar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Button asChild variant="outline" className="h-24 flex-col gap-2 bg-transparent">
                  <Link href="/projects/new">
                    <Plus className="h-6 w-6" />
                    <span className="text-sm font-semibold">Yangi loyiha</span>
                  </Link>
                </Button>

                <Button asChild variant="outline" className="h-24 flex-col gap-2 bg-transparent">
                  <Link href="/tuman/activities/new">
                    <Calendar className="h-6 w-6" />
                    <span className="text-sm font-semibold">Tadbir tashkil qilish</span>
                  </Link>
                </Button>

                <Button asChild variant="outline" className="h-24 flex-col gap-2 bg-transparent">
                  <Link href="/tuman/reports">
                    <BarChart3 className="h-6 w-6" />
                    <span className="text-sm font-semibold">Hisobotlar</span>
                  </Link>
                </Button>

                <Button asChild variant="outline" className="h-24 flex-col gap-2 bg-transparent">
                  <Link href="/ratings">
                    <Award className="h-6 w-6" />
                    <span className="text-sm font-semibold">Reyting ko'rish</span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
