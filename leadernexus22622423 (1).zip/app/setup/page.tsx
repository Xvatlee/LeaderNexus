import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle2, AlertCircle, Database, Play } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { DatabaseStatusChecker } from "@/components/database-status-checker"

export default function SetupPage() {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold">LeaderNexus Setup Guide</h1>
          <p className="text-muted-foreground">Follow these steps to set up your LeaderNexus application</p>
        </div>

        <DatabaseStatusChecker />

        <Alert>
          <Database className="h-4 w-4" />
          <AlertDescription>
            This guide will help you set up the database and configure your LeaderNexus application.
          </AlertDescription>
        </Alert>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                1
              </span>
              Database Setup
            </CardTitle>
            <CardDescription>Execute the SQL migration scripts in the correct order</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
              <Play className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <AlertDescription className="text-sm">
                <strong>In v0:</strong> Click the "Run All" button when the Scripts dialog appears. Scripts will execute
                in the correct order automatically.
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <div className="space-y-2">
                <p className="text-sm font-semibold text-green-700 dark:text-green-400">
                  Phase 1: Core Setup (REQUIRED - Run First)
                </p>
                <ol className="list-decimal ml-6 space-y-2 text-sm">
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">scripts/01_create_tables.sql</code>
                    <p className="text-muted-foreground mt-1">
                      Creates all base tables (viloyat, tuman, profiles, projects, issues, etc.)
                    </p>
                  </li>
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">scripts/02_enable_rls.sql</code>
                    <p className="text-muted-foreground mt-1">Enables Row Level Security policies</p>
                  </li>
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">scripts/03_seed_sample_data.sql</code>
                    <p className="text-muted-foreground mt-1">Seeds Surxondaryo viloyati with 14 districts</p>
                  </li>
                </ol>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-semibold text-blue-700 dark:text-blue-400">
                  Phase 2: Features (Run After Phase 1)
                </p>
                <ol className="list-decimal ml-6 space-y-2 text-sm" start={4}>
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">
                      scripts/04_create_notification_triggers.sql
                    </code>
                    <p className="text-muted-foreground mt-1">Sets up notification triggers</p>
                  </li>
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">scripts/002_create_voting_tables.sql</code>
                    <p className="text-muted-foreground mt-1">Creates voting system tables</p>
                  </li>
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">scripts/008_add_status_to_profiles.sql</code>
                    <p className="text-muted-foreground mt-1">Adds status column to profiles</p>
                  </li>
                </ol>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-semibold text-purple-700 dark:text-purple-400">
                  Phase 3: Media System (Optional)
                </p>
                <ol className="list-decimal ml-6 space-y-2 text-sm" start={7}>
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">scripts/018_create_storage_bucket.sql</code>
                    <p className="text-muted-foreground mt-1">Creates Supabase storage bucket for media files</p>
                  </li>
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">scripts/020_create_media_tables.sql</code>
                    <p className="text-muted-foreground mt-1">Creates media, likes, and comments tables</p>
                  </li>
                  <li>
                    <code className="bg-muted px-2 py-1 rounded text-xs">scripts/021_media_rls_policies.sql</code>
                    <p className="text-muted-foreground mt-1">Sets up RLS policies for media</p>
                  </li>
                </ol>
              </div>
            </div>

            <Alert className="bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-800">
              <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              <AlertDescription className="text-sm">
                <strong>Important:</strong> All scripts are now safe to run multiple times. They include proper error
                handling and will skip steps that are already completed.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                2
              </span>
              Environment Variables
            </CardTitle>
            <CardDescription>Verify Supabase connection is configured</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">The following environment variables should already be set in your v0 project:</p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5" />
                <code className="bg-muted px-2 py-1 rounded text-xs">NEXT_PUBLIC_SUPABASE_URL</code>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5" />
                <code className="bg-muted px-2 py-1 rounded text-xs">NEXT_PUBLIC_SUPABASE_ANON_KEY</code>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5" />
                <code className="bg-muted px-2 py-1 rounded text-xs">SUPABASE_SERVICE_ROLE_KEY</code>
              </li>
            </ul>
            <p className="text-xs text-muted-foreground">
              These are automatically configured when you connect the Supabase integration in v0.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                3
              </span>
              Test the Application
            </CardTitle>
            <CardDescription>Verify everything is working correctly</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <ol className="list-decimal ml-6 space-y-3 text-sm">
              <li>
                Navigate to the registration page
                <Button size="sm" variant="outline" className="ml-2 bg-transparent" asChild>
                  <Link href="/auth/register">Go to Register</Link>
                </Button>
              </li>
              <li>Verify that districts and directions are loaded in the dropdowns</li>
              <li>Create a test account with the "Leader (Sardor)" role</li>
              <li>Check your email for the confirmation link</li>
              <li>Log in and explore the dashboard</li>
            </ol>
          </CardContent>
        </Card>

        <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-900 dark:text-amber-100">
              <AlertCircle className="h-5 w-5" />
              Troubleshooting
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-amber-900 dark:text-amber-100">
            <div>
              <p className="font-medium">Error: "No districts available"</p>
              <p className="text-xs mt-1">
                The seed data script (03_seed_sample_data.sql) hasn't been run. Click "Run All" in the Scripts dialog.
              </p>
            </div>
            <div>
              <p className="font-medium">Error: "Supabase is not configured"</p>
              <p className="text-xs mt-1">
                Check that environment variables are set in the Vars section of v0, or reconnect the Supabase
                integration.
              </p>
            </div>
            <div>
              <p className="font-medium">Error: "relation does not exist"</p>
              <p className="text-xs mt-1">
                Database tables haven't been created. Make sure Phase 1 scripts (01, 02, 03) have been run successfully.
              </p>
            </div>
            <div>
              <p className="font-medium">Error: "policy already exists"</p>
              <p className="text-xs mt-1">
                This error should no longer occur. All scripts now include DROP POLICY IF EXISTS. Safe to re-run
                scripts.
              </p>
            </div>
            <div>
              <p className="font-medium">Media upload not working</p>
              <p className="text-xs mt-1">
                Run Phase 3 scripts (018, 020, 021) to enable the media system with storage bucket and tables.
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-center gap-4 pt-4">
          <Button asChild>
            <Link href="/auth/register">Start Registration</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/">Go to Home</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
