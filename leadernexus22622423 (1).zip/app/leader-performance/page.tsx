"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import DashboardNav from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Award, TrendingUp, Star, Crown, Medal } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { Profile } from "@/lib/types"

interface LeaderRanking {
  rank_position: number
  ranking_period: string
  total_points: number
  projects_completed: number
  participation_rate: number
  is_top_performer: boolean
  leader: {
    username: string
    full_name: string | null
    avatar_url: string | null
  }
}

interface LeaderReward {
  id: string
  reward_type: string
  title: string
  description: string
  icon: string | null
  points_awarded: number
  issued_date: string
}

interface LeaderReview {
  leadership_score: number
  communication_score: number
  project_management_score: number
  innovation_score: number
  overall_rating: number
  strengths: string
  areas_for_improvement: string
  review_period: string
  created_at: string
}

export default function LeaderPerformancePage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [currentRanking, setCurrentRanking] = useState<LeaderRanking | null>(null)
  const [allRankings, setAllRankings] = useState<LeaderRanking[]>([])
  const [rewards, setRewards] = useState<LeaderReward[]>([])
  const [reviews, setReviews] = useState<LeaderReview[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        redirect("/auth/login")
        return
      }

      const { data: userProfile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      if (!userProfile || (userProfile.role !== "leader" && userProfile.role !== "admin")) {
        redirect("/dashboard")
        return
      }

      setProfile(userProfile)

      // Get current month ranking
      const currentPeriod = new Date().toISOString().slice(0, 7) // YYYY-MM
      const { data: currentRank } = await supabase
        .from("leader_rankings")
        .select(
          `
          *,
          leader:profiles!leader_id(username, full_name, avatar_url)
        `,
        )
        .eq("leader_id", user.id)
        .eq("ranking_period", currentPeriod)
        .maybeSingle()

      setCurrentRanking(currentRank)

      // Get all rankings for current month
      const { data: allRanks } = await supabase
        .from("leader_rankings")
        .select(
          `
          *,
          leader:profiles!leader_id(username, full_name, avatar_url)
        `,
        )
        .eq("ranking_period", currentPeriod)
        .order("rank_position", { ascending: true })
        .limit(50)

      setAllRankings(allRanks || [])

      // Get rewards
      const { data: rewardsData } = await supabase
        .from("leader_rewards")
        .select("*")
        .eq("leader_id", user.id)
        .order("issued_date", { ascending: false })

      setRewards(rewardsData || [])

      // Get reviews
      const { data: reviewsData } = await supabase
        .from("leader_reviews")
        .select("*")
        .eq("leader_id", user.id)
        .order("created_at", { ascending: false })

      setReviews(reviewsData || [])

      setLoading(false)
    }

    loadData()
  }, [])

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="h-6 w-6 text-yellow-500" />
    if (rank === 2) return <Medal className="h-6 w-6 text-gray-400" />
    if (rank === 3) return <Medal className="h-6 w-6 text-amber-600" />
    return <span className="text-xl font-bold text-muted-foreground">#{rank}</span>
  }

  const getRewardIcon = (type: string) => {
    switch (type) {
      case "badge":
        return <Award className="h-5 w-5" />
      case "certificate":
        return <Star className="h-5 w-5" />
      case "award":
        return <Trophy className="h-5 w-5" />
      default:
        return <Award className="h-5 w-5" />
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav user={profile} />

      <main className="container py-8">
        <div className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-4xl font-bold tracking-tight">Performance & Recognition</h1>
            <p className="text-muted-foreground mt-2">Track your progress and celebrate achievements</p>
          </div>

          {/* Current Ranking Card */}
          {currentRanking && (
            <Card className="border-accent">
              <CardHeader>
                <CardTitle>Your Current Ranking</CardTitle>
                <CardDescription>Performance for {currentRanking.ranking_period}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-6">
                  <div className="flex items-center justify-center w-20 h-20 rounded-full bg-accent/10">
                    {getRankIcon(currentRanking.rank_position)}
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground">Total Points</div>
                        <div className="text-2xl font-bold">{currentRanking.total_points}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Projects</div>
                        <div className="text-2xl font-bold">{currentRanking.projects_completed}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Participation</div>
                        <div className="text-2xl font-bold">{currentRanking.participation_rate}%</div>
                      </div>
                    </div>
                    {currentRanking.is_top_performer && (
                      <Badge className="bg-accent">
                        <Star className="h-3 w-3 mr-1" />
                        Top Performer
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Tabs defaultValue="rankings" className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="rankings">Rankings</TabsTrigger>
              <TabsTrigger value="rewards">Rewards</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>

            {/* Rankings Tab */}
            <TabsContent value="rankings">
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Leaderboard</CardTitle>
                  <CardDescription>Top performing leaders this month</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {allRankings.map((ranking) => (
                      <div
                        key={ranking.rank_position}
                        className={`flex items-center gap-4 p-4 rounded-lg border ${
                          ranking.leader.username === profile?.username ? "bg-accent/5 border-accent" : ""
                        }`}
                      >
                        <div className="flex items-center justify-center w-12 h-12">
                          {getRankIcon(ranking.rank_position)}
                        </div>
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={ranking.leader.avatar_url || ""} />
                          <AvatarFallback>{ranking.leader.username?.charAt(0).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="font-semibold">{ranking.leader.full_name || ranking.leader.username}</div>
                          <div className="text-sm text-muted-foreground">@{ranking.leader.username}</div>
                        </div>
                        <div className="flex items-center gap-6 text-sm">
                          <div className="text-right">
                            <div className="font-semibold">{ranking.total_points}</div>
                            <div className="text-muted-foreground">Points</div>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">{ranking.projects_completed}</div>
                            <div className="text-muted-foreground">Projects</div>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">{ranking.participation_rate}%</div>
                            <div className="text-muted-foreground">Active</div>
                          </div>
                        </div>
                        {ranking.is_top_performer && (
                          <Badge className="bg-accent">
                            <Star className="h-3 w-3 mr-1" />
                            Top
                          </Badge>
                        )}
                      </div>
                    ))}
                    {allRankings.length === 0 && (
                      <div className="text-center py-12 text-muted-foreground">
                        <TrendingUp className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>No rankings available for this period</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Rewards Tab */}
            <TabsContent value="rewards">
              <Card>
                <CardHeader>
                  <CardTitle>Your Rewards & Recognition</CardTitle>
                  <CardDescription>Badges, certificates, and awards earned</CardDescription>
                </CardHeader>
                <CardContent>
                  {rewards.length > 0 ? (
                    <div className="grid gap-4 md:grid-cols-2">
                      {rewards.map((reward) => (
                        <div key={reward.id} className="flex items-start gap-4 p-4 rounded-lg border">
                          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-accent/10 text-accent">
                            {getRewardIcon(reward.reward_type)}
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center gap-2">
                              <div className="font-semibold">{reward.title}</div>
                              <Badge variant="secondary" className="text-xs">
                                {reward.reward_type}
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground">{reward.description}</div>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span>{new Date(reward.issued_date).toLocaleDateString()}</span>
                              {reward.points_awarded > 0 && <span>+{reward.points_awarded} points</span>}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      <Trophy className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No rewards yet. Keep up the great work!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Reviews Tab */}
            <TabsContent value="reviews">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Reviews</CardTitle>
                  <CardDescription>Feedback from peers and administrators</CardDescription>
                </CardHeader>
                <CardContent>
                  {reviews.length > 0 ? (
                    <div className="space-y-6">
                      {reviews.map((review, index) => (
                        <div key={index} className="p-6 rounded-lg border space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-semibold">Review Period: {review.review_period}</div>
                              <div className="text-sm text-muted-foreground">
                                {new Date(review.created_at).toLocaleDateString()}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Star className="h-5 w-5 text-accent fill-accent" />
                              <span className="text-2xl font-bold">{review.overall_rating.toFixed(1)}</span>
                              <span className="text-muted-foreground">/5.0</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <div className="text-sm text-muted-foreground">Leadership</div>
                              <div className="flex items-center gap-1">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < review.leadership_score ? "text-accent fill-accent" : "text-muted-foreground"
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                            <div>
                              <div className="text-sm text-muted-foreground">Communication</div>
                              <div className="flex items-center gap-1">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < review.communication_score
                                        ? "text-accent fill-accent"
                                        : "text-muted-foreground"
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                            <div>
                              <div className="text-sm text-muted-foreground">Project Management</div>
                              <div className="flex items-center gap-1">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < review.project_management_score
                                        ? "text-accent fill-accent"
                                        : "text-muted-foreground"
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                            <div>
                              <div className="text-sm text-muted-foreground">Innovation</div>
                              <div className="flex items-center gap-1">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < review.innovation_score ? "text-accent fill-accent" : "text-muted-foreground"
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>

                          {review.strengths && (
                            <div>
                              <div className="text-sm font-medium mb-1">Strengths</div>
                              <div className="text-sm text-muted-foreground">{review.strengths}</div>
                            </div>
                          )}

                          {review.areas_for_improvement && (
                            <div>
                              <div className="text-sm font-medium mb-1">Areas for Improvement</div>
                              <div className="text-sm text-muted-foreground">{review.areas_for_improvement}</div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      <Star className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No performance reviews yet</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
