// Database types
export interface Profile {
  id: string
  email: string
  username: string
  full_name: string | null
  avatar_url: string | null
  role: "admin" | "leader" | "district_head_leader" // Added district_head_leader role
  points: number
  language: string
  district: string | null
  direction: string | null
  created_at: string
}

export interface Post {
  id: string
  author_id: string
  title: string
  content: string
  category: string
  media_url: string | null
  media_type: string | null
  likes: number
  comments_count: number
  is_solved: boolean
  created_at: string
}

export interface Comment {
  id: string
  post_id: string
  author_id: string
  content: string
  parent_id: string | null
  created_at: string
}

export interface Notification {
  id: string
  user_id: string
  type: string
  title: string
  message: string
  is_read: boolean
  action_url: string | null
  created_at: string
}

export interface Achievement {
  id: string
  name: string
  description: string
  icon: string
  points_required: number
  category: string
}

export interface UserAchievement {
  id: string
  user_id: string
  achievement_id: string
  earned_at: string
}

export interface PointTransaction {
  id: string
  user_id: string
  amount: number
  reason: string
  created_at: string
}

// Extended types with relations
export interface PostWithAuthor extends Post {
  author: Pick<Profile, "id" | "username" | "full_name" | "avatar_url">
  user_liked?: boolean
}

export interface CommentWithAuthor extends Comment {
  author: Pick<Profile, "id" | "username" | "full_name" | "avatar_url">
}

export interface LeaderboardEntry {
  rank: number
  profile: Profile
  achievement_count: number
}

export interface UserProfile {
  id: string
  email: string
  username: string
  full_name: string | null
  avatar_url: string | null
  role: "admin" | "leader" | "district_head_leader" // Added district_head_leader role
  status: "active" | "suspended"
  points: number
  language: string
  district: string | null
  direction: string | null
  created_at: string
  updated_at?: string
  last_login?: string | null
}

export interface Plan {
  id: string
  leader_id: string
  title: string
  description: string | null
  plan_type: "weekly" | "monthly" | "yearly"
  start_date: string
  end_date: string
  status: "pending" | "in_progress" | "completed" | "cancelled"
  progress: number
  notes: string | null
  created_at: string
  updated_at: string
}

export interface PlanTask {
  id: string
  plan_id: string
  title: string
  description: string | null
  status: "pending" | "in_progress" | "completed"
  priority: "low" | "medium" | "high"
  due_date: string | null
  completed_at: string | null
  created_at: string
  updated_at: string
}

export interface PlanCollaborator {
  id: string
  plan_id: string
  collaborator_id: string
  can_edit: boolean
  invited_at: string
}

export interface PlanWithDetails extends Plan {
  leader: Pick<Profile, "id" | "username" | "full_name" | "avatar_url">
  plan_tasks: PlanTask[]
  plan_collaborators: (PlanCollaborator & {
    collaborator: Pick<Profile, "id" | "username" | "full_name" | "avatar_url">
  })[]
}

// New types for districts and directions
export interface District {
  id: string
  name: string
  region: string | null
  is_active: boolean
  created_at: string
}

export interface Direction {
  id: string
  name: string
  description: string | null
  is_active: boolean
  created_at: string
}

export interface RatingCriteria {
  id: string
  name_uz: string
  name_ru: string
  description_uz: string
  description_ru: string
  category: "projects" | "engagement" | "events" | "leadership" | "feedback"
  weight: number
  max_score: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface RatingPeriod {
  id: string
  period_type: "monthly" | "annual"
  start_date: string
  end_date: string
  year: number
  month: number | null
  is_active: boolean
  is_finalized: boolean
  created_at: string
}

export interface SardorRating {
  id: string
  sardor_id: string
  period_id: string
  district_id: string | null
  direction_id: string | null
  project_score: number
  engagement_score: number
  events_score: number
  leadership_score: number
  feedback_score: number
  total_score: number
  weighted_score: number
  rank_in_district: number | null
  rank_overall: number | null
  total_projects: number
  completed_projects: number
  total_events: number
  total_participants: number
  community_feedback_count: number
  is_finalized: boolean
  notes: string | null
  created_at: string
  updated_at: string
}

export interface RatingDetail {
  id: string
  rating_id: string
  criteria_id: string
  score: number
  max_score: number
  weight: number
  weighted_score: number
  notes: string | null
  created_at: string
  updated_at: string
}

export interface PeerReview {
  id: string
  reviewer_id: string
  reviewee_id: string
  period_id: string
  leadership_rating: number
  collaboration_rating: number
  communication_rating: number
  innovation_rating: number
  overall_rating: number
  positive_feedback: string | null
  constructive_feedback: string | null
  suggestions: string | null
  is_anonymous: boolean
  created_at: string
  updated_at: string
}

export interface CommunityFeedback {
  id: string
  sardor_id: string
  period_id: string | null
  rating: number
  category: "project" | "event" | "leadership" | "communication" | "other"
  feedback_text: string
  submitter_id: string | null
  submitter_name: string | null
  is_anonymous: boolean
  is_verified: boolean
  is_approved: boolean
  admin_notes: string | null
  created_at: string
}

export interface RatingAchievement {
  id: string
  sardor_id: string
  period_id: string
  achievement_type:
    | "top_district"
    | "top_overall"
    | "most_improved"
    | "best_engagement"
    | "best_projects"
    | "best_leader"
    | "monthly_star"
    | "annual_star"
  rank: number | null
  badge_name_uz: string | null
  badge_name_ru: string | null
  description_uz: string | null
  description_ru: string | null
  created_at: string
}

export interface SardorRatingWithDetails extends SardorRating {
  sardor: Pick<Profile, "id" | "username" | "full_name" | "avatar_url" | "district" | "direction">
  district: District | null
  direction: Direction | null
  rating_details: (RatingDetail & { criteria: RatingCriteria })[]
  peer_reviews_received: number
  average_peer_rating: number | null
}

export interface Sardor {
  id: string
  user_id: string
  district: string
  direction: string
  full_name: string
  avatar_url: string | null
  activity_status: "active" | "inactive"
  performance_score: number
  created_at: string
  updated_at: string
}

export interface SardorEvaluation {
  id: string
  sardor_id: string
  evaluator_id: string
  district: string
  score: number
  notes: string | null
  flagged: boolean
  created_at: string
  updated_at: string
}
