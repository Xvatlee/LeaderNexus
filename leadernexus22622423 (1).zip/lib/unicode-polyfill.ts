// Unicode-safe btoa/atob polyfill for browser
// This MUST be loaded before any Supabase operations
// The native btoa() only supports Latin1 characters, but Uzbek Cyrillic needs UTF-8 encoding

if (typeof window !== "undefined") {
  // Store original functions BEFORE overriding
  const nativeBtoa = window.btoa.bind(window)
  const nativeAtob = window.atob.bind(window)

  // Override window.btoa with Unicode-safe version
  ;(window as any).btoa = (str: string): string => {
    if (!str) return ""

    // Check if string contains non-Latin1 characters
    let hasUnicode = false
    for (let i = 0; i < str.length; i++) {
      if (str.charCodeAt(i) > 255) {
        hasUnicode = true
        break
      }
    }

    if (hasUnicode) {
      // Use safe encoder for Unicode strings
      const utf8Bytes = new TextEncoder().encode(str)
      let binary = ""
      for (let i = 0; i < utf8Bytes.length; i++) {
        binary += String.fromCharCode(utf8Bytes[i])
      }
      return nativeBtoa(binary)
    }

    // Use native for ASCII-only strings (faster)
    return nativeBtoa(str)
  }

  // Override window.atob with Unicode-safe version
  ;(window as any).atob = (base64: string): string => {
    if (!base64) return ""

    try {
      const binary = nativeAtob(base64)
      // Try to decode as UTF-8
      const bytes = new Uint8Array(binary.length)
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i)
      }
      return new TextDecoder().decode(bytes)
    } catch {
      // Fallback to native if anything fails
      try {
        return nativeAtob(base64)
      } catch {
        return ""
      }
    }
  }
}

// Export for explicit imports
export const encodeBase64 = (str: string): string => {
  if (typeof window !== "undefined") {
    return window.btoa(str)
  }
  return Buffer.from(str, "utf-8").toString("base64")
}

export const decodeBase64 = (base64: string): string => {
  if (typeof window !== "undefined") {
    return window.atob(base64)
  }
  return Buffer.from(base64, "base64").toString("utf-8")
}
