export type MediaFileType = "image" | "video" | "document"
export type MediaStatus = "pending" | "approved" | "rejected" | "archived"
export type MediaVisibility = "public" | "district" | "direction" | "private"
export type MediaCategory = "event" | "project" | "achievement" | "training" | "meeting" | "other"

export interface MediaFile {
  id: string
  title: string
  description?: string
  file_url: string
  file_type: MediaFileType
  file_size?: number
  mime_type?: string
  thumbnail_url?: string

  uploaded_by: string
  district_id?: string
  direction_id?: string

  category: MediaCategory
  tags?: string[]

  status: MediaStatus
  reviewed_by?: string
  reviewed_at?: string
  rejection_reason?: string

  visibility: MediaVisibility
  is_featured: boolean

  event_date?: string
  location?: string
  participants_count?: number
  related_project_id?: string

  view_count: number
  download_count: number

  created_at: string
  updated_at: string
}

export interface MediaComment {
  id: string
  media_id: string
  user_id: string
  comment: string
  created_at: string
  updated_at: string
}

export interface MediaLike {
  id: string
  media_id: string
  user_id: string
  created_at: string
}

export interface MediaCollection {
  id: string
  name: string
  description?: string
  created_by: string
  district_id?: string
  direction_id?: string
  cover_image_url?: string
  is_public: boolean
  created_at: string
  updated_at: string
}

export interface MediaCollectionItem {
  id: string
  collection_id: string
  media_id: string
  position: number
  created_at: string
}

export interface MediaUploadData {
  title: string
  description?: string
  category: MediaCategory
  tags?: string[]
  visibility: MediaVisibility
  event_date?: string
  location?: string
  participants_count?: number
}

export interface MediaFilterOptions {
  file_type?: MediaFileType
  category?: MediaCategory
  district_id?: string
  direction_id?: string
  status?: MediaStatus
  search?: string
  is_featured?: boolean
}
