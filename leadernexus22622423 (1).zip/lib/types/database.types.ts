export type UserRole = "viloyat_sardori" | "tuman_sardori" | "district_head_leader" | "admin"
export type ProjectStatus = "planning" | "in_progress" | "completed" | "on_hold" | "cancelled"
export type IssuePriority = "low" | "medium" | "high" | "critical"
export type IssueStatus = "open" | "in_progress" | "resolved" | "closed"

export interface Viloyat {
  id: string
  name: string
  description: string | null
  created_at: string
  updated_at: string
}

export interface Tuman {
  id: string
  viloyat_id: string
  name: string
  description: string | null
  population: number | null
  area_km2: number | null
  created_at: string
  updated_at: string
}

export interface Profile {
  id: string
  email: string
  full_name: string
  role: UserRole
  viloyat_id: string | null
  tuman_id: string | null
  district: string | null // Added district field for district_head_leader role
  avatar_url: string | null
  phone: string | null
  bio: string | null
  total_points: number
  created_at: string
  updated_at: string
}

export interface Project {
  id: string
  tuman_id: string
  created_by: string
  title: string
  description: string | null
  status: ProjectStatus
  start_date: string | null
  end_date: string | null
  budget: number | null
  progress_percentage: number
  impact_score: number
  community_involvement: number
  created_at: string
  updated_at: string
}

export interface ProjectMilestone {
  id: string
  project_id: string
  title: string
  description: string | null
  due_date: string | null
  completed: boolean
  completed_at: string | null
  created_at: string
}

export interface DistrictRating {
  id: string
  tuman_id: string
  rating_period: string
  overall_score: number
  project_completion_score: number
  community_engagement_score: number
  leadership_score: number
  innovation_score: number
  rank: number | null
  created_at: string
  updated_at: string
}

export interface Activity {
  id: string
  tuman_id: string
  created_by: string
  title: string
  description: string | null
  activity_type: string
  start_date: string
  end_date: string | null
  participants_count: number
  impact_points: number
  created_at: string
  updated_at: string
}

export interface Issue {
  id: string
  tuman_id: string
  reported_by: string
  title: string
  description: string
  priority: IssuePriority
  status: IssueStatus
  assigned_to: string | null
  resolved_at: string | null
  resolution_notes: string | null
  created_at: string
  updated_at: string
}

export interface Feedback {
  id: string
  from_user: string
  to_user: string | null
  tuman_id: string | null
  feedback_type: string
  content: string
  rating: number | null
  is_public: boolean
  created_at: string
}

export interface Notification {
  id: string
  user_id: string
  title: string
  message: string
  type: string
  link: string | null
  read: boolean
  created_at: string
}

export interface PerformanceMetric {
  id: string
  tuman_id: string
  metric_date: string
  projects_completed: number
  projects_in_progress: number
  total_participants: number
  total_budget_spent: number
  community_satisfaction: number
  created_at: string
}

export interface DistrictSardor {
  id: string
  profile_id: string
  district: string
  direction: string
  activity_status: "active" | "inactive"
  performance_score: number
  monthly_reports_count: number
  projects_completed: number
  last_activity_date: string | null
  created_at: string
  updated_at: string
}

export interface DistrictHeadEvaluation {
  id: string
  sardor_id: string
  evaluator_id: string
  district: string
  score: number
  category: "activity" | "leadership" | "engagement" | "innovation"
  notes: string | null
  is_flagged: boolean
  created_at: string
}

export interface DistrictNotification {
  id: string
  district: string
  recipient_id: string
  sender_id: string | null
  title: string
  message: string
  type: "report_submitted" | "project_completed" | "performance_alert" | "general"
  link: string | null
  read: boolean
  created_at: string
}
