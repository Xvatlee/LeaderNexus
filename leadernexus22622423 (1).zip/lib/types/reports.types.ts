export type ReportType = "monthly" | "yearly"
export type ReportStatus = "draft" | "submitted" | "reviewed" | "approved"
export type AlertType = "missing" | "overdue" | "reminder"

export interface Report {
  id: string
  user_id: string
  district_id: string
  report_type: ReportType
  report_period: string
  title: string
  summary?: string

  // Project updates
  completed_projects_count: number
  ongoing_projects_count: number
  projects_details: ProjectDetail[]

  // Community engagement
  events_count: number
  initiatives_count: number
  participation_rate?: number
  community_activities: CommunityActivity[]

  // Performance metrics
  project_success_rate?: number
  leadership_effectiveness_score?: number
  innovation_score?: number
  performance_metrics: Record<string, any>

  // Challenges and solutions
  challenges_faced?: string
  solutions_implemented?: string

  // Status and metadata
  status: ReportStatus
  submitted_at?: string
  reviewed_at?: string
  reviewed_by?: string

  created_at: string
  updated_at: string
}

export interface ProjectDetail {
  id: string
  name: string
  status: "completed" | "ongoing" | "planned"
  completion_percentage: number
  description?: string
  start_date?: string
  end_date?: string
  impact?: string
}

export interface CommunityActivity {
  id: string
  name: string
  type: "event" | "initiative" | "program"
  date: string
  participants_count: number
  description?: string
  outcome?: string
}

export interface ReportFeedback {
  id: string
  report_id: string
  reviewer_id: string
  overall_rating?: number
  project_success_rating?: number
  community_participation_rating?: number
  leadership_rating?: number
  feedback_text?: string
  suggestions?: string
  areas_for_improvement?: string
  is_read: boolean
  created_at: string
  updated_at: string
}

export interface ReportComment {
  id: string
  report_id: string
  user_id: string
  parent_comment_id?: string
  comment_text: string
  is_read: boolean
  created_at: string
  updated_at: string
}

export interface ReportAlert {
  id: string
  district_id: string
  report_type: ReportType
  expected_period: string
  alert_type: AlertType
  alert_message: string
  is_resolved: boolean
  resolved_at?: string
  created_at: string
}

export interface ReportAuditLog {
  id: string
  report_id?: string
  user_id: string
  action: string
  changes?: Record<string, any>
  ip_address?: string
  user_agent?: string
  created_at: string
}
