// Email utility for sending admin request notifications
// Uses Resend API for transactional emails

interface AdminRequestEmailParams {
  requesterEmail: string
  requesterName: string
  reason: string
  requestId: string
  approvalToken: string
}

export async function sendAdminRequestEmail(params: AdminRequestEmailParams): Promise<void> {
  const { requesterEmail, requesterName, reason, requestId, approvalToken } = params

  const appUrl = process.env.APP_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || "http://localhost:3000"
  const superAdminEmail = process.env.SUPER_ADMIN_EMAIL || "xvatkee@gmail.com"
  const resendApiKey = process.env.RESEND_API_KEY

  if (!resendApiKey) {
    console.error("[v0] RESEND_API_KEY is not configured. Skipping email notification.")
    console.log("[v0] Admin request details:", {
      requester: requesterEmail,
      reason,
      approveUrl: `${appUrl}/api/admin-requests/${requestId}/approve?token=${approvalToken}`,
      rejectUrl: `${appUrl}/api/admin-requests/${requestId}/reject?token=${approvalToken}`,
    })
    return
  }

  const approveUrl = `${appUrl}/api/admin-requests/${requestId}/approve?token=${approvalToken}`
  const rejectUrl = `${appUrl}/api/admin-requests/${requestId}/reject?token=${approvalToken}`

  const emailHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; }
          .header { background-color: #16a34a; color: white; padding: 20px; text-align: center; }
          .content { padding: 30px; background-color: #f9fafb; }
          .info-box { background-color: white; border-left: 4px solid #16a34a; padding: 15px; margin: 20px 0; }
          .button-container { text-align: center; margin: 30px 0; }
          .button { display: inline-block; padding: 12px 30px; margin: 0 10px; text-decoration: none; border-radius: 5px; font-weight: bold; }
          .approve-btn { background-color: #16a34a; color: white; }
          .reject-btn { background-color: #dc2626; color: white; }
          .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
          .warning { background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>🛡️ Admin Access Request</h1>
        </div>
        <div class="content">
          <p>Hello Super Admin,</p>
          <p>A user has requested admin privileges on LeaderNexus. Please review the request details below:</p>
          
          <div class="info-box">
            <strong>Requester:</strong> ${requesterName}<br>
            <strong>Email:</strong> ${requesterEmail}<br>
            <strong>Reason:</strong> ${reason || "No reason provided"}<br>
            <strong>Request ID:</strong> ${requestId}
          </div>

          <div class="warning">
            <strong>⚠️ Important:</strong> This approval link expires in 60 minutes. Admin privileges grant full access to the platform.
          </div>

          <div class="button-container">
            <a href="${approveUrl}" class="button approve-btn">✓ Approve Request</a>
            <a href="${rejectUrl}" class="button reject-btn">✗ Reject Request</a>
          </div>

          <p style="font-size: 12px; color: #666; margin-top: 30px;">
            If the buttons don't work, copy and paste these URLs:<br>
            <strong>Approve:</strong> ${approveUrl}<br>
            <strong>Reject:</strong> ${rejectUrl}
          </p>
        </div>
        <div class="footer">
          <p>This is an automated email from LeaderNexus Admin System</p>
          <p>© 2025 LeaderNexus - Surxondaryo Bolalar Harakati</p>
        </div>
      </body>
    </html>
  `

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendApiKey}`,
      },
      body: JSON.stringify({
        from: "LeaderNexus <noreply@leadernexus.com>",
        to: superAdminEmail,
        subject: `Admin Access Request from ${requesterName}`,
        html: emailHtml,
      }),
    })

    if (!response.ok) {
      const error = await response.text()
      console.error("[v0] Failed to send email:", error)
      throw new Error(`Email sending failed: ${error}`)
    }

    const data = await response.json()
    console.log("[v0] Admin request email sent successfully:", data.id)
  } catch (error) {
    console.error("[v0] Error sending admin request email:", error)
    // Don't throw - we still want the request to be created even if email fails
    console.log("[v0] Request created but email notification failed. Manual approval may be needed.")
  }
}
