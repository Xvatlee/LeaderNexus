export class DistrictAccessError extends Error {
  constructor(
    message: string,
    public code: "UNAUTHORIZED" | "FORBIDDEN" | "DISTRICT_MISMATCH" | "INVALID_ROLE",
  ) {
    super(message)
    this.name = "DistrictAccessError"
  }
}

export function handleDistrictError(error: unknown): {
  message: string
  code: string
  redirect?: string
} {
  if (error instanceof DistrictAccessError) {
    switch (error.code) {
      case "UNAUTHORIZED":
        return {
          message: "Tizimga kirish talab qilinadi",
          code: "UNAUTHORIZED",
          redirect: "/auth/login",
        }
      case "FORBIDDEN":
        return {
          message: "Sizda bu sahifaga kirish huquqi yo'q",
          code: "FORBIDDEN",
          redirect: "/dashboard",
        }
      case "DISTRICT_MISMATCH":
        return {
          message: "Siz faqat o'z tumaningizga kirish huquqiga egasiz",
          code: "DISTRICT_MISMATCH",
          redirect: "/dashboard",
        }
      case "INVALID_ROLE":
        return {
          message: "Noto'g'ri rol. Faqat Bosh sardorlar kirishi mumkin",
          code: "INVALID_ROLE",
          redirect: "/dashboard",
        }
    }
  }

  return {
    message: "Kutilmagan xatolik yuz berdi",
    code: "INTERNAL_ERROR",
    redirect: "/dashboard",
  }
}

export function logSecurityEvent(event: {
  type: "ACCESS_GRANTED" | "ACCESS_DENIED" | "DISTRICT_MISMATCH" | "ROLE_VIOLATION"
  userId: string
  district?: string
  requestedPath?: string
  reason?: string
}) {
  const logEntry = {
    ...event,
    timestamp: new Date().toISOString(),
    severity: event.type.includes("DENIED") || event.type.includes("MISMATCH") ? "WARNING" : "INFO",
  }

  console.log("[SECURITY]", JSON.stringify(logEntry))

  // TODO: In production, send to monitoring service (e.g., Sentry, DataDog)
}
