import { createClient } from "@/lib/supabase/client"

export type NotificationType =
  | "project_update"
  | "rating_change"
  | "issue_assigned"
  | "issue_resolved"
  | "activity_reminder"
  | "feedback_received"
  | "system"

export async function sendNotification(
  userId: string,
  title: string,
  message: string,
  type: NotificationType,
  link?: string,
) {
  try {
    const supabase = createClient()

    const { data, error } = await supabase
      .from("notifications")
      .insert({
        user_id: userId,
        title,
        message,
        type,
        link,
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Send notification error:", error)
      return null
    }

    return data
  } catch (error) {
    console.error("[v0] Notification send failed:", error)
    return null
  }
}

export async function notifyProjectUpdate(projectId: string, tumanId: string, title: string, updateMessage: string) {
  const supabase = createClient()

  // Get all users in the district
  const { data: users } = await supabase.from("profiles").select("id").eq("tuman_id", tumanId)

  if (!users) return

  for (const user of users) {
    await sendNotification(
      user.id,
      `Loyiha yangilandi: ${title}`,
      updateMessage,
      "project_update",
      `/projects/${projectId}`,
    )
  }
}

export async function notifyRatingChange(tumanId: string, newRating: number, oldRating: number, rank: number) {
  const supabase = createClient()

  // Get tuman sardori
  const { data: users } = await supabase
    .from("profiles")
    .select("id")
    .eq("tuman_id", tumanId)
    .eq("role", "tuman_sardori")

  if (!users) return

  const change = newRating - oldRating
  const changeText = change > 0 ? `+${change.toFixed(1)}` : change.toFixed(1)

  for (const user of users) {
    await sendNotification(
      user.id,
      "Reytingingiz yangilandi",
      `Yangi reyting: ${newRating.toFixed(1)} (${changeText}). O'rningiz: ${rank}`,
      "rating_change",
      "/tuman/dashboard",
    )
  }
}

export async function notifyIssueAssigned(issueId: string, assignedUserId: string, issueTitle: string) {
  await sendNotification(
    assignedUserId,
    "Sizga muammo tayinlandi",
    `Yangi muammo: ${issueTitle}`,
    "issue_assigned",
    `/viloyat/issues/${issueId}`,
  )
}

export async function notifyIssueResolved(issueId: string, reportedById: string, issueTitle: string) {
  await sendNotification(
    reportedById,
    "Muammo hal qilindi",
    `"${issueTitle}" muammosi hal qilindi`,
    "issue_resolved",
    `/viloyat/issues/${issueId}`,
  )
}

export async function notifyActivityReminder(
  activityId: string,
  tumanId: string,
  activityTitle: string,
  startDate: string,
) {
  const supabase = createClient()

  // Get all users in the district
  const { data: users } = await supabase.from("profiles").select("id").eq("tuman_id", tumanId)

  if (!users) return

  const dateStr = new Date(startDate).toLocaleDateString("uz-UZ")

  for (const user of users) {
    await sendNotification(
      user.id,
      "Tadbir eslatmasi",
      `"${activityTitle}" tadbiriga ${dateStr} da qatnashing`,
      "activity_reminder",
      `/tuman/activities/${activityId}`,
    )
  }
}
