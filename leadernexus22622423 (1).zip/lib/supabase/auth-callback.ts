// Auth callback handler to create profile after successful registration
import { createClient } from "@/lib/supabase/server"

export async function handleAuthCallback(userId: string, metadata: any) {
  const supabase = await createClient()

  try {
    // Check if profile already exists
    const { data: existingProfile } = await supabase.from("profiles").select("id").eq("id", userId).maybeSingle()

    if (existingProfile) {
      console.log("[v0] Profile already exists for user:", userId)
      return
    }

    // Create profile from user metadata
    const profileData = {
      id: userId,
      email: metadata.email,
      username: metadata.username,
      full_name: metadata.full_name,
      role: metadata.role || "leader",
      district: metadata.district || null,
      direction: metadata.direction || null,
      points: 0,
      language: "uz",
    }

    console.log("[v0] Creating profile:", profileData)

    const { error } = await supabase.from("profiles").insert(profileData)

    if (error) {
      console.error("[v0] Error creating profile:", error)
      throw error
    }

    console.log("[v0] Profile created successfully")
  } catch (error) {
    console.error("[v0] Error in handleAuthCallback:", error)
    throw error
  }
}
