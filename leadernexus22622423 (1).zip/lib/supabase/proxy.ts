import { createServerClient } from "@supabase/ssr"
import { NextResponse, type NextRequest } from "next/server"

export async function updateSession(request: NextRequest) {
  const publicRoutes = ["/", "/auth/login", "/auth/register"]
  const isPublicRoute = publicRoutes.includes(request.nextUrl.pathname)

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  // If Supabase credentials are missing, allow public routes but redirect protected routes to a setup page
  if (!supabaseUrl || !supabaseAnonKey) {
    console.error("[v0] Missing Supabase credentials in proxy")

    // Allow public routes to work without Supabase
    if (isPublicRoute) {
      return NextResponse.next({ request })
    }

    // For protected routes, redirect to home page with error message
    const url = request.nextUrl.clone()
    url.pathname = "/"
    url.searchParams.set("error", "supabase_not_configured")
    return NextResponse.redirect(url)
  }

  let supabaseResponse = NextResponse.next({
    request,
  })

  const supabase = createServerClient(supabaseUrl, supabaseAnonKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll()
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
        supabaseResponse = NextResponse.next({
          request,
        })
        cookiesToSet.forEach(({ name, value, options }) => supabaseResponse.cookies.set(name, value, options))
      },
    },
  })

  let user = null
  const isProtectedRoute =
    request.nextUrl.pathname.startsWith("/dashboard") ||
    request.nextUrl.pathname.startsWith("/forum") ||
    request.nextUrl.pathname.startsWith("/leaderboard") ||
    request.nextUrl.pathname.startsWith("/achievements") ||
    request.nextUrl.pathname.startsWith("/profile") ||
    request.nextUrl.pathname.startsWith("/plans") ||
    request.nextUrl.pathname.startsWith("/admin") ||
    request.nextUrl.pathname.startsWith("/district-dashboard") // Added district dashboard protection

  if (isProtectedRoute || !isPublicRoute) {
    try {
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()
      user = authUser
    } catch (error) {
      // If there's an authentication error (e.g., invalid refresh token),
      // clear the session by not setting user and let the redirect logic handle it
      console.log("[v0] Auth error in middleware:", error)
    }
  }

  // Redirect to login if accessing protected routes without authentication
  if (isProtectedRoute && !user) {
    const url = request.nextUrl.clone()
    url.pathname = "/auth/login"
    return NextResponse.redirect(url)
  }

  if (request.nextUrl.pathname.startsWith("/district-dashboard") && user) {
    try {
      const pathParts = request.nextUrl.pathname.split("/")
      const requestedDistrict = pathParts[2] ? decodeURIComponent(pathParts[2]) : null

      if (requestedDistrict) {
        const { data: profile } = await supabase.from("profiles").select("role, district").eq("id", user.id).single()

        // Validate user has district_head_leader role or admin
        if (!profile || (profile.role !== "district_head_leader" && profile.role !== "admin")) {
          console.error("[SECURITY] Unauthorized district dashboard access attempt", {
            userId: user.id,
            requestedPath: request.nextUrl.pathname,
          })
          const url = request.nextUrl.clone()
          url.pathname = "/dashboard"
          url.searchParams.set("error", "unauthorized_access")
          return NextResponse.redirect(url)
        }

        // CRITICAL: Validate district match for district_head_leader
        if (profile.role === "district_head_leader" && profile.district !== requestedDistrict) {
          console.error("[SECURITY] District mismatch detected", {
            userId: user.id,
            userDistrict: profile.district,
            requestedDistrict: requestedDistrict,
            timestamp: new Date().toISOString(),
          })
          const url = request.nextUrl.clone()
          url.pathname = "/dashboard"
          url.searchParams.set("error", "district_access_denied")
          return NextResponse.redirect(url)
        }

        // Log successful district access for audit
        console.log("[SECURITY] District access granted", {
          userId: user.id,
          district: requestedDistrict,
          role: profile.role,
          timestamp: new Date().toISOString(),
        })
      }
    } catch (error) {
      console.error("[SECURITY] Error validating district access:", error)
      const url = request.nextUrl.clone()
      url.pathname = "/dashboard"
      url.searchParams.set("error", "validation_error")
      return NextResponse.redirect(url)
    }
  }

  if (request.nextUrl.pathname.startsWith("/admin") && user) {
    try {
      const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

      if (!profile || profile.role !== "admin") {
        const url = request.nextUrl.clone()
        url.pathname = "/dashboard"
        return NextResponse.redirect(url)
      }
    } catch (error) {
      console.log("[v0] Error checking admin role:", error)
      // If there's an error checking admin role, redirect to dashboard
      const url = request.nextUrl.clone()
      url.pathname = "/dashboard"
      return NextResponse.redirect(url)
    }
  }

  // Redirect to dashboard if accessing auth pages while authenticated
  if ((request.nextUrl.pathname === "/auth/login" || request.nextUrl.pathname === "/auth/register") && user) {
    const url = request.nextUrl.clone()
    url.pathname = "/dashboard"
    return NextResponse.redirect(url)
  }

  return supabaseResponse
}
