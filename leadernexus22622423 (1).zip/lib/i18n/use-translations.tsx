"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { translations, type TranslationKeys } from "./translations"
import { i18nConfig, type Locale } from "./config"

const TranslationContext = createContext<{
  locale: Locale
  setLocale: (locale: Locale) => void
  t: (key: string, values?: Record<string, string | number>) => string
  translations: TranslationKeys
}>({
  locale: i18nConfig.defaultLocale,
  setLocale: () => {},
  t: () => "",
  translations: translations[i18nConfig.defaultLocale],
})

// Helper function to replace placeholders like {{name}} with values
function interpolate(text: string, values?: Record<string, string | number>): string {
  if (!values) return text
  return text.replace(/\{\{(\w+)\}\}/g, (_, key) => String(values[key] || ""))
}

// Helper to get nested value from object using dot notation
function getNestedValue(obj: any, path: string): any {
  const keys = path.split(".")
  let result = obj
  for (const key of keys) {
    if (result && typeof result === "object") {
      result = result[key]
    } else {
      return undefined
    }
  }
  return result
}

export function TranslationProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(i18nConfig.defaultLocale)

  // Load locale from localStorage or browser on mount
  useEffect(() => {
    const savedLocale = localStorage.getItem("locale") as Locale | null
    if (savedLocale && i18nConfig.locales.includes(savedLocale)) {
      setLocaleState(savedLocale)
    } else {
      // Detect browser language
      const browserLang = navigator.language.split("-")[0] as Locale
      if (i18nConfig.locales.includes(browserLang)) {
        setLocaleState(browserLang)
      }
    }
  }, [])

  const setLocale = (newLocale: Locale) => {
    setLocaleState(newLocale)
    localStorage.setItem("locale", newLocale)
    document.documentElement.lang = newLocale
  }

  const t = (key: string, values?: Record<string, string | number>): string => {
    const value = getNestedValue(translations[locale], key)
    if (value === undefined) {
      console.warn(`[v0] Translation key not found: ${key}`)
      return key
    }
    return interpolate(String(value), values)
  }

  return (
    <TranslationContext.Provider value={{ locale, setLocale, t, translations: translations[locale] }}>
      {children}
    </TranslationContext.Provider>
  )
}

export function useTranslations() {
  const context = useContext(TranslationContext)
  if (!context) {
    throw new Error("useTranslations must be used within TranslationProvider")
  }
  return context
}
