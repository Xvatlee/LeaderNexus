export const i18nConfig = {
  locales: ["en", "ru", "uz"],
  defaultLocale: "en",
  localeNames: {
    en: "English",
    ru: "Русский",
    uz: "O'zbekcha",
  },
  localeFlags: {
    en: "🇬🇧",
    ru: "🇷🇺",
    uz: "🇺🇿",
  },
} as const

export type Locale = (typeof i18nConfig.locales)[number]
