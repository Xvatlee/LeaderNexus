import { createClient } from "@/lib/supabase/server"

export async function checkAdminAccess() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { isAdmin: false, user: null, error: "Not authenticated" }
  }

  const { data: profile, error } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (error || !profile) {
    return { isAdmin: false, user, error: "Profile not found" }
  }

  if (profile.role !== "admin") {
    return { isAdmin: false, user, error: "Unauthorized - Admin access required" }
  }

  return { isAdmin: true, user, error: null }
}

export async function isUserAdmin(userId: string): Promise<boolean> {
  const supabase = await createClient()

  const { data, error } = await supabase.from("admins").select("user_id").eq("user_id", userId).maybeSingle()

  if (error || !data) {
    return false
  }

  return true
}

export async function checkSuperAdmin(email: string): Promise<boolean> {
  const superAdminEmail = process.env.SUPER_ADMIN_EMAIL || "xvatkee@gmail.com"
  return email === superAdminEmail
}

export async function getAdminRequestStatus(userId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("admin_requests")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle()

  if (error) {
    console.error("[v0] Error fetching admin request status:", error)
    return null
  }

  return data
}
