# Database Setup Instructions

## Problem: Registration Page Shows Configuration Error

If you see the error "Supabase is not configured" or "No districts available" on the registration page, it means the database tables haven't been created yet.

## Solution: Run the SQL Migration Scripts

### In v0 (Recommended)

1. The v0 interface will show a "Run Files" dialog with 6 SQL scripts
2. Click the **"Run All (6)"** button to execute all scripts in order
3. Wait for all scripts to complete successfully
4. Refresh the registration page

### Script Execution Order

The scripts will run in this order:

1. **01_create_tables.sql** - Creates base tables (viloyat, tuman, profiles, projects, etc.)
2. **02_enable_rls.sql** - Enables Row Level Security policies for all tables
3. **002_create_voting_tables.sql** - Creates voting system tables
4. **03_seed_sample_data.sql** - Seeds Surxondaryo region with 14 districts and 9 directions
5. **04_create_notification_triggers.sql** - Sets up automatic notification triggers
6. **008_add_status_to_profiles.sql** - Adds status tracking to user profiles

### What Gets Created

After running the scripts, your database will have:

- **Surxondaryo Region** (viloyat)
- **14 Districts** (tuman): Termiz, Denov, Sherobod, Boysun, Uzun, Qumqo'rg'on, Angor, Jarqo'rg'on, Sho'rchi, Bandixon, Muzrabot, Oltinsoy, Qiziriq, Sariosiyo
- **9 Leadership Directions**: Sport, San'at, Fan, Ijtimoiy ishlar, Ta'lim, Ekologiya, Texnologiya, Tadbirkorlik, Madaniyat
- All necessary tables with proper relationships and security policies

### Verification

After running the scripts:

1. Go to `/auth/register`
2. Select role: "Leader (Sardor)"
3. The "Tuman" dropdown should show 14 districts
4. The "Yo'nalish" dropdown should show 9 directions
5. If you see these options, setup is complete!

### Troubleshooting

**Error: "relation already exists"**
- Some tables were already created. This is normal if you run scripts multiple times.
- The scripts use `IF NOT EXISTS` where possible to prevent errors.

**Error: "permission denied"**
- Make sure your Supabase connection has admin privileges.
- Check that the `SUPABASE_SERVICE_ROLE_KEY` is set correctly.

**No data in dropdowns after running scripts**
- Run script `03_seed_sample_data.sql` again
- Check browser console for error messages
- Verify Supabase connection in v0's Connect section

### Manual Setup (Alternative)

If you need to run scripts manually in Supabase:

1. Go to your Supabase project dashboard
2. Navigate to SQL Editor
3. Copy and paste each script in order
4. Click "Run" for each script
5. Verify no errors appear in the output

## Next Steps

Once the database is set up:

1. Register a test account at `/auth/register`
2. Check your email for the confirmation link
3. Log in at `/auth/login`
4. Explore the dashboard and features

## Need Help?

If you continue to experience issues:

1. Check the v0 console for error messages
2. Verify all environment variables are set in the Vars section
3. Try disconnecting and reconnecting the Supabase integration
4. Visit the `/setup` page for a guided setup experience
